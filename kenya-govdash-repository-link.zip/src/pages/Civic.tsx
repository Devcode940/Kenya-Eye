import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Bot, Download, KeyRound, Lock, Search, Send, ShieldCheck, Upload } from "lucide-react";
import { COUNTIES, allRepresentatives, getCounty, searchAll } from "../data/counties";
import { AUDIT_SUMMARY, COUNTY_PENDING_TOTALS, DEVOLUTION_HISTORY, HIGHLIGHTS_2425_9M, NATIONAL_FINANCE, SOURCES, getAggregateFrom } from "../data/finance";
import { effectiveCountyFinance, getWb, saveWb, setWbStatus, setFeedbackStatus, getFeedback, addFeedback, getAlerts, getCecmVerified, toggleCecm, upsertFinance, deleteFinance, type WbEnvelope, type FeedbackItem } from "../data/store";
import { decryptEnvelope, encryptReport, ensureAdminKeypair, exportPrivateKeyPem, hasPrivateKeyInMemory, importPrivateKeyFromText } from "../lib/crypto";
import { formatKesMillions, formatPct } from "../lib/format";
import { useRouter } from "../lib/router";
import { AuditBadge, Card, DataGap, PersonRow, SectionTitle, StatCard } from "../components/ui";
import type { CountyFinance } from "../lib/types";

export function SearchPage({ initial }: { initial?: string }) {
  const { navigate, route } = useRouter();
  const [q, setQ] = useState(initial || route.query.q || "");
  const results = searchAll(q);
  const finHits = q.trim().length > 1 ? effectiveCountyFinance().filter((f) => f.countyName.toLowerCase().includes(q.toLowerCase())) : [];
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Site-wide search</h1>
      <div className="relative">
        <Search className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Counties, officials, parties, finance…" className="h-12 w-full rounded-2xl border border-border bg-card pl-12 pr-4" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5">
          <SectionTitle title={`Counties (${results.counties.length})`} />
          {results.counties.map((c) => (
            <button key={c.code} onClick={() => navigate("county", { code: String(c.code) })} className="block w-full rounded-lg px-2 py-2 text-left hover:bg-muted">
              {c.name} · {c.governor.name}
            </button>
          ))}
        </Card>
        <Card className="p-5">
          <SectionTitle title={`Officials (${results.people.length})`} />
          <div className="max-h-[480px] overflow-y-auto">
            {results.people.slice(0, 40).map((p) => (
              <PersonRow key={p.id} person={p} onClick={() => navigate("rep", { id: p.id })} />
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle title={`Finance records (${finHits.length})`} />
          {finHits.map((f) => (
            <button key={f.countyName} onClick={() => navigate("finance-county", { name: f.countyName })} className="block w-full rounded-lg px-2 py-2 text-left hover:bg-muted">
              {f.countyName} · FY {f.fiscalYear} · {formatPct(f.overallAbsorption)} · <AuditBadge opinion={f.auditOpinion} />
            </button>
          ))}
        </Card>
      </div>
    </div>
  );
}

export function StatsPage() {
  const eff = effectiveCountyFinance();
  const agg = getAggregateFrom(eff);
  const reps = allRepresentatives();
  const senators = reps.filter((p) => p.title.startsWith("Senator")).length;
  const wrs = reps.filter((p) => p.title.startsWith("Woman")).length;
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Platform statistics</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Counties" value="47" hint="CoK 2010, Sch. 4" />
        <StatCard label="Officials indexed" value={String(reps.length)} hint={`${senators} senators · ${wrs} women reps · 47 governors`} />
        <StatCard label="Finance snapshots FY23/24" value={String(eff.length)} hint="CoB CG-BIRR extract" />
        <StatCard label="Avg CoG compliance" value={agg.avgCompliance.toFixed(1)} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle title="Coverage honesty" />
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Population: 47/47 (KNBS 2019 Census)</li>
            <li>Governors, senators, women reps: 47/47 (IEBC 2022)</li>
            <li>Finance FY 2023/24 county rows: {eff.length}/47 — the rest are N/A, not estimated</li>
            <li>Verified CECM names: {reps.filter((r) => r.title.startsWith("CECM") && (getCecmVerified()[r.id] ?? r.verified)).length} of {reps.filter((r) => r.title.startsWith("CECM")).length}</li>
            <li>Whistleblower envelopes held locally: {getWb().length}</li>
            <li>Feedback submissions: {getFeedback().length} · Alerts: {getAlerts().length}</li>
          </ul>
        </Card>
        <Card className="p-5">
          <SectionTitle title="OAG audit summary (published)" />
          <ul className="space-y-2 text-sm">
            <li>FY 2023/24 county executives with clean opinion: <strong>0 of 47</strong> — {AUDIT_SUMMARY.countyExecutivesFY2324.note}</li>
            <li>FY 2023/24 county assemblies with clean opinion: <strong>8</strong> (up from 3) — {AUDIT_SUMMARY.countyAssembliesFY2324.note}</li>
            <li>FY 2022/23 county revenue funds: 46% unmodified · 43% qualified · 11% adverse · 0 disclaimer (46 CRFs)</li>
          </ul>
        </Card>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {SOURCES.map((s) => (
          <a key={s.abbr} href={s.url} target="_blank" rel="noreferrer" className="rounded-xl border border-border p-3 text-sm hover:bg-muted/40">
            <p className="font-semibold">{s.abbr}</p>
            <p className="text-muted-foreground">{s.data}</p>
          </a>
        ))}
      </div>
    </div>
  );
}

export function FeedbackPage() {
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [form, setForm] = useState({ name: "", county: "Nairobi City", topic: "Service delivery", message: "" });
  useEffect(() => {
    const load = () => setItems(getFeedback());
    load();
    window.addEventListener("kgd-store", load);
    return () => window.removeEventListener("kgd-store", load);
  }, []);

  function submit(e: FormEvent) {
    e.preventDefault();
    addFeedback({ ...form });
    setForm({ ...form, message: "" });
  }

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Public feedback</h1>
      <p className="text-sm text-muted-foreground">Submissions persist in this browser's store. Admins triage status from the Admin console; the timeline updates here.</p>
      <Card className="p-5">
        <form onSubmit={submit} className="grid gap-3">
          <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" className="h-10 rounded-xl border border-border bg-background px-3" />
          <div className="grid gap-3 sm:grid-cols-2">
            <select value={form.county} onChange={(e) => setForm({ ...form, county: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
              {COUNTIES.map((c) => (
                <option key={c.code}>{c.name}</option>
              ))}
            </select>
            <select value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
              {["Service delivery", "Roads", "Health", "Water", "Corruption concern", "Budget"].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </div>
          <textarea required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} placeholder="Your feedback" className="rounded-xl border border-border bg-background px-3 py-2" />
          <button className="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-ke-green text-white">
            <Send className="h-4 w-4" /> Submit
          </button>
        </form>
      </Card>
      <div className="space-y-3">
        {items.map((it) => (
          <Card key={it.id} className="p-4">
            <div className="flex justify-between gap-3">
              <div>
                <p className="font-medium">
                  {it.topic} · {it.county}
                </p>
                <p className="text-sm text-muted-foreground">{it.message}</p>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {it.name} · {new Date(it.at).toLocaleString()}
                </p>
              </div>
              <span className="h-fit rounded-full bg-amber-100 px-2 py-0.5 text-[11px] text-amber-800">{it.status}</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
              {it.history.map((h, i) => (
                <span key={i} className="rounded-full border border-border px-2 py-0.5">
                  {new Date(h.at).toLocaleDateString()} · {h.status}
                </span>
              ))}
            </div>
          </Card>
        ))}
        {items.length === 0 && <DataGap note="No submissions yet in this browser." />}
      </div>
    </div>
  );
}

export function WhistleblowerPage() {
  const [ticket, setTicket] = useState("");
  const [trackInput, setTrackInput] = useState("");
  const [trackResult, setTrackResult] = useState("");
  const [form, setForm] = useState({ category: "Procurement", county: "Nairobi City", evidence: "" });
  const [pubInfo, setPubInfo] = useState<{ fingerprint: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    ensureAdminKeypair().then((k) => setPubInfo({ fingerprint: k.fingerprint }));
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const envelope = await encryptReport(JSON.stringify({ ...form, submittedAt: new Date().toISOString() }));
      const id = `WB-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
      const env: WbEnvelope = {
        id,
        ...envelope,
        category: form.category,
        county: form.county,
        status: "Queued",
        at: Date.now(),
        history: [{ status: "Queued", at: Date.now() }],
      };
      saveWb(env);
      setTicket(id);
      setForm({ ...form, evidence: "" });
    } finally {
      setBusy(false);
    }
  }

  function track() {
    const hit = getWb().find((s) => s.id === trackInput.trim().toUpperCase());
    setTrackResult(hit ? `${hit.id} · ${hit.category} · ${hit.county} · status: ${hit.status}` : "No ticket found in this browser's store.");
  }

  async function downloadKey() {
    try {
      const pem = await exportPrivateKeyPem();
      const blob = new Blob([pem], { type: "text/plain" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "govdash-admin-private-key.pem";
      a.click();
    } catch (err) {
      alert((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Lock className="h-6 w-6 text-ke-green" />
        <h1 className="font-display text-3xl">Whistleblower portal</h1>
      </div>
      <Card className="p-4 text-sm">
        <p className="flex items-start gap-2">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
          Real hybrid encryption in your browser: RSA-OAEP-2048 admin public key wraps a fresh AES-256-GCM key per report. Only ciphertext and the wrapped key are stored — the private key never persists (download it once below; without it, nobody can read the report).
        </p>
        {pubInfo && (
          <p className="mt-2 font-mono text-[11px] text-muted-foreground">
            Admin public key fingerprint: {pubInfo.fingerprint}
          </p>
        )}
        <button onClick={downloadKey} className="mt-2 inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs">
          <KeyRound className="h-3.5 w-3.5" /> Download admin private key (one-time, keep offline)
        </button>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle title="Submit encrypted report" />
          <form onSubmit={submit} className="grid gap-3">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
              {["Procurement", "Ghost workers", "Pending bills", "Land", "Extra-legal action", "Other"].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <select value={form.county} onChange={(e) => setForm({ ...form, county: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
              {COUNTIES.map((c) => (
                <option key={c.code}>{c.name}</option>
              ))}
            </select>
            <textarea required value={form.evidence} onChange={(e) => setForm({ ...form, evidence: e.target.value })} rows={6} placeholder="Describe the issue. Do not include your name." className="rounded-xl border border-border bg-background px-3 py-2" />
            <button disabled={busy} className="h-10 rounded-xl bg-ke-black text-white disabled:opacity-50 dark:bg-primary dark:text-primary-foreground">
              {busy ? "Encrypting…" : "Encrypt & submit"}
            </button>
          </form>
          {ticket && (
            <p className="mt-3 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200">
              Ticket <strong>{ticket}</strong> — save this ID to track status.
            </p>
          )}
        </Card>
        <Card className="p-5">
          <SectionTitle title="Track a ticket" />
          <div className="flex gap-2">
            <input value={trackInput} onChange={(e) => setTrackInput(e.target.value)} placeholder="WB-XXXXXXXX" className="h-10 flex-1 rounded-xl border border-border bg-background px-3" />
            <button onClick={track} className="h-10 rounded-xl border border-border px-4">
              Track
            </button>
          </div>
          {trackResult && <p className="mt-3 text-sm">{trackResult}</p>}
        </Card>
      </div>
    </div>
  );
}

function aiAnswer(q: string): string {
  const s = q.toLowerCase();
  const eff = effectiveCountyFinance();
  const agg = getAggregateFrom(eff);
  const unmod = eff.filter((c) => c.auditOpinion === "Unmodified");
  if (s.includes("clean") || (s.includes("best") && s.includes("audit")) || s.includes("unmodified"))
    return `In the FY 2023/24 extract, ${unmod.length} counties carry an Unmodified (clean) audit opinion: ${unmod.map((c) => c.countyName).join(", ") || "none"}. Note: OAG's Green Book FY 2023/24 records that no county executive received a clean opinion nationwide — the clean opinions in our extract reflect the published county-level figures we hold. Source: OAG Green Book Vol 1 FY 2023/24; CoB CG-BIRR FY 2023/24.`;
  if (s.includes("worst") || s.includes("bottom") || s.includes("adverse") || s.includes("lowest"))
    return `Lowest CoG compliance in the FY 2023/24 extract: ${agg.bottomPerformers.map((c) => `${c.countyName} (${c.complianceScore}, ${c.auditOpinion})`).join("; ")}. CoB 9M FY 2024/25 lowest overall absorption: ${HIGHLIGHTS_2425_9M.lowestOverall.map(([n, v]) => `${n} ${v}%`).join(", ")}. These are published scores, not accusations.`;
  if (s.includes("pending"))
    return `CoB's latest report puts outstanding county trade payables at ${formatKesMillions(COUNTY_PENDING_TOTALS.totalTradePayables)}, with Nairobi City at ${formatKesMillions(COUNTY_PENDING_TOTALS.nairobiShare)} (~50%). In the FY 2023/24 county extract, sampled pending bills total ${formatKesMillions(agg.totalPendingBills)}. National government pending bills FY 2023/24: ${formatKesMillions(NATIONAL_FINANCE.find((n) => n.fiscalYear === "2023/24")!.pendingBills)}. Source: CoB CG-BIRR; OAG.`;
  if (s.includes("debt"))
    return `National public debt FY 2023/24 snapshot: ${formatKesMillions(NATIONAL_FINANCE.find((n) => n.fiscalYear === "2023/24")!.totalDebt)}. Source: National Treasury / OAG.`;
  if (s.includes("absorption") && (s.includes("average") || s.includes("overall") || s.includes("national")))
    return `County governments spent ${formatKesMillions(NATIONAL_FINANCE[0].actualExpenditure)} of ${formatKesMillions(NATIONAL_FINANCE[0].approvedBudget)} approved in FY 2024/25 (78% overall; development 54.21%). FY 2023/24 extract average overall absorption across the ${agg.count} counties we hold: ${agg.avgOverallAbsorption.toFixed(1)}%. Source: CoB CG-BIRR.`;
  if (s.includes("senator") && s.includes("how many")) return "47 senators, one per county, elected 9 August 2022 (IEBC).";
  if (s.includes("governor") && s.includes("how many")) return "47 county governors for the 2022–2027 term (IEBC).";
  if (s.includes("uda") && s.includes("governor"))
    return `${COUNTIES.filter((c) => c.governor.party === "UDA").length} of 47 governors were elected on UDA tickets in 2022. Source: IEBC 2022 results.`;
  const countyHit = COUNTIES.find((c) => s.includes(c.name.toLowerCase().replace(" city", "")));
  if (countyHit) {
    const f = eff.find((x) => x.countyName === countyHit.name);
    return `${countyHit.name} County (code ${countyHit.code}, ${countyHit.region}): Governor ${countyHit.governor.name} (${countyHit.governor.party}), Senator ${countyHit.senator?.name ?? "N/A"} (${countyHit.senator?.party ?? "—"}), Woman Rep ${countyHit.womanRep?.name ?? "N/A"}. Population ${countyHit.population.toLocaleString()} (KNBS 2019). ${f ? `FY ${f.fiscalYear}: absorption ${formatPct(f.overallAbsorption)}, development ${formatPct(f.developmentAbsorption)}, audit ${f.auditOpinion}, CoG ${f.complianceScore}, pending bills ${formatKesMillions(f.pendingBills)}.` : "No FY 2023/24 finance extract held — N/A rather than estimated."}`;
  }
  if (s.includes("compare") && countyHit === undefined) return "Ask me about any county by name (e.g. “compare Nakuru vs Nyeri” style queries), or open the Compare page for radar charts.";
  return `I answer from the OAG / CoB / KNBS / IEBC records attached to this dashboard and never invent figures. Try: “Which counties have unmodified audits?”, “Nairobi absorption”, “pending bills”, “debt”, “UDA governors”, or any county name.`;
}

export function AIPage() {
  const [q, setQ] = useState("");
  const [chat, setChat] = useState<{ role: "user" | "ai"; text: string }[]>([
    { role: "ai", text: "Ask about county finance, audit opinions, governors, senators, women reps, pending bills or debt. Answers cite the attached OAG / CoB / KNBS / IEBC records." },
  ]);

  function send(e: FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    setChat((c) => [...c, { role: "user", text: q }, { role: "ai", text: aiAnswer(q) }]);
    setQ("");
  }

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center gap-2">
        <Bot className="h-6 w-6 text-ke-green" />
        <h1 className="font-display text-3xl">AI assistant</h1>
      </div>
      <p className="text-sm text-muted-foreground">Data-grounded assistant over the full 47-county dataset. The production Kenya GovDash adds Mistral AI when an API key is configured; this build answers strictly from attached published records.</p>
      <Card className="flex h-[480px] flex-col p-4">
        <div className="flex-1 space-y-3 overflow-y-auto pr-1">
          {chat.map((m, i) => (
            <div key={i} className={`max-w-[90%] whitespace-pre-line rounded-2xl px-3 py-2 text-sm ${m.role === "ai" ? "bg-muted" : "ml-auto bg-ke-green text-white"}`}>
              {m.text}
            </div>
          ))}
        </div>
        <form onSubmit={send} className="mt-3 flex gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Which county has the best audit opinion?" className="h-11 flex-1 rounded-full border border-border bg-background px-4 text-sm" />
          <button className="h-11 rounded-full bg-ke-green px-4 text-white">Send</button>
        </form>
      </Card>
    </div>
  );
}

const ADMIN_PASSWORD = "fb0599a99117931085153a59";

type AdminTab = "resources" | "finance" | "cecm" | "wb" | "feedback";

export function AdminPage() {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem("kgd-admin") === "1");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<AdminTab>("resources");
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const bump = () => setTick((t) => t + 1);
    window.addEventListener("kgd-store", bump);
    return () => window.removeEventListener("kgd-store", bump);
  }, []);

  if (!authed) {
    return (
      <div className="mx-auto max-w-sm space-y-4 pt-10">
        <h1 className="font-display text-3xl">Admin console</h1>
        <p className="text-sm text-muted-foreground">Demo login. Production requires ADMIN_PASSWORD_HASH + JWT_SECRET and fails closed without them.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (pw === ADMIN_PASSWORD) {
              sessionStorage.setItem("kgd-admin", "1");
              setAuthed(true);
            } else setErr("Invalid password");
          }}
          className="grid gap-3"
        >
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" className="h-11 rounded-xl border border-border bg-background px-3" />
          <button className="h-11 rounded-xl bg-ke-black text-white dark:bg-primary dark:text-primary-foreground">Sign in</button>
          {err && <p className="text-sm text-rose-600">{err}</p>}
        </form>
      </div>
    );
  }

  const eff = effectiveCountyFinance();
  const reps = allRepresentatives();
  const cecms = reps.filter((p) => p.title.startsWith("CECM"));
  const verifiedMap = getCecmVerified();
  const verified = cecms.filter((c) => verifiedMap[c.id] ?? c.verified).length;
  const wb = getWb();
  const feedback = getFeedback();
  void tick;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl">Admin console</h1>
        <button
          className="text-sm underline"
          onClick={() => {
            sessionStorage.removeItem("kgd-admin");
            setAuthed(false);
          }}
        >
          Sign out
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {(["resources", "finance", "cecm", "wb", "feedback"] as AdminTab[]).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-full px-3 py-1 text-sm ${tab === t ? "bg-ke-green text-white" : "border border-border"}`}>
            {t === "resources" ? "Oversight resources" : t === "finance" ? "Finance snapshots" : t === "cecm" ? "CECM verification" : t === "wb" ? "Whistleblower triage" : "Feedback triage"}
          </button>
        ))}
      </div>

      {tab === "resources" && (
        <Card className="p-5">
          {SOURCES.map((r) => (
            <a key={r.abbr} href={r.url} target="_blank" rel="noreferrer" className="flex items-center justify-between border-b border-border py-2 text-sm hover:bg-muted/40">
              <span>
                <strong>{r.abbr}</strong> — {r.name} · {r.data}
              </span>
              <span className="text-xs text-ke-green">open ↗</span>
            </a>
          ))}
        </Card>
      )}

      {tab === "finance" && <FinanceAdmin records={eff} />}

      {tab === "cecm" && (
        <Card className="p-5">
          <p className="mb-3 text-sm">
            Verified names: {verified} / {cecms.length} ({Math.round((verified / cecms.length) * 100)}%)
          </p>
          <div className="mb-4 h-3 overflow-hidden rounded-full bg-muted">
            <div className="h-full bg-ke-green" style={{ width: `${(verified / cecms.length) * 100}%` }} />
          </div>
          <div className="max-h-[420px] space-y-1 overflow-y-auto">
            {cecms.map((c) => {
              const v = verifiedMap[c.id] ?? c.verified;
              return (
                <div key={c.id} className="flex items-center justify-between rounded-lg px-2 py-1.5 text-sm hover:bg-muted/50">
                  <span>
                    {c.name} — <span className="text-muted-foreground">{c.title.replace("CECM — ", "")} · {c.jurisdiction}</span>
                  </span>
                  <button onClick={() => toggleCecm(c.id, !v)} className={`rounded-full px-2 py-0.5 text-[11px] ${v ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                    {v ? "Verified" : "Unverified"}
                  </button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {tab === "wb" && <WbAdmin envelopes={wb} />}

      {tab === "feedback" && (
        <Card className="p-5">
          {feedback.length === 0 && <p className="text-sm text-muted-foreground">No feedback submissions.</p>}
          {feedback.map((f) => (
            <div key={f.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-border py-2 text-sm">
              <span>
                {f.topic} · {f.county} · {f.message.slice(0, 60)}
              </span>
              <span className="flex gap-1">
                {(["Received", "Under review", "Responded", "Closed"] as const).map((s) => (
                  <button key={s} onClick={() => setFeedbackStatus(f.id, s)} className={`rounded-full border px-2 py-0.5 text-[11px] ${f.status === s ? "border-ke-green bg-ke-green text-white" : "border-border"}`}>
                    {s}
                  </button>
                ))}
              </span>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

function FinanceAdmin({ records }: { records: CountyFinance[] }) {
  const [form, setForm] = useState({ countyName: "Nairobi City", approvedBudget: "41200", overallAbsorption: "54.4", developmentAbsorption: "3.3", auditOpinion: "Adverse", complianceScore: "62", pendingBills: "24500" });
  const [msg, setMsg] = useState("");
  return (
    <div className="space-y-4">
      <Card className="p-5">
        <SectionTitle title="Add / update FY 2023/24 snapshot" />
        <form
          className="grid gap-2 sm:grid-cols-3"
          onSubmit={(e) => {
            e.preventDefault();
            upsertFinance({
              countyName: form.countyName,
              fiscalYear: "2023/24",
              approvedBudget: Number(form.approvedBudget),
              equitableShare: 0,
              osrTarget: 0,
              overallAbsorption: Number(form.overallAbsorption),
              developmentAbsorption: Number(form.developmentAbsorption),
              auditOpinion: form.auditOpinion as CountyFinance["auditOpinion"],
              complianceScore: Number(form.complianceScore),
              pendingBills: Number(form.pendingBills),
              source: "Admin-entered (kgd store)",
            });
            setMsg(`Saved snapshot for ${form.countyName}.`);
          }}
        >
          <select value={form.countyName} onChange={(e) => setForm({ ...form, countyName: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
            {COUNTIES.map((c) => (
              <option key={c.code}>{c.name}</option>
            ))}
          </select>
          <input value={form.approvedBudget} onChange={(e) => setForm({ ...form, approvedBudget: e.target.value })} placeholder="Approved budget (M)" className="h-10 rounded-xl border border-border bg-background px-3" />
          <input value={form.overallAbsorption} onChange={(e) => setForm({ ...form, overallAbsorption: e.target.value })} placeholder="Overall absorption %" className="h-10 rounded-xl border border-border bg-background px-3" />
          <input value={form.developmentAbsorption} onChange={(e) => setForm({ ...form, developmentAbsorption: e.target.value })} placeholder="Dev absorption %" className="h-10 rounded-xl border border-border bg-background px-3" />
          <select value={form.auditOpinion} onChange={(e) => setForm({ ...form, auditOpinion: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">
            {["Unmodified", "Qualified", "Adverse", "Disclaimer"].map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
          <input value={form.complianceScore} onChange={(e) => setForm({ ...form, complianceScore: e.target.value })} placeholder="CoG score" className="h-10 rounded-xl border border-border bg-background px-3" />
          <input value={form.pendingBills} onChange={(e) => setForm({ ...form, pendingBills: e.target.value })} placeholder="Pending bills (M)" className="h-10 rounded-xl border border-border bg-background px-3" />
          <button className="h-10 rounded-xl bg-ke-green text-white sm:col-span-3">Save snapshot</button>
        </form>
        {msg && <p className="mt-2 text-sm text-emerald-700">{msg}</p>}
      </Card>
      <Card className="overflow-x-auto p-5">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase text-muted-foreground">
              <th className="py-1">County</th>
              <th>Budget</th>
              <th>Absorption</th>
              <th>Audit</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.countyName} className="border-t border-border">
                <td className="py-1.5">{r.countyName}</td>
                <td>{formatKesMillions(r.approvedBudget)}</td>
                <td>{formatPct(r.overallAbsorption)}</td>
                <td>{r.auditOpinion}</td>
                <td>
                  <button className="text-xs text-rose-600" onClick={() => deleteFinance(r.countyName)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function WbAdmin({ envelopes }: { envelopes: WbEnvelope[] }) {
  const [keyFile, setKeyFile] = useState("");
  const [decrypted, setDecrypted] = useState<Record<string, string>>({});
  const [err, setErr] = useState("");

  async function importKey(file: File) {
    const text = await file.text();
    setKeyFile(file.name);
    try {
      await importPrivateKeyFromText(text);
      setErr("");
    } catch {
      setErr("Could not import that key file.");
    }
  }

  async function decrypt(id: string) {
    const env = envelopes.find((w) => w.id === id);
    if (!env) return;
    try {
      const plain = await decryptEnvelope(env);
      setDecrypted((d) => ({ ...d, [id]: plain }));
      setErr("");
    } catch (e) {
      setErr((e as Error).message);
    }
  }

  function exportBundle() {
    const blob = new Blob([JSON.stringify(envelopes, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "whistleblower-ciphertext-bundle.json";
    a.click();
  }

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <SectionTitle title="Offline decryption" action={
          <button onClick={exportBundle} className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs">
            <Download className="h-3.5 w-3.5" /> Export ciphertext bundle
          </button>
        } />
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <label className="inline-flex cursor-pointer items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs">
            <Upload className="h-3.5 w-3.5" /> Import admin private key {keyFile && <span className="text-muted-foreground">({keyFile})</span>}
            <input type="file" accept=".pem,.key,.txt" className="hidden" onChange={(e) => e.target.files?.[0] && importKey(e.target.files[0])} />
          </label>
          <span className="text-xs text-muted-foreground">{hasPrivateKeyInMemory() ? "Private key loaded in memory (not stored)." : "No private key in memory."}</span>
        </div>
        {err && <p className="mt-2 text-sm text-rose-600">{err}</p>}
      </Card>
      <Card className="p-5">
        {envelopes.length === 0 && <p className="text-sm text-muted-foreground">No encrypted envelopes in this browser.</p>}
        {envelopes.map((w) => (
          <div key={w.id} className="border-b border-border py-3 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-xs">
                {w.id} · {w.category} · {w.county} · {new Date(w.at).toLocaleString()}
              </span>
              <span className="flex gap-1">
                {(["Queued", "Under review", "Escalated", "Closed"] as const).map((s) => (
                  <button key={s} onClick={() => setWbStatus(w.id, s)} className={`rounded-full border px-2 py-0.5 text-[11px] ${w.status === s ? "border-ke-green bg-ke-green text-white" : "border-border"}`}>
                    {s}
                  </button>
                ))}
              </span>
            </div>
            <p className="mt-1 font-mono text-[10px] text-muted-foreground">
              ciphertext {w.ciphertext.length} chars · iv {w.iv} · wrapped key {w.wrappedKey.length} chars — server-side storage sees only this
            </p>
            <div className="mt-1 flex gap-2">
              <button onClick={() => decrypt(w.id)} className="rounded-full border border-border px-2 py-0.5 text-[11px]">
                Decrypt (needs key)
              </button>
            </div>
            {decrypted[w.id] && <pre className="mt-2 max-h-32 overflow-y-auto rounded-lg bg-muted p-2 text-xs">{decrypted[w.id]}</pre>}
          </div>
        ))}
      </Card>
    </div>
  );
}

const REPORTS = [
  { label: "OAG Green Book Vol 1 — County Executives FY 2023/24 (PDF)", value: "https://www.oagkenya.go.ke/wp-content/uploads/2025/02/GREEN-BOOK-EXECUTIVES-2024-FINAL-5.3.2025-SIGNED.pdf", note: "Signed 5 Mar 2025 · audit opinions per county executive" },
  { label: "OAG Green Book Vol 2 — County Assemblies FY 2023/24 (PDF)", value: "https://www.oagkenya.go.ke/wp-content/uploads/2025/02/GREEN-BOOK-ASSEMBLIES-2024-FINAL-01-April-2025-KLB.pdf", note: "8 assemblies with clean opinions" },
  { label: "OAG Summary Report — County Revenue Funds FY 2022/23 (PDF)", value: "https://www.oagkenya.go.ke/wp-content/uploads/2024/07/Combined-Summary-Report-County-Governments-Revenue-Funds-2023.pdf", note: "46% unmodified · 43% qualified · 11% adverse" },
  { label: "CoB — County BIRRs (all reports)", value: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports", note: "Absorption, OSR, pending bills per county" },
  { label: "CoB — National Government BIRRs", value: "https://cob.go.ke/reports", note: "National budget execution" },
  { label: "Council of Governors", value: "https://cog.go.ke/", note: "Compliance scores, county status" },
  { label: "EACC — corruption reports", value: "https://eacc.go.ke/", note: "Ethics & anti-corruption" },
  { label: "Parliament of Kenya — members", value: "https://www.parliament.go.ke/", note: "MPs, senators, women reps" },
  { label: "KNBS 2019 Census volumes", value: "https://www.knbs.or.ke/?p=2972", note: "Population & housing census" },
];

const OVERSIGHT: Record<string, { title: string; body: string; rows: { label: string; value: string; note: string; href?: string }[] }> = {
  "pending-bills": {
    title: "Pending bills heatmap",
    body: `CoB-reported pending bills. Latest national figure: county trade payables ${formatKesMillions(COUNTY_PENDING_TOTALS.totalTradePayables)}, Nairobi City ${formatKesMillions(COUNTY_PENDING_TOTALS.nairobiShare)} (~50%). ${COUNTY_PENDING_TOTALS.source}.`,
    rows: effectiveCountyFinance()
      .slice()
      .sort((a, b) => (b.pendingBills || 0) - (a.pendingBills || 0))
      .map((c) => ({ label: c.countyName, value: formatKesMillions(c.pendingBills), note: c.source })),
  },
  projects: {
    title: "Development absorption (project proxy)",
    body: "Development absorption is the published proxy for project delivery in CoB BIRRs. 9M FY 2024/25 leaders: " + HIGHLIGHTS_2425_9M.highestDev.map(([n, v]) => `${n} ${v}%`).join(", ") + ". Laggards: " + HIGHLIGHTS_2425_9M.lowestDev9M.map(([n, v]) => `${n} ${v}%`).join(", ") + ".",
    rows: effectiveCountyFinance()
      .slice()
      .sort((a, b) => (a.developmentAbsorption || 0) - (b.developmentAbsorption || 0))
      .map((c) => ({ label: c.countyName, value: formatPct(c.developmentAbsorption), note: "Development absorption FY 2023/24 · " + c.source })),
  },
  "red-flags": {
    title: "Red-flag scanner",
    body: "Heuristic flags from published metrics only — not findings of guilt.",
    rows: effectiveCountyFinance()
      .filter((c) => c.auditOpinion === "Adverse" || c.auditOpinion === "Disclaimer" || (c.developmentAbsorption || 0) < 20 || (c.overallAbsorption || 100) < 60)
      .map((c) => ({
        label: c.countyName,
        value: c.auditOpinion,
        note: `Absorption ${formatPct(c.overallAbsorption)} · Dev ${formatPct(c.developmentAbsorption)} · Pending ${formatKesMillions(c.pendingBills)} · ${c.source}`,
      })),
  },
  tenders: {
    title: "Tender anomaly detector",
    body: "PPRA award-level data is not bundled here. This panel stays empty rather than fabricating tenders — see PPRA's public portal for live awards.",
    rows: [{ label: "PPRA tenders portal", value: "ppra.go.ke", note: "Official public procurement awards", href: "https://www.ppra.go.ke/" }],
  },
  constitution: {
    title: "Constitution of Kenya 2010",
    body: "Devolution under Chapter 11 (47 counties, Fourth Schedule). Leadership & integrity under Chapter 6. Public finance principles under Article 201; Auditor-General under Article 229.",
    rows: [
      { label: "Chapter 6", value: "Leadership & Integrity", note: "State officer obligations" },
      { label: "Chapter 11", value: "Devolved Government", note: "47 counties; Fourth Schedule functions" },
      { label: "Article 201", value: "Public finance principles", note: "Openness, accountability, prudent use" },
      { label: "Article 229", value: "Auditor-General", note: "Audits national + county governments" },
    ],
  },
  court: {
    title: "Court cases tracker",
    body: "No complete public dataset of county-linked cases is bundled. Matters must be cited from Kenya Law (kenyalaw.org) — none are invented here.",
    rows: [{ label: "Kenya Law Reports", value: "kenyalaw.org", note: "Official case law", href: "https://kenyalaw.org/" }],
  },
  reports: {
    title: "Oversight reports & official portals",
    body: "Primary sources behind every figure on this dashboard.",
    rows: REPORTS.map((r) => ({ label: r.label, value: "Open ↗", note: r.note, href: r.value })),
  },
  datasets: {
    title: "kenya-county-data — open county dataset",
    body: "Every county page in this app is backed by a structured JSON dataset under kenya-county-data/data/ (11 domains × 47 counties), with a SQLite schema, ingestion pipelines (KNBS, CoB/Treasury, CoG, county portals) and a zero-dependency Node API. Missing public data is null + source, never estimated.",
    rows: [
      { label: "data/counties/county_master.json", value: "47 counties", note: "codes, county seats, centroids, population, leadership — IEBC 2022 + KNBS 2019" },
      { label: "data/counties/county_boundaries.geojson", value: "47 features", note: "centroid Points; swap in IEBC polygons via ingestion/knbs" },
      { label: "data/{demographics,health,education,agriculture,finance,infrastructure,projects,governance,procurement,environment,elections}", value: "11 domains", note: "per-county JSON; published fields filled, the rest null + source" },
      { label: "database/schema.sql + migrations/", value: "SQLite/Postgres", note: "counties, representatives, finance_snapshots, domain_* tables, civic tables" },
      { label: "ingestion/ (knbs, treasury, cog, county_portals, validation)", value: "5 pipelines", note: "node kenya-county-data/ingestion/validation/validate.mjs — exit 1 on errors" },
      { label: "backend/server.mjs", value: "http://localhost:4000", note: "node kenya-county-data/backend/server.mjs → /api/counties/:code/:domain, /api/finance?format=csv, /api/search" },
      { label: "Regenerate from app data", value: "npx tsx scripts/generate-county-data.mts", note: "writes all data/** JSON from verified in-app datasets" },
    ],
  },
  archive: {
    title: "Past fiscal-year reports — explore every year since devolution",
    body: "Every financial year from the start of devolution (FY 2013/14) to FY 2024/25. Each year links to the official OAG audit reports page and the CoB reports portal, plus the aggregate figures we hold (null = not published, never estimated). API: GET /api/reports and /api/devolution on the local backend.",
    rows: [],
  },
};

const FY_REPORT_LINKS: Record<string, { oag: string; cob: string }> = {
  "2013/14": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2014/15": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2015/16": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2016/17": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2017/18": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2018/19": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2019/20": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2020/21": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  "2021/22": { oag: "https://www.oagkenya.go.ke/2021-2022-county-government-audit-reports/", cob: "https://cob.go.ke/reports" },
  "2022/23": { oag: "https://www.oagkenya.go.ke/2022-2023-county-government-audit-reports/", cob: "https://cob.go.ke/reports" },
  "2023/24": { oag: "https://www.oagkenya.go.ke/2023-2024-county-government-audit-reports/", cob: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports" },
  "2024/25": { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports" },
};

export function ArchivePage() {
  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">OAG · CoB · CRA · Parliament</p>
        <h1 className="font-display text-3xl">Past FY reports — 2013/14 → 2024/25</h1>
        <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
          Explore every fiscal year since devolution began (April 2013). Each card links to the official audit (OAG Green Book) and budget (CoB BIRR) reports and shows the aggregate figures held here.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {DEVOLUTION_HISTORY.map((d) => {
          const links = FY_REPORT_LINKS[d.fiscalYear] ?? { oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" };
          return (
            <Card key={d.fiscalYear} className="p-4">
              <div className="flex items-center justify-between">
                <p className="font-display text-xl">FY {d.fiscalYear}</p>
                <div className="flex gap-2 text-[11px]">
                  <a className="text-ke-green underline" href={links.oag} target="_blank" rel="noreferrer">OAG audits ↗</a>
                  <a className="text-ke-green underline" href={links.cob} target="_blank" rel="noreferrer">CoB BIRR ↗</a>
                </div>
              </div>
              <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                <dt className="text-muted-foreground">Equitable share</dt><dd className="text-right">{d.equitableShareB != null ? `Kshs ${d.equitableShareB}B` : "N/A"}</dd>
                <dt className="text-muted-foreground">County budgets</dt><dd className="text-right">{d.countyBudgetB != null ? `Kshs ${d.countyBudgetB}B` : "N/A"}</dd>
                <dt className="text-muted-foreground">Spent</dt><dd className="text-right">{d.expenditureB != null ? `Kshs ${d.expenditureB}B` : "N/A"}</dd>
                <dt className="text-muted-foreground">Absorption</dt><dd className="text-right">{d.overallAbsorptionPct != null ? `${d.overallAbsorptionPct}%` : "N/A"}</dd>
                <dt className="text-muted-foreground">Dev. absorption</dt><dd className="text-right">{d.developmentAbsorptionPct != null ? `${d.developmentAbsorptionPct}%` : "N/A"}</dd>
                <dt className="text-muted-foreground">OSR collected</dt><dd className="text-right">{d.osrCollectedB != null ? `Kshs ${d.osrCollectedB}B` : "N/A"}</dd>
                <dt className="text-muted-foreground">Audit opinions U/Q/A/D</dt>
                <dd className="text-right">{d.auditUnmodified != null ? `${d.auditUnmodified}/${d.auditQualified ?? "?"}/${d.auditAdverse ?? "?"}/${d.auditDisclaimer ?? "?"}` : "N/A"}</dd>
              </dl>
              <p className="mt-2 text-[10px] text-muted-foreground">{d.source}</p>
            </Card>
          );
        })}
      </div>
      <Card className="p-4 text-xs text-muted-foreground">
        Same data over the API: <code>node kenya-county-data/backend/seed.mjs && node kenya-county-data/backend/server.mjs</code> → <code>GET /api/devolution</code>, <code>GET /api/reports</code>, <code>GET /api/finance?fy=2016/17&format=csv</code>
      </Card>
    </div>
  );
}

export function OversightPage({ section }: { section: string }) {
  if (section === "archive") return <ArchivePage />;
  const data = OVERSIGHT[section] ?? OVERSIGHT["pending-bills"];
  const max = useMemo(() => {
    if (section !== "pending-bills") return 1;
    return Math.max(...effectiveCountyFinance().map((c) => c.pendingBills || 0), 1);
  }, [section]);
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">{data.title}</h1>
      <p className="max-w-3xl text-sm text-muted-foreground">{data.body}</p>
      {data.rows.length === 0 && <DataGap />}
      <div className="space-y-2">
        {data.rows.map((r) => (
          <div key={r.label} className="rounded-xl border border-border bg-card p-3">
            <div className="flex items-center justify-between gap-3 text-sm">
              {r.href ? (
                <a href={r.href} target="_blank" rel="noreferrer" className="font-medium text-ke-green underline">
                  {r.label}
                </a>
              ) : (
                <span className="font-medium">{r.label}</span>
              )}
              <span>{r.value}</span>
            </div>
            {section === "pending-bills" && (
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-ke-red" style={{ width: `${((effectiveCountyFinance().find((c) => c.countyName === r.label)?.pendingBills || 0) / max) * 100}%` }} />
              </div>
            )}
            <p className="mt-1 text-[11px] text-muted-foreground">{r.note}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export { getCounty };
