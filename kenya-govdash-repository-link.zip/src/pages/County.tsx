import { Mail, Phone, Globe, ArrowLeft, MapPin, AtSign } from "lucide-react";
import { getCounty, flattenCounty, getPerson } from "../data/counties";
import { getCountyFinance, getCountyTimeSeries } from "../data/finance";
import { formatKesMillions, formatPct, formatPopulation } from "../lib/format";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { AuditBadge, Avatar, Badge, Card, CoalitionBadge, DataGap, PersonRow, ScoreRing, SectionTitle, StatCard } from "../components/ui";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { ReactNode } from "react";
import { DOMAIN_LABELS, getDomain, domainMeta, type DomainKey } from "../data/domains";

function DomainPanel({ countyName, domainKey }: { countyName: string; domainKey: DomainKey }) {
  const data = getDomain<Record<string, unknown>>(domainKey, countyName);
  const meta = domainMeta(domainKey);
  const entries = data ? Object.entries(data).filter(([k, v]) => k !== "countyCode" && v !== null && v !== false) : [];
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="font-medium">{DOMAIN_LABELS[domainKey]}</p>
        {data?.dataAvailable === false ? <Badge className="border-amber-300 bg-amber-50 text-amber-800">pending ingest</Badge> : <Badge className="border-emerald-300 bg-emerald-50 text-emerald-800">published</Badge>}
      </div>
      {entries.length > 0 ? (
        <dl className="mt-2 space-y-1 text-xs">
          {entries.slice(0, 4).map(([k, v]) => (
            <div key={k} className="flex justify-between gap-2">
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="text-right font-medium">{typeof v === "object" ? (v as { name?: string }).name ?? JSON.stringify(v) : String(v)}</dd>
            </div>
          ))}
        </dl>
      ) : (
        <p className="mt-2 text-xs text-muted-foreground">No published fields in this extract — N/A, not estimated.</p>
      )}
      <p className="mt-2 text-[10px] text-muted-foreground">{meta.source}</p>
    </Card>
  );
}

export function CountyPage({ code }: { code: string }) {
  const { countyName } = useLanguage();
  const { navigate } = useRouter();
  const county = getCounty(Number(code));
  if (!county) {
    return (
      <div className="p-8 text-center">
        <p className="font-display text-2xl">County not found</p>
        <button className="mt-3 underline" onClick={() => navigate("home")}>
          Back home
        </button>
      </div>
    );
  }
  const fin = getCountyFinance(county.name);
  const series = getCountyTimeSeries(county.name);
  const people = flattenCounty(county);
  const leaders = [county.governor, county.deputyGovernor, county.senator, county.womanRep].filter(Boolean);

  return (
    <div className="space-y-6">
      <button onClick={() => navigate("home")} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All counties
      </button>
      <div className="relative overflow-hidden rounded-3xl border border-border">
        <img src="/images/county-assembly.jpg" alt="" className="h-48 w-full object-cover sm:h-56" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/10" />
        <div className="absolute bottom-0 p-6 text-white">
          <p className="text-[11px] uppercase tracking-[0.2em] text-ke-gold">
            County {String(county.code).padStart(3, "0")} · {county.region}
          </p>
          <h1 className="font-display text-4xl">{countyName(county.name)} County</h1>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Population" value={formatPopulation(county.population)} hint="KNBS 2019 Census" />
        <StatCard label="Land area" value={`${Math.round(county.area).toLocaleString()} km²`} hint={`Density ${county.density.toLocaleString()}/km²`} />
        <StatCard label="Absorption FY23/24" value={formatPct(fin?.overallAbsorption)} hint={fin ? "CoB CG-BIRR" : "Not in published extract"} />
        <StatCard label="CoG compliance" value={fin?.complianceScore != null ? String(fin.complianceScore) : "N/A"} hint={fin?.auditOpinion ?? "Audit N/A"} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <SectionTitle kicker="Executive" title="County leadership" />
          <div className="grid gap-3 sm:grid-cols-2">
            {leaders.map((p) => (
              <button
                key={p!.id}
                onClick={() => navigate("rep", { id: p!.id })}
                className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:bg-muted/60"
              >
                <Avatar name={p!.name} size="lg" />
                <div>
                  <p className="font-medium">{p!.name}</p>
                  <p className="text-xs text-muted-foreground">{p!.title}</p>
                  <div className="mt-1 flex gap-1">
                    <CoalitionBadge coalition={p!.coalition} />
                  </div>
                </div>
              </button>
            ))}
          </div>
          {!county.senator && (
            <div className="mt-3">
              <DataGap note="Senator / Woman Rep records for this county are not yet attached from Parliament of Kenya extracts." />
            </div>
          )}
        </Card>
        <Card className="flex flex-col items-center justify-center p-5">
          <ScoreRing score={fin?.complianceScore ?? null} size={120} label="CoG score" />
          <div className="mt-3">{fin ? <AuditBadge opinion={fin.auditOpinion} /> : <span className="text-xs text-muted-foreground">Audit N/A</span>}</div>
          <p className="mt-2 text-center text-xs text-muted-foreground">{fin?.source ?? "Finance snapshot not in current CoB extract"}</p>
        </Card>
      </div>

      {fin && (
        <Card className="p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <SectionTitle kicker="Finance" title={`FY ${fin.fiscalYear} snapshot`} />
            <button onClick={() => navigate("finance-county", { name: county.name })} className="text-sm text-ke-green underline">
              Open finance drill-down
            </button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Approved budget" value={formatKesMillions(fin.approvedBudget)} />
            <StatCard label="Equitable share" value={formatKesMillions(fin.equitableShare)} />
            <StatCard label="OSR collected" value={formatKesMillions(fin.ownSourceRevenue)} hint={`Target ${formatKesMillions(fin.osrTarget)}`} />
            <StatCard label="Pending bills" value={formatKesMillions(fin.pendingBills)} tone="red" />
          </div>
          {series.length > 1 && (
            <div className="mt-6 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={series}>
                  <XAxis dataKey="fiscalYear" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="overallAbsorption" name="Overall %" stroke="#006b3f" strokeWidth={2} />
                  <Line type="monotone" dataKey="developmentAbsorption" name="Development %" stroke="#bb0000" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
          {fin.notes && <p className="mt-3 text-sm text-muted-foreground">{fin.notes}</p>}
        </Card>
      )}

      <section>
        <SectionTitle kicker="kenya-county-data" title="County data domains" action={<span className="text-xs text-muted-foreground">JSON + API: kenya-county-data/</span>} />
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {(Object.keys(DOMAIN_LABELS) as DomainKey[]).map((k) => (
            <DomainPanel key={k} countyName={county.name} domainKey={k} />
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="National Assembly" title={`Constituency MPs (${county.mps.length})`} />
          {county.mps.length === 0 ? (
            <DataGap note="Constituency MP list for this county is not yet ingested from parliament.go.ke." />
          ) : (
            county.mps.map((mp) => (
              <PersonRow key={mp.id} person={mp} onClick={() => navigate("rep", { id: mp.id })} extra={<CoalitionBadge coalition={mp.coalition} />} />
            ))
          )}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="County executive" title={`CECMs (${county.cecms.filter((c) => c.verified).length} verified / ${county.cecms.length})`} />
          <div className="max-h-[420px] overflow-y-auto">
            {county.cecms.map((c) => (
              <PersonRow
                key={c.id}
                person={c}
                onClick={() => navigate("rep", { id: c.id })}
                extra={c.verified ? <span className="text-[10px] text-emerald-600">Verified</span> : <span className="text-[10px] text-muted-foreground">Unverified</span>}
              />
            ))}
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="Directory" title={`All ${people.length} attached officials`} />
        <p className="mb-3 flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3" /> {countyName(county.name)} · term 2022–2027
        </p>
        <div className="grid gap-2 sm:grid-cols-2">
          {people.map((p) => (
            <PersonRow key={p.id} person={p} onClick={() => navigate("rep", { id: p.id })} />
          ))}
        </div>
      </Card>
    </div>
  );
}

export function RepPage({ id }: { id: string }) {
  const { navigate } = useRouter();
  const person = getPerson(id);
  if (!person) {
    return (
      <div className="p-8 text-center">
        <p className="font-display text-2xl">Official not found</p>
        <button className="mt-3 underline" onClick={() => navigate("reps")}>
          Back to directory
        </button>
      </div>
    );
  }
  const county = person.countyCode ? getCounty(person.countyCode) : undefined;
  const fin = county ? getCountyFinance(county.name) : undefined;
  const metrics = [
    { label: "Overall accountability", score: fin?.complianceScore ?? null },
    { label: "Budget absorption", score: fin?.overallAbsorption ?? null },
    { label: "Development delivery", score: fin?.developmentAbsorption ?? null },
    { label: "OSR performance", score: fin && fin.osrTarget ? Math.round(((fin.ownSourceRevenue || 0) / fin.osrTarget) * 100) : null },
    { label: "Manifesto fulfillment", score: null },
    { label: "Legislative oversight", score: null },
    { label: "Public sentiment", score: null },
  ];

  return (
    <div className="space-y-6">
      <button onClick={() => navigate("reps")} className="inline-flex items-center gap-1 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Directory
      </button>
      <Card className="p-6">
        <div className="flex flex-col gap-5 sm:flex-row">
          <Avatar name={person.name} size="xl" />
          <div className="flex-1">
            <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{person.level}</p>
            <h1 className="font-display text-3xl">{person.name}</h1>
            <p className="text-muted-foreground">{person.title}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              <CoalitionBadge coalition={person.coalition} />
              {person.party && <span className="rounded-full border border-border px-2 py-0.5 text-[11px]">{person.party}</span>}
              <span className="rounded-full border border-border px-2 py-0.5 text-[11px]">
                {person.termStart.slice(0, 4)}–{person.termEnd.slice(0, 4)}
              </span>
            </div>
            {person.bio ? (
              <p className="mt-4 text-sm leading-relaxed">{person.bio}</p>
            ) : (
              <div className="mt-4">
                <DataGap note="No citable biography attached. Official county/Parliament bio not ingested." />
              </div>
            )}
            {person.bioSource && <p className="mt-1 text-[11px] text-muted-foreground">Source: {person.bioSource}</p>}
          </div>
        </div>
        <div className="mt-5 grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
          <Contact icon={<Mail className="h-4 w-4" />} label="Email" value={person.email} />
          <Contact icon={<Phone className="h-4 w-4" />} label="Phone" value={person.phone} />
          <Contact icon={<AtSign className="h-4 w-4" />} label="Twitter / X" value={person.twitter} />
          <Contact icon={<Globe className="h-4 w-4" />} label="Website" value={person.website} />
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <SectionTitle kicker="Scorecard" title="Accountability metrics" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {metrics.map((m) => (
              <ScoreRing key={m.label} score={m.score} label={m.label} />
            ))}
          </div>
          <div className="mt-4">
            <DataGap note="Manifesto, ethics and sentiment scores are unpublished in TI-Kenya CGSR extracts used here — shown as N/A." />
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="County link" title="Jurisdiction" />
          <p className="text-sm">{person.jurisdiction}</p>
          {county && (
            <button onClick={() => navigate("county", { code: String(county.code) })} className="mt-3 w-full rounded-xl bg-ke-green py-2 text-sm text-white">
              Open {county.name} County
            </button>
          )}
          {fin && county && (
            <button onClick={() => navigate("finance-county", { name: county.name })} className="mt-2 w-full rounded-xl border border-border py-2 text-sm">
              County finance
            </button>
          )}
          {fin && (
            <div className="mt-4 space-y-2 text-sm">
              <div>
                Audit: <AuditBadge opinion={fin.auditOpinion} />
              </div>
              <p>Absorption: {formatPct(fin.overallAbsorption)}</p>
              <p>Pending bills: {formatKesMillions(fin.pendingBills)}</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function Contact({ icon, label, value }: { icon: ReactNode; label: string; value?: string | null }) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-border px-3 py-2">
      {icon}
      <div>
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
        <p>{value ?? "N/A"}</p>
      </div>
    </div>
  );
}
