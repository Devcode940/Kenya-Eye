import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Bell, Download } from "lucide-react";
import { NATIONAL_FINANCE, getCountyFinance, getCountyTimeSeries, linearForecast, SOURCES, AUDIT_SUMMARY, COUNTY_PENDING_TOTALS, HIGHLIGHTS_2425_9M, getAggregateFrom, DEVOLUTION_HISTORY } from "../data/finance";
import { COUNTIES } from "../data/counties";
import { effectiveCountyFinance, addAlert, getAlerts } from "../data/store";
import { formatKesMillions, formatPct, auditBg } from "../lib/format";
import { useRouter } from "../lib/router";
import { AuditBadge, Card, DataGap, SectionTitle, StatCard } from "../components/ui";
import type { AuditOpinion } from "../lib/types";

export function FinancePage() {
  const { navigate } = useRouter();
  const eff = effectiveCountyFinance();
  const agg = getAggregateFrom(eff);
  const national = NATIONAL_FINANCE.find((n) => n.fiscalYear === "2023/24")!;
  const latest = NATIONAL_FINANCE[0];
  const [email, setEmail] = useState("");
  const [alertCounty, setAlertCounty] = useState("Nairobi City");
  const [threshold, setThreshold] = useState("70");
  const [subscribed, setSubscribed] = useState("");

  const auditData = (["Unmodified", "Qualified", "Adverse", "Disclaimer"] as AuditOpinion[]).map((k) => ({
    name: k,
    count: agg.auditOpinionCounts[k] || 0,
  }));

  const trend = NATIONAL_FINANCE.slice().reverse().map((n) => ({
    fy: n.fiscalYear,
    overall: n.overallAbsorption,
    development: n.developmentAbsorption,
    recurrent: n.recurrentAbsorption,
  }));

  const pendingMax = Math.max(...eff.map((r) => r.pendingBills || 0), 1);

  const radarCounties = ["Nyeri", "Nairobi City", "Kilifi"];
  const radarData = ["overallAbsorption", "developmentAbsorption", "complianceScore", "recurrentAbsorption"].map((key) => {
    const row: Record<string, string | number> = {
      metric: key === "overallAbsorption" ? "Overall %" : key === "developmentAbsorption" ? "Dev %" : key === "complianceScore" ? "CoG" : "Recurrent %",
    };
    radarCounties.forEach((c) => {
      const rec = getCountyFinance(c);
      row[c] = (rec as unknown as Record<string, number | undefined>)?.[key] ?? 0;
    });
    return row;
  });

  const forecast = linearForecast(NATIONAL_FINANCE.slice().reverse().map((n) => n.overallAbsorption));

  function exportCsv() {
    const header = "county,fy,approvedBudget,absorption,audit,compliance,pendingBills\n";
    const rows = eff.map(
      (r) => `${r.countyName},${r.fiscalYear},${r.approvedBudget},${r.overallAbsorption},${r.auditOpinion},${r.complianceScore},${r.pendingBills}`,
    ).join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "kenya-govdash-finance-2023-24.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Controller of Budget · OAG · CoG</p>
        <h1 className="font-display text-3xl sm:text-4xl">Finance & Audit Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">National + county snapshots for FY 2021/22 → 2023/24. Amounts in Kshs millions unless noted.</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label={`County spend FY ${latest.fiscalYear}`} value={formatKesMillions(latest.actualExpenditure)} hint={`of ${formatKesMillions(latest.approvedBudget)} approved · ${formatPct(latest.overallAbsorption)} absorbed · dev ${formatPct(latest.developmentAbsorption)}`} />
        <StatCard label="National budget FY23/24" value={formatKesMillions(national.approvedBudget)} hint={`Spent ${formatKesMillions(national.actualExpenditure)} · linear forecast ${forecast ?? "N/A"}%`} tone="green" />
        <StatCard label="Public debt FY23/24" value={formatKesMillions(national.totalDebt)} hint="National Treasury / OAG" tone="gold" />
        <StatCard label="County trade payables" value={formatKesMillions(COUNTY_PENDING_TOTALS.totalTradePayables)} hint={`Nairobi ${formatKesMillions(COUNTY_PENDING_TOTALS.nairobiShare)} (~50%) · CoB`} tone="red" />
      </div>

      <Card className="p-5">
        <SectionTitle kicker="OAG · published" title="Audit opinions — official summaries" />
        <div className="grid gap-3 sm:grid-cols-3 text-sm">
          <div className="rounded-xl border border-border p-3">
            <p className="font-semibold">County executives FY 2023/24</p>
            <p className="mt-1 font-display text-3xl">0 / 47 clean</p>
            <p className="mt-1 text-xs text-muted-foreground">{AUDIT_SUMMARY.countyExecutivesFY2324.note}</p>
          </div>
          <div className="rounded-xl border border-border p-3">
            <p className="font-semibold">County assemblies FY 2023/24</p>
            <p className="mt-1 font-display text-3xl">8 clean</p>
            <p className="mt-1 text-xs text-muted-foreground">{AUDIT_SUMMARY.countyAssembliesFY2324.note}</p>
          </div>
          <div className="rounded-xl border border-border p-3">
            <p className="font-semibold">County revenue funds FY 2022/23 (46 CRFs)</p>
            <p className="mt-1 font-display text-3xl">46% · 43% · 11%</p>
            <p className="mt-1 text-xs text-muted-foreground">Unmodified · qualified · adverse (0 disclaimers). {AUDIT_SUMMARY.revenueFundsFY2223.source}</p>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="CoB 9M FY 2024/25" title="Highest overall absorption" />
          {HIGHLIGHTS_2425_9M.highestOverall.map(([n, v]) => (
            <div key={n} className="flex items-center gap-3 py-1.5 text-sm">
              <span className="w-28">{n}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-ke-green" style={{ width: `${v}%` }} />
              </div>
              <span className="w-10 text-right font-medium">{v}%</span>
            </div>
          ))}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="CoB 9M FY 2024/25" title="Lowest overall absorption" />
          {HIGHLIGHTS_2425_9M.lowestOverall.map(([n, v]) => (
            <div key={n} className="flex items-center gap-3 py-1.5 text-sm">
              <span className="w-28">{n}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-ke-red" style={{ width: `${v}%` }} />
              </div>
              <span className="w-10 text-right font-medium">{v}%</span>
            </div>
          ))}
          <p className="mt-2 text-[11px] text-muted-foreground">{HIGHLIGHTS_2425_9M.source}</p>
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="Pending bills" title="County pending bills — FY 2023/24 extract (top 10)" />
        <div className="space-y-2">
          {eff
            .slice()
            .sort((a, b) => (b.pendingBills || 0) - (a.pendingBills || 0))
            .slice(0, 10)
            .map((r) => (
              <div key={r.countyName} className="flex items-center gap-3 text-sm">
                <span className="w-32 truncate">{r.countyName}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div className="h-full bg-ke-red" style={{ width: `${((r.pendingBills || 0) / pendingMax) * 100}%` }} />
                </div>
                <span className="w-24 text-right">{formatKesMillions(r.pendingBills)}</span>
              </div>
            ))}
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Since devolution · 2013/14 → 2024/25" title="County governments in aggregate — 12 years" />
        <p className="mb-3 text-xs text-muted-foreground">
          First county governments took office April 2013. Bars: equitable share to the 47 counties (Kshs B, left axis). Line: aggregate budget absorption % (right axis). Years without a published figure are simply absent from the line — not interpolated.
        </p>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={DEVOLUTION_HISTORY}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="fiscalYear" tick={{ fontSize: 10 }} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} label={{ value: "Kshs B", angle: -90, position: "insideLeft", fontSize: 10 }} />
              <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 11 }} label={{ value: "absorption %", angle: 90, position: "insideRight", fontSize: 10 }} />
              <Tooltip />
              <Legend />
              <Bar yAxisId="left" dataKey="equitableShareB" name="Equitable share (Kshs B)" fill="#c5a572" radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="overallAbsorptionPct" name="Overall absorption %" stroke="#006b3f" strokeWidth={2.5} connectNulls />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-xs">
            <thead className="uppercase tracking-wider text-muted-foreground">
              <tr>
                {["FY", "Equitable share", "County budget", "Spent", "Absorption", "Dev. absorption", "OSR collected", "Audit (U/Q/A/D)"].map((h) => (
                  <th key={h} className="px-2 py-1 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {DEVOLUTION_HISTORY.map((d) => (
                <tr key={d.fiscalYear} className="border-t border-border">
                  <td className="px-2 py-1 font-medium">{d.fiscalYear}</td>
                  <td className="px-2 py-1">{d.equitableShareB != null ? `Kshs ${d.equitableShareB}B` : "N/A"}</td>
                  <td className="px-2 py-1">{d.countyBudgetB != null ? `Kshs ${d.countyBudgetB}B` : "N/A"}</td>
                  <td className="px-2 py-1">{d.expenditureB != null ? `Kshs ${d.expenditureB}B` : "N/A"}</td>
                  <td className="px-2 py-1">{d.overallAbsorptionPct != null ? `${d.overallAbsorptionPct}%` : "N/A"}</td>
                  <td className="px-2 py-1">{d.developmentAbsorptionPct != null ? `${d.developmentAbsorptionPct}%` : "N/A"}</td>
                  <td className="px-2 py-1">{d.osrCollectedB != null ? `Kshs ${d.osrCollectedB}B` : "N/A"}</td>
                  <td className="px-2 py-1">{d.auditUnmodified != null ? `${d.auditUnmodified}/${d.auditQualified ?? "?"}/${d.auditAdverse ?? "?"}/${d.auditDisclaimer ?? "?"}` : "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">
          Sources: CoB annual CG-BIRRs FY 2013/14–2024/25; CRA equitable-share tables; OAG Green Books &amp; County Audit Fiduciary Risks Report. Audit columns = opinions on the 47 county governments where published (2023/24 and 2024/25 show county executives only).
        </p>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="Trends" title="National absorption — 3 years" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="fy" />
                <YAxis domain={[70, 100]} />
                <Tooltip />
                <Legend />
                <Line dataKey="overall" name="Overall" stroke="#006b3f" strokeWidth={2} />
                <Line dataKey="recurrent" name="Recurrent" stroke="#c5a572" strokeWidth={2} />
                <Line dataKey="development" name="Development" stroke="#bb0000" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Audit" title="County audit opinion distribution" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={auditData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#0f3d2e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Among {agg.count} counties with a published FY 2023/24 extract. Remaining counties: N/A.</p>
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="Radar" title="Nyeri · Nairobi · Kilifi — 4 metrics" />
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="metric" />
              <PolarRadiusAxis domain={[0, 100]} />
              <Radar name="Nyeri" dataKey="Nyeri" stroke="#006b3f" fill="#006b3f" fillOpacity={0.25} />
              <Radar name="Nairobi City" dataKey="Nairobi City" stroke="#bb0000" fill="#bb0000" fillOpacity={0.2} />
              <Radar name="Kilifi" dataKey="Kilifi" stroke="#c5a572" fill="#c5a572" fillOpacity={0.2} />
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="CoG" title="Top 5 — compliance score" />
          {agg.topPerformers.map((r, i) => (
            <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="flex w-full items-center gap-3 py-2 text-left hover:bg-muted/50">
              <span className="w-6 font-display text-lg">{i + 1}</span>
              <span className="flex-1">{r.countyName}</span>
              <AuditBadge opinion={r.auditOpinion} />
              <span className="w-10 text-right font-semibold">{r.complianceScore}</span>
            </button>
          ))}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Intervention" title="Bottom 5 — needs attention" />
          {agg.bottomPerformers.map((r, i) => (
            <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="flex w-full items-center gap-3 py-2 text-left hover:bg-muted/50">
              <span className="w-6 font-display text-lg">{i + 1}</span>
              <span className="flex-1">{r.countyName}</span>
              <AuditBadge opinion={r.auditOpinion} />
              <span className="w-10 text-right font-semibold">{r.complianceScore}</span>
            </button>
          ))}
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between p-5">
          <SectionTitle kicker="Table" title="County-level finance detail" />
          <button onClick={exportCsv} className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs">
            <Download className="h-3.5 w-3.5" /> CSV
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="bg-muted/60 text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                {["County", "Budget", "OSR", "Absorption", "Dev %", "Pending", "Audit", "CoG"].map((h) => (
                  <th key={h} className="px-4 py-2 font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {eff.slice()
                .sort((a, b) => a.countyName.localeCompare(b.countyName))
                .map((r) => (
                  <tr key={r.countyName} className="cursor-pointer border-t border-border hover:bg-muted/40" onClick={() => navigate("finance-county", { name: r.countyName })}>
                    <td className="px-4 py-2 font-medium">{r.countyName}</td>
                    <td className="px-4 py-2">{formatKesMillions(r.approvedBudget)}</td>
                    <td className="px-4 py-2">{formatKesMillions(r.ownSourceRevenue)}</td>
                    <td className="px-4 py-2">{formatPct(r.overallAbsorption)}</td>
                    <td className="px-4 py-2">{formatPct(r.developmentAbsorption)}</td>
                    <td className="px-4 py-2">{formatKesMillions(r.pendingBills)}</td>
                    <td className="px-4 py-2">
                      <span className={`rounded-full border px-2 py-0.5 text-[11px] ${auditBg(r.auditOpinion)}`}>{r.auditOpinion}</span>
                    </td>
                    <td className="px-4 py-2">{r.complianceScore ?? "—"}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        <div className="p-4">
          <DataGap note={`${47 - eff.length} counties have no FY 2023/24 row in this extract and are omitted rather than filled with estimates.`} />
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Alerts" title="Subscribe to finance alerts" />
        <p className="mb-3 text-sm text-muted-foreground">{getAlerts().length} active alert(s) in this browser. Production GovDash emails via Resend.</p>
        <form
          className="grid gap-3 sm:grid-cols-4"
          onSubmit={(e) => {
            e.preventDefault();
            addAlert({ email, county: alertCounty, metric: "overallAbsorption", threshold: Number(threshold) });
            setSubscribed(`Alert saved for ${alertCounty} below ${threshold}% absorption.`);
          }}
        >
          <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="h-10 rounded-xl border border-border bg-background px-3 text-sm" />
          <select value={alertCounty} onChange={(e) => setAlertCounty(e.target.value)} className="h-10 rounded-xl border border-border bg-background px-3 text-sm">
            {COUNTIES.map((c) => (
              <option key={c.code}>{c.name}</option>
            ))}
          </select>
          <input type="number" min={0} max={100} value={threshold} onChange={(e) => setThreshold(e.target.value)} className="h-10 rounded-xl border border-border bg-background px-3 text-sm" />
          <button className="inline-flex h-10 items-center justify-center gap-1 rounded-xl bg-ke-green text-sm text-white">
            <Bell className="h-4 w-4" /> Create alert
          </button>
        </form>
        {subscribed && <p className="mt-2 text-sm text-emerald-700">{subscribed}</p>}
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Sources" title="Data sources & methodology" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {SOURCES.map((s) => (
            <a key={s.abbr} href={s.url} target="_blank" rel="noreferrer" className="rounded-xl border border-border p-3 hover:bg-muted/50">
              <p className="text-xs font-semibold uppercase tracking-wider text-ke-green">{s.abbr}</p>
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-muted-foreground">{s.data}</p>
            </a>
          ))}
        </div>
      </Card>
    </div>
  );
}

export function FinanceCountyPage({ name }: { name: string }) {
  const { navigate } = useRouter();
  const rec = getCountyFinance(name);
  const series = getCountyTimeSeries(name);
  const county = COUNTIES.find((c) => c.name.toLowerCase() === name.toLowerCase());
  const forecast = linearForecast(series.map((s) => s.overallAbsorption || 0));

  if (!rec) {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">{name}</h1>
        <DataGap note="No CoB/OAG finance extract is attached for this county. Fields are N/A rather than estimated." />
        {county && (
          <button className="rounded-full bg-ke-green px-4 py-2 text-sm text-white" onClick={() => navigate("county", { code: String(county.code) })}>
            Open county profile
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <button onClick={() => navigate("finance")} className="text-sm text-muted-foreground underline">
        ← All finance
      </button>
      <h1 className="font-display text-3xl">{rec.countyName} — finance drill-down</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Approved budget" value={formatKesMillions(rec.approvedBudget)} />
        <StatCard label="Actual expenditure" value={formatKesMillions(rec.actualExpenditure)} />
        <StatCard label="Overall absorption" value={formatPct(rec.overallAbsorption)} hint={forecast != null ? `Linear forecast ${forecast}%` : undefined} />
        <StatCard label="Pending bills" value={formatKesMillions(rec.pendingBills)} tone="red" />
      </div>
      {series.length > 0 && (
        <Card className="p-5">
          <SectionTitle title="Absorption time series" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="fiscalYear" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line dataKey="overallAbsorption" name="Overall" stroke="#006b3f" />
                <Line dataKey="developmentAbsorption" name="Development" stroke="#bb0000" />
                <Line dataKey="recurrentAbsorption" name="Recurrent" stroke="#c5a572" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}
      <Card className="p-5 text-sm leading-relaxed">
        <p>
          Audit opinion: <AuditBadge opinion={rec.auditOpinion} />
        </p>
        <p className="mt-2">Source: {rec.source}</p>
        {rec.notes && <p className="mt-2">{rec.notes}</p>}
        {county && (
          <button className="mt-4 rounded-full bg-ke-green px-4 py-2 text-white" onClick={() => navigate("county", { code: String(county.code) })}>
            County profile
          </button>
        )}
      </Card>
    </div>
  );
}

export function ComparePage() {
  const eff = effectiveCountyFinance();
  const [selected, setSelected] = useState<string[]>(["Nyeri", "Kisumu", "Nairobi City"]);
  const options = eff.map((c) => c.countyName);
  const records = selected.map((n) => eff.find((c) => c.countyName === n)).filter(Boolean);

  const radar = ["overallAbsorption", "developmentAbsorption", "complianceScore", "recurrentAbsorption"].map((key) => {
    const row: Record<string, string | number> = {
      metric: key.replace(/([A-Z])/g, " $1"),
    };
    selected.forEach((c) => {
      const rec = eff.find((x) => x.countyName === c);
      row[c] = (rec as unknown as Record<string, number | undefined>)?.[key] ?? 0;
    });
    return row;
  });

  const colors = ["#006b3f", "#bb0000", "#c5a572", "#1d4ed8", "#7c3aed"];

  function toggle(name: string) {
    setSelected((prev) => {
      if (prev.includes(name)) return prev.filter((p) => p !== name);
      if (prev.length >= 5) return prev;
      return [...prev, name];
    });
  }

  function exportCsv() {
    const header = "county,budget,absorption,dev,compliance,audit,pending\n";
    const rows = records
      .map((r) => `${r!.countyName},${r!.approvedBudget},${r!.overallAbsorption},${r!.developmentAbsorption},${r!.complianceScore},${r!.auditOpinion},${r!.pendingBills}`)
      .join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "county-compare.csv";
    a.click();
  }

  const memoOptions = useMemo(() => options, [options]);

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">County comparison</h1>
      <p className="text-sm text-muted-foreground">Select 2–5 counties that have published CoB FY 2023/24 extracts.</p>
      <div className="flex flex-wrap gap-2">
        {memoOptions.map((n) => (
          <button
            key={n}
            onClick={() => toggle(n)}
            className={`rounded-full border px-3 py-1 text-xs ${selected.includes(n) ? "border-ke-green bg-ke-green text-white" : "border-border"}`}
          >
            {n}
          </button>
        ))}
      </div>
      <Card className="p-5">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radar}>
              <PolarGrid />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} />
              {selected.map((c, i) => (
                <Radar key={c} name={c} dataKey={c} stroke={colors[i]} fill={colors[i]} fillOpacity={0.15} />
              ))}
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              {["County", "Budget", "Absorption", "Dev %", "CoG", "Audit", "Pending"].map((h) => (
                <th key={h} className="px-3 py-2">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r!.countyName} className="border-t border-border">
                <td className="px-3 py-2 font-medium">{r!.countyName}</td>
                <td className="px-3 py-2">{formatKesMillions(r!.approvedBudget)}</td>
                <td className="px-3 py-2">{formatPct(r!.overallAbsorption)}</td>
                <td className="px-3 py-2">{formatPct(r!.developmentAbsorption)}</td>
                <td className="px-3 py-2">{r!.complianceScore}</td>
                <td className="px-3 py-2">
                  <AuditBadge opinion={r!.auditOpinion} />
                </td>
                <td className="px-3 py-2">{formatKesMillions(r!.pendingBills)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button onClick={exportCsv} className="rounded-full border border-border px-4 py-2 text-sm">
        Export CSV
      </button>
    </div>
  );
}
