import { useMemo, useState } from "react";
import { allRepresentatives, COUNTIES } from "../data/counties";
import { useRouter } from "../lib/router";
import { Avatar, Card, CoalitionBadge } from "../components/ui";
import type { Coalition, Level } from "../lib/types";

export function RepsPage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<Level | "All">("All");
  const [coalition, setCoalition] = useState<Coalition | "All">("All");
  const [county, setCounty] = useState("All");
  const [page, setPage] = useState(0);
  const pageSize = 30;

  const all = useMemo(() => allRepresentatives(), []);
  const filtered = useMemo(() => {
    return all.filter((p) => {
      if (level !== "All" && p.level !== level) return false;
      if (coalition !== "All" && p.coalition !== coalition) return false;
      if (county !== "All" && p.countyCode !== Number(county)) return false;
      if (q) {
        const s = `${p.name} ${p.title} ${p.party} ${p.jurisdiction}`.toLowerCase();
        if (!s.includes(q.toLowerCase())) return false;
      }
      return true;
    });
  }, [all, q, level, coalition, county]);

  const slice = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));

  const governors = all.filter((p) => p.title.startsWith("Governor")).length;
  const senators = all.filter((p) => p.title.startsWith("Senator")).length;
  const wrs = all.filter((p) => p.title.startsWith("Woman")).length;
  const mps = all.filter((p) => p.level === "Constituency").length;
  const cecms = all.filter((p) => p.title.startsWith("CECM")).length;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Parliament · Counties · IEBC 2022</p>
        <h1 className="font-display text-3xl sm:text-4xl">Representatives directory</h1>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        {[
          ["Governors", governors],
          ["Senators", senators],
          ["Women Reps", wrs],
          ["MPs (attached)", mps],
          ["CECMs", cecms],
        ].map(([l, v]) => (
          <Card key={String(l)} className="p-3 text-center">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{l}</p>
            <p className="font-display text-2xl">{v}</p>
          </Card>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(0);
          }}
          placeholder="Search by name, county, or party…"
          className="h-10 min-w-[200px] flex-1 rounded-full border border-border bg-card px-4 text-sm"
        />
        <select
          value={level}
          onChange={(e) => {
            setLevel(e.target.value as Level | "All");
            setPage(0);
          }}
          className="h-10 rounded-full border border-border bg-card px-3 text-sm"
        >
          <option value="All">All levels</option>
          <option>National</option>
          <option>County</option>
          <option>Constituency</option>
        </select>
        <select
          value={coalition}
          onChange={(e) => {
            setCoalition(e.target.value as Coalition | "All");
            setPage(0);
          }}
          className="h-10 rounded-full border border-border bg-card px-3 text-sm"
        >
          <option value="All">All coalitions</option>
          <option>Kenya Kwanza</option>
          <option>Azimio</option>
          <option>Independent</option>
          <option>Other</option>
        </select>
        <select
          value={county}
          onChange={(e) => {
            setCounty(e.target.value);
            setPage(0);
          }}
          className="h-10 rounded-full border border-border bg-card px-3 text-sm"
        >
          <option value="All">All counties</option>
          {COUNTIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      <p className="text-xs text-muted-foreground">{filtered.length} representatives · page {page + 1} / {pages}</p>
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {slice.map((p) => (
          <button
            key={p.id}
            onClick={() => navigate("rep", { id: p.id })}
            className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 text-left hover:shadow-md"
          >
            <Avatar name={p.name} />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{p.name}</p>
              <p className="truncate text-xs text-muted-foreground">{p.title}</p>
              <div className="mt-1">
                <CoalitionBadge coalition={p.coalition} />
              </div>
            </div>
          </button>
        ))}
      </div>
      <div className="flex justify-center gap-2">
        <button disabled={page === 0} onClick={() => setPage((p) => p - 1)} className="rounded-full border border-border px-3 py-1 text-sm disabled:opacity-40">
          Prev
        </button>
        <button disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)} className="rounded-full border border-border px-3 py-1 text-sm disabled:opacity-40">
          Next
        </button>
      </div>
    </div>
  );
}
