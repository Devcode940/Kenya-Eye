import { ExternalLink, BookOpen, Terminal } from "lucide-react";
import { COUNTIES } from "../data/counties";
import { SENATE_LEADERSHIP, SENATE_NOMINATED, SENATE_SOURCES } from "../data/senate";
import { coalitionColor, formatPct } from "../lib/format";
import { useRouter } from "../lib/router";
import { Badge, Card, CoalitionBadge, SectionTitle } from "../components/ui";

export function SenatePage() {
  const { navigate } = useRouter();
  const elected = COUNTIES.map((c) => ({ county: c, sen: c.senator! })).filter((x) => x.sen);
  const byParty = (party: string) => elected.filter((x) => x.sen.party === party).length;

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl border border-border">
        <img src="/images/nairobi.jpg" alt="Nairobi" className="h-44 w-full object-cover sm:h-52" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/20" />
        <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-ke-gold">Parliament of Kenya · Upper House</p>
          <h1 className="font-display text-4xl">The Senate — 13th Parliament</h1>
          <p className="mt-1 max-w-2xl text-sm text-white/80">
            67 members: 47 elected (one per county) + 20 nominated (16 women, 2 youth, 2 PWD). Allocates national revenue to counties (Art. 217) and oversees county spending.
          </p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-4 text-center">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Total senators</p>
          <p className="font-display text-3xl">67</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Elected (counties)</p>
          <p className="font-display text-3xl">47</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Nominated</p>
          <p className="font-display text-3xl">20</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">UDA elected</p>
          <p className="font-display text-3xl">{byParty("UDA")}</p>
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="parliament.go.ke" title="House leadership" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {SENATE_LEADERSHIP.map((l) => (
            <div key={l.role} className="rounded-xl border border-border p-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{l.role}</p>
              <p className="mt-1 font-medium">{l.name}</p>
              <Badge className="mt-1 border-border">{l.party}</Badge>
            </div>
          ))}
        </div>
      </Card>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between p-5 pb-0">
          <SectionTitle kicker="IEBC 2022" title="47 elected senators (one per county)" />
          <span className="text-xs text-muted-foreground">ODM {byParty("ODM")} · UDA {byParty("UDA")} · other {47 - byParty("ODM") - byParty("UDA")}</span>
        </div>
        <div className="overflow-x-auto p-5 pt-2">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                {["County", "Senator", "Party", "Coalition", ""].map((h) => (
                  <th key={h} className="px-2 py-2 font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {elected.map(({ county, sen }) => (
                <tr key={county.code} className="border-t border-border">
                  <td className="px-2 py-2 font-medium">
                    <button className="text-ke-green underline" onClick={() => navigate("county", { code: String(county.code) })}>
                      {county.name}
                    </button>
                  </td>
                  <td className="px-2 py-2">
                    <button onClick={() => navigate("rep", { id: sen.id })} className="hover:underline">
                      {sen.name}
                    </button>
                  </td>
                  <td className="px-2 py-2">{sen.party}</td>
                  <td className="px-2 py-2">
                    <CoalitionBadge coalition={sen.coalition} />
                  </td>
                  <td className="px-2 py-2 text-right">
                    <button onClick={() => navigate("rep", { id: sen.id })} className="text-xs text-muted-foreground underline">
                      profile
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="IEBC gazette · Sep 2022" title="20 nominated senators" />
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {SENATE_NOMINATED.map((n) => (
            <div key={n.name} className="rounded-xl border border-border p-3">
              <p className="text-sm font-medium">{n.name}</p>
              <div className="mt-1 flex gap-1">
                <Badge className="border-border">{n.party}</Badge>
                <Badge className={coalitionColor(n.party === "UDA" || n.party === "UDM" || n.party === "Jubilee" ? "Kenya Kwanza" : n.party === "Wiper" || n.party === "ODM" ? "Azimio" : "Other")}>
                  {n.group}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Live data" title="How to get info from the Senate (verified sources)" />
        <div className="space-y-3">
          {SENATE_SOURCES.map((s) => (
            <div key={s.name} className="rounded-xl border border-border p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">{s.name}</p>
                <a href={s.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-ke-green underline">
                  <ExternalLink className="h-3 w-3" /> {s.url.replace(/^https?:\/\//, "")}
                </a>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{s.how}</p>
              <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-muted/70 p-2 font-mono text-[11px] leading-relaxed">
                <Terminal className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {s.curl}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-4 flex items-start gap-2 text-xs text-muted-foreground">
          <BookOpen className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
          Note: parliament.go.ke has no official JSON API for the roster — it is HTML (scrape or use the OpenSanctions ke_senate mirror, refreshed monthly). The Hansard repository (hansardsn.parliament.go.ke) IS a real DSpace REST API. Browser fetches to these domains will hit CORS unless you proxy/build-time ingest — in this app, Senate data is baked in at build time from the verified lists above.
        </p>
      </Card>
    </div>
  );
}

export { formatPct };
