import { useMemo, useState } from "react";
import { MapPin, Users, Landmark, Scale, ArrowRight, Filter } from "lucide-react";
import { COUNTIES, NATIONAL, REGIONS } from "../data/counties";
import { getAggregate, COUNTY_FINANCE } from "../data/finance";
import { formatKesMillions, formatPopulation, coalitionColor } from "../lib/format";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { AuditBadge, Badge, Card, CoalitionBadge, ScoreRing, SectionTitle, StatCard } from "../components/ui";
import type { Coalition, Region } from "../lib/types";

export function HomePage() {
  const { t, countyName } = useLanguage();
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [region, setRegion] = useState<Region | "All">("All");
  const [coalition, setCoalition] = useState<Coalition | "All">("All");
  const agg = getAggregate();

  const filtered = useMemo(() => {
    return COUNTIES.filter((c) => {
      if (region !== "All" && c.region !== region) return false;
      if (coalition !== "All" && c.governor.coalition !== coalition) return false;
      if (q) {
        const s = `${c.name} ${c.governor.name} ${c.governor.party}`.toLowerCase();
        if (!s.includes(q.toLowerCase())) return false;
      }
      return true;
    });
  }, [q, region, coalition]);

  const kk = COUNTIES.filter((c) => c.governor.coalition === "Kenya Kwanza").length;
  const az = COUNTIES.filter((c) => c.governor.coalition === "Azimio").length;

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl border border-border">
        <img src="/images/hero.jpg" alt="Parliament of Kenya" className="h-[340px] w-full object-cover sm:h-[400px]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/55 to-black/20" />
        <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-10">
          <div className="flag-stripe mb-4 h-1 w-28 rounded-full" />
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-ke-gold">{t("app.badge")}</p>
          <h1 className="mt-2 max-w-3xl font-display text-3xl font-semibold leading-tight text-white sm:text-5xl">{t("app.title")}</h1>
          <p className="mt-3 max-w-2xl text-sm text-white/80 sm:text-base">{t("app.subtitle")}</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={() => navigate("finance")} className="rounded-full bg-ke-green px-4 py-2 text-sm font-medium text-white">
              Finance & Audit
            </button>
            <button onClick={() => navigate("reps")} className="rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/30">
              Representatives
            </button>
            <button onClick={() => navigate("compare")} className="rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/30">
              Compare counties
            </button>
          </div>
        </div>
      </section>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Counties" value="47" hint="Devolved units · CoK 2010" icon={<MapPin className="h-5 w-5" />} tone="green" />
        <StatCard label="Population (2019)" value={formatPopulation(COUNTIES.reduce((s, c) => s + c.population, 0))} hint="KNBS Census" icon={<Users className="h-5 w-5" />} />
        <StatCard label="National absorption FY23/24" value={`${agg.avgOverallAbsorption.toFixed(1)}%`} hint="County average · CoB" icon={<Landmark className="h-5 w-5" />} tone="gold" />
        <StatCard label="Pending bills (sample)" value={formatKesMillions(agg.totalPendingBills)} hint={`${agg.count} counties with published CoB data`} icon={<Scale className="h-5 w-5" />} tone="red" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <SectionTitle kicker="National executive" title="Republic of Kenya · 2022–2027" />
          <div className="grid gap-3 sm:grid-cols-2">
            {NATIONAL.map((p) => (
              <button key={p.id} onClick={() => navigate("rep", { id: p.id })} className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:bg-muted/50">
                <img src="/images/emblem.png" alt="" className="h-12 w-12 rounded-full object-cover" />
                <div>
                  <p className="font-medium">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.title}</p>
                  <div className="mt-1">
                    <CoalitionBadge coalition={p.coalition} />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Politics" title="Governor coalitions" />
          <div className="space-y-3">
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span>Kenya Kwanza</span>
                <span>{kk} / 47</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-yellow-500" style={{ width: `${(kk / 47) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span>Azimio</span>
                <span>{az} / 47</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-sky-500" style={{ width: `${(az / 47) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span>Independent / Other</span>
                <span>{47 - kk - az} / 47</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-stone-400" style={{ width: `${((47 - kk - az) / 47) * 100}%` }} />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">IEBC 2022 general election. Party switches after election are not inferred.</p>
          </div>
        </Card>
      </div>

      <section>
        <SectionTitle
          kicker="Devolution"
          title="All 47 counties"
          action={
            <span className="text-xs text-muted-foreground">
              {filtered.length} shown · KNBS 2019
            </span>
          }
        />
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px] flex-1">
            <Filter className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Filter by county or governor"
              className="h-9 w-full rounded-full border border-border bg-card pl-9 pr-3 text-sm outline-none"
            />
          </div>
          <select value={region} onChange={(e) => setRegion(e.target.value as Region | "All")} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
            <option value="All">All regions</option>
            {REGIONS.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
          <select value={coalition} onChange={(e) => setCoalition(e.target.value as Coalition | "All")} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
            <option value="All">All coalitions</option>
            <option>Kenya Kwanza</option>
            <option>Azimio</option>
            <option>Independent</option>
            <option>Other</option>
          </select>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c) => {
            const fin = COUNTY_FINANCE.find((f) => f.countyName === c.name);
            return (
              <Card key={c.code} className="p-4" onClick={() => navigate("county", { code: String(c.code) })}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                      County {String(c.code).padStart(3, "0")} · {c.region}
                    </p>
                    <h3 className="font-display text-xl">{countyName(c.name)}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{c.governor.name}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      <Badge className={coalitionColor(c.governor.coalition)}>{c.governor.party || c.governor.coalition}</Badge>
                      {fin && <AuditBadge opinion={fin.auditOpinion} />}
                    </div>
                  </div>
                  <ScoreRing score={fin?.complianceScore ?? null} size={64} label="CoG" />
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3 text-xs">
                  <div>
                    <p className="text-muted-foreground">Population</p>
                    <p className="font-medium">{formatPopulation(c.population)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Area</p>
                    <p className="font-medium">{Math.round(c.area).toLocaleString()} km²</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Absorption</p>
                    <p className="font-medium">{fin?.overallAbsorption != null ? `${fin.overallAbsorption}%` : "N/A"}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <img src="https://images.pexels.com/photos/15496542/pexels-photo-15496542.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Nairobi skyline" className="h-44 w-full object-cover" />
          <div className="p-5">
            <SectionTitle kicker="Citizen tools" title="Report, ask, compare" />
            <p className="text-sm text-muted-foreground">Submit public feedback, file an encrypted whistleblower envelope, or ask the rule-based AI assistant about county finance.</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={() => navigate("feedback")} className="rounded-full bg-ke-green px-4 py-2 text-sm text-white">
                Feedback portal
              </button>
              <button onClick={() => navigate("whistleblower")} className="rounded-full border border-border px-4 py-2 text-sm">
                Whistleblower
              </button>
              <button onClick={() => navigate("ai")} className="rounded-full border border-border px-4 py-2 text-sm">
                Ask AI
              </button>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Methodology" title="How this dashboard treats data" />
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
              Numbers are taken from published OAG, CoB, CoG, KNBS and Parliament records.
            </li>
            <li className="flex gap-2">
              <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
              Where a figure is not in the latest public report it is shown as N/A — never estimated.
            </li>
            <li className="flex gap-2">
              <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
              CECM names without a citable gazette are labelled “Not publicly verified”.
            </li>
            <li className="flex gap-2">
              <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" />
              Finance coverage is {agg.count} of 47 counties for FY 2023/24 pending full CoB ingest.
            </li>
          </ul>
        </Card>
      </section>
    </div>
  );
}
