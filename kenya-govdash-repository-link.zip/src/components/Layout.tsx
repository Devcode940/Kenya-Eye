import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  BarChart3,
  Bot,
  Building2,
  Gavel,
  Home,
  Landmark,
  Menu,
  Moon,
  Scale,
  Search,
  ShieldAlert,
  Sun,
  Users,
  X,
  GitCompare,
  MessageSquare,
  Activity,
  FileWarning,
  Briefcase,
  Wallet,
  Siren,
  ScrollText,
} from "lucide-react";
import { useAuth } from "../lib/auth";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { useTheme } from "../lib/theme";
import { COUNTIES, searchAll } from "../data/counties";
import { cn } from "../utils/cn";
import type { PageId } from "../lib/types";

const NAV: { id: string; labelKey: string; page: PageId; params?: Record<string, string>; icon: typeof Home; section: string }[] = [
  { id: "home", labelKey: "nav.home", page: "home", icon: Home, section: "Dashboard" },
  { id: "finance", labelKey: "nav.finance_audit", page: "finance", icon: BarChart3, section: "Dashboard" },
  { id: "reps", labelKey: "nav.representatives", page: "reps", icon: Users, section: "Dashboard" },
  { id: "senate", labelKey: "Senate", page: "senate", icon: Landmark, section: "Dashboard" },
  { id: "compare", labelKey: "nav.compare", page: "compare", icon: GitCompare, section: "Dashboard" },
  { id: "stats", labelKey: "nav.stats", page: "stats", icon: Activity, section: "Dashboard" },
  { id: "pending-bills", labelKey: "Pending Bills", page: "oversight", params: { section: "pending-bills" }, icon: Wallet, section: "Accountability" },
  { id: "projects", labelKey: "Project Tracker", page: "oversight", params: { section: "projects" }, icon: Briefcase, section: "Accountability" },
  { id: "red-flags", labelKey: "Red Flag Scanner", page: "oversight", params: { section: "red-flags" }, icon: Siren, section: "Accountability" },
  { id: "tenders", labelKey: "Tender Anomalies", page: "oversight", params: { section: "tenders" }, icon: FileWarning, section: "Accountability" },
  { id: "constitution", labelKey: "Constitution", page: "oversight", params: { section: "constitution" }, icon: Scale, section: "Law" },
  { id: "court", labelKey: "Court Cases", page: "oversight", params: { section: "court" }, icon: Gavel, section: "Law" },
  { id: "reports", labelKey: "Reports & Portals", page: "oversight", params: { section: "reports" }, icon: ScrollText, section: "Law" },
  { id: "datasets", labelKey: "County Datasets", page: "oversight", params: { section: "datasets" }, icon: ScrollText, section: "Law" },
  { id: "archive", labelKey: "Past FY Reports", page: "oversight", params: { section: "archive" }, icon: ScrollText, section: "Law" },
  { id: "feedback", labelKey: "nav.feedback", page: "feedback", icon: MessageSquare, section: "Citizen Tools" },
  { id: "whistleblower", labelKey: "nav.whistleblower", page: "whistleblower", icon: ShieldAlert, section: "Citizen Tools" },
  { id: "ai", labelKey: "nav.ai", page: "ai", icon: Bot, section: "Citizen Tools" },
  { id: "admin", labelKey: "nav.admin", page: "admin", icon: Landmark, section: "Citizen Tools" },
];

function FlagMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 32" className={className} aria-hidden>
      <rect width="48" height="32" fill="#17120b" />
      <rect y="10.5" width="48" height="11" fill="#bb0000" />
      <rect y="21.5" width="48" height="10.5" fill="#006b3f" />
      <rect y="9.5" width="48" height="2" fill="#fff" />
      <rect y="20.5" width="48" height="2" fill="#fff" />
      <circle cx="16" cy="16" r="6.2" fill="#fff" />
      <circle cx="16" cy="16" r="4.6" fill="#c5a572" />
    </svg>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { t, language, setLanguage } = useLanguage();
  const { theme, toggle } = useTheme();
  const { route, navigate } = useRouter();
  const { user, demoMode, signIn, signOut, error: authError } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [q, setQ] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmdOpen(true);
      }
      if (e.key === "Escape") setCmdOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    setSidebarOpen(false);
  }, [route.page, route.params.section, route.params.code]);

  const isActive = (item: (typeof NAV)[number]) => {
    if (item.page === "oversight") return route.page === "oversight" && route.params.section === item.params?.section;
    if (item.page === "home") return route.page === "home";
    return route.page === item.page || (item.page === "finance" && route.page === "finance-county") || (item.page === "reps" && route.page === "rep");
  };

  const sections = useMemo(() => {
    const map = new Map<string, typeof NAV>();
    for (const n of NAV) {
      const arr = map.get(n.section) ?? [];
      arr.push(n);
      map.set(n.section, arr);
    }
    return [...map.entries()];
  }, []);

  const results = q.trim().length > 1 ? searchAll(q) : { counties: [], people: [] };

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="flag-stripe h-1.5 w-full" />
      <header className="sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1600px] items-center gap-3 px-3 py-2.5 lg:px-5">
          <button className="rounded-lg p-2 lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
          <button onClick={() => navigate("home")} className="flex items-center gap-2.5">
            <img src="/images/emblem.png" alt="" className="h-9 w-9 rounded-full object-cover ring-1 ring-ke-gold/50" />
            <div className="text-left">
              <p className="font-display text-base font-semibold leading-none">{t("app.title.short")}</p>
              <p className="mt-0.5 hidden text-[10px] uppercase tracking-[0.16em] text-muted-foreground sm:block">47 Counties · 2022–2027</p>
            </div>
          </button>
          <button
            onClick={() => setCmdOpen(true)}
            className="ml-auto hidden flex-1 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground shadow-sm md:flex lg:max-w-md"
          >
            <Search className="h-4 w-4" />
            <span className="flex-1 text-left">{t("action.search")}</span>
            <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 text-[10px]">⌘K</kbd>
          </button>
          <div className="ml-auto flex items-center gap-1 md:ml-0">
            <button onClick={() => setCmdOpen(true)} className="rounded-lg p-2 md:hidden" aria-label="Search">
              <Search className="h-5 w-5" />
            </button>
            <div className="flex overflow-hidden rounded-full border border-border text-[11px] font-semibold">
              <button className={cn("px-2.5 py-1", language === "en" ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "")} onClick={() => setLanguage("en")}>
                EN
              </button>
              <button className={cn("px-2.5 py-1", language === "sw" ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "")} onClick={() => setLanguage("sw")}>
                SW
              </button>
            </div>
            <button onClick={toggle} className="rounded-lg p-2" aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            {user ? (
              <button onClick={signOut} className="flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1.5 text-xs" title={user.email ?? ""}>
                <img src={user.photoURL ?? "/images/emblem.png"} alt="" className="h-5 w-5 rounded-full" />
                <span className="hidden max-w-[90px] truncate sm:inline">{user.displayName?.split(" ")[0] ?? "Signed in"}</span>
              </button>
            ) : (
              <button
                onClick={signIn}
                className="flex items-center gap-1.5 rounded-full bg-ke-black px-3 py-1.5 text-xs text-white dark:bg-primary dark:text-primary-foreground"
                title={demoMode ? "Demo mode — set VITE_FIREBASE_* env vars to enable Google sign-in (see .env.example). " + (authError || "") : "Sign in with Google"}
              >
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-current"><path d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.9h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.4z"/><path d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z"/><path d="M6.4 13.9a6 6 0 0 1 0-3.8V7.5H3.1a10 10 0 0 0 0 9l3.3-2.6z"/><path d="M12 6c1.5 0 2.8.5 3.8 1.5L18.7 4A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.8 9.4 6 12 6z"/></svg>
                <span className="hidden sm:inline">{demoMode ? "Sign in (demo)" : "Google"}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1600px]">
        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-50 w-72 overflow-y-auto border-r border-border bg-card px-3 py-4 transition lg:static lg:z-0 lg:block lg:h-[calc(100dvh-3.4rem)] lg:sticky lg:top-[3.4rem]",
            sidebarOpen ? "block" : "hidden lg:block",
          )}
        >
          <div className="mb-3 flex items-center justify-between lg:hidden">
            <span className="font-display text-lg">Menu</span>
            <button onClick={() => setSidebarOpen(false)}>
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mb-4 rounded-xl bg-gradient-to-br from-ke-black via-ke-red to-ke-green p-[1px]">
            <div className="rounded-[11px] bg-card p-3">
              <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Sourced from</p>
              <p className="mt-1 text-xs leading-relaxed">OAG · CoB · CoG · KNBS · Parliament · IEBC</p>
            </div>
          </div>
          {sections.map(([section, items]) => (
            <div key={section} className="mb-4">
              <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">{section}</p>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item);
                  return (
                    <button
                      key={item.id}
                      onClick={() => navigate(item.page, item.params)}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm transition",
                        active ? "bg-ke-green text-white dark:bg-primary dark:text-primary-foreground" : "hover:bg-muted",
                      )}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{t(item.labelKey) === item.labelKey ? item.labelKey.replace("nav.", "") : t(item.labelKey)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </aside>
        {sidebarOpen && <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

        <main className="has-bottom-nav min-w-0 flex-1 px-3 py-5 lg:px-6 lg:py-6">{children}</main>
      </div>

      <footer className="hidden border-t border-border bg-card/60 px-6 py-6 lg:block">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <FlagMark className="h-4 w-6 rounded-sm" />
            <span>{t("app.title")} — 2022–2027</span>
          </div>
          <span>{t("footer.nonPartisan")}</span>
          <span>{t("footer.sources")}</span>
        </div>
      </footer>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="grid grid-cols-5 text-[10px]">
          {[
            { page: "home" as PageId, icon: Home, label: t("bottomnav.home") },
            { page: "finance" as PageId, icon: BarChart3, label: t("nav.finance_audit") },
            { page: "ai" as PageId, icon: Bot, label: t("bottomnav.ai") },
            { page: "reps" as PageId, icon: Users, label: t("nav.representatives") },
            { page: "search" as PageId, icon: Search, label: t("nav.search") },
          ].map((item) => {
            const Icon = item.icon;
            const active = route.page === item.page || (item.page === "search" && cmdOpen);
            return (
              <button
                key={item.page}
                onClick={() => (item.page === "search" ? setCmdOpen(true) : navigate(item.page))}
                className={cn("flex flex-col items-center gap-1 py-2", active ? "text-ke-green dark:text-primary" : "text-muted-foreground")}
              >
                <Icon className="h-5 w-5" />
                <span className="truncate px-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {cmdOpen && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center bg-black/50 p-4 pt-[12vh]" onClick={() => setCmdOpen(false)}>
          <div className="w-full max-w-xl overflow-hidden rounded-2xl border border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 border-b border-border px-4">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("action.search")}
                className="h-12 w-full bg-transparent text-sm outline-none"
              />
              <kbd className="text-[10px] text-muted-foreground">ESC</kbd>
            </div>
            <div className="max-h-[50vh] overflow-y-auto p-2">
              {q.trim().length <= 1 && (
                <div className="grid grid-cols-2 gap-1 p-1">
                  {NAV.slice(0, 8).map((n) => (
                    <button
                      key={n.id}
                      onClick={() => {
                        navigate(n.page, n.params);
                        setCmdOpen(false);
                        setQ("");
                      }}
                      className="rounded-lg px-3 py-2 text-left text-sm hover:bg-muted"
                    >
                      {t(n.labelKey) === n.labelKey ? n.labelKey : t(n.labelKey)}
                    </button>
                  ))}
                </div>
              )}
              {results.counties.slice(0, 6).map((c) => (
                <button
                  key={c.code}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted"
                  onClick={() => {
                    navigate("county", { code: String(c.code) });
                    setCmdOpen(false);
                    setQ("");
                  }}
                >
                  <Building2 className="h-4 w-4 text-ke-green" />
                  <span>
                    {c.name} County <span className="text-xs text-muted-foreground">· {c.governor.name}</span>
                  </span>
                </button>
              ))}
              {results.people.slice(0, 8).map((p) => (
                <button
                  key={p.id}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted"
                  onClick={() => {
                    navigate("rep", { id: p.id });
                    setCmdOpen(false);
                    setQ("");
                  }}
                >
                  <Users className="h-4 w-4 text-ke-gold" />
                  <span>
                    {p.name} <span className="text-xs text-muted-foreground">· {p.title}</span>
                  </span>
                </button>
              ))}
              {q.trim().length > 1 && results.counties.length === 0 && results.people.length === 0 && (
                <p className="p-4 text-center text-sm text-muted-foreground">No matches. Try a county, governor, or party.</p>
              )}
            </div>
            <div className="flex justify-between border-t border-border px-4 py-2 text-[11px] text-muted-foreground">
              <span>{COUNTIES.length} counties indexed</span>
              <button
                className="underline"
                onClick={() => {
                  navigate("search", {}, q ? { q } : {});
                  setCmdOpen(false);
                }}
              >
                Open full search
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
