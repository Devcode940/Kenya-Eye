import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { subscribeAuth, signInWithGoogle, logout, firebaseEnabled } from "./firebase";
import type { User } from "firebase/auth";

interface AuthCtx {
  user: User | null;
  loading: boolean;
  demoMode: boolean;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  error: string;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => subscribeAuth((u) => {
    setUser(u);
    setLoading(false);
  }), []);

  const signIn = async () => {
    setError("");
    try {
      await signInWithGoogle();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const signOut = async () => {
    await logout();
  };

  return (
    <Ctx.Provider value={{ user, loading, demoMode: !firebaseEnabled, signIn, signOut, error }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
