// Real hybrid E2E encryption, mirroring the production Kenya GovDash design:
// RSA-OAEP-2048 admin keypair (public key acts as the "server" key; private key is
// never persisted — downloadable once, held in memory only), per-report AES-256-GCM
// data key wrapped with RSA-OAEP. Only ciphertext + wrapped key are stored.
import { getWbPubJwk, setWbPubJwk } from "../data/store";

function bytesToB64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}
function b64ToBytes(b64: string): Uint8Array<ArrayBuffer> {
  const s = atob(b64);
  const out = new Uint8Array(new ArrayBuffer(s.length));
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

let memoryPrivateKey: CryptoKey | null = null;

const RSA_PARAMS = { name: "RSA-OAEP", hash: "SHA-256" } as const;

async function fingerprintOf(key: CryptoKey): Promise<string> {
  const raw = await crypto.subtle.exportKey("spki", key);
  const digest = await crypto.subtle.digest("SHA-256", raw);
  return bytesToB64(new Uint8Array(digest)).slice(0, 24).toUpperCase();
}

export async function ensureAdminKeypair(): Promise<{ publicJwk: JsonWebKey; fingerprint: string }> {
  const existing = getWbPubJwk();
  if (existing) {
    const jwk = JSON.parse(existing) as JsonWebKey;
    const pub = await crypto.subtle.importKey("jwk", jwk, RSA_PARAMS, true, ["wrapKey"]);
    return { publicJwk: jwk, fingerprint: await fingerprintOf(pub) };
  }
  const kp = await crypto.subtle.generateKey(
    { name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
    true,
    ["wrapKey", "unwrapKey"],
  );
  memoryPrivateKey = kp.privateKey;
  const publicJwk = await crypto.subtle.exportKey("jwk", kp.publicKey);
  setWbPubJwk(JSON.stringify(publicJwk));
  return { publicJwk, fingerprint: await fingerprintOf(kp.publicKey) };
}

export async function getPublicKey(): Promise<CryptoKey> {
  let jwk = getWbPubJwk();
  if (!jwk) {
    const kp = await ensureAdminKeypair();
    jwk = JSON.stringify(kp.publicJwk);
  }
  return crypto.subtle.importKey("jwk", JSON.parse(jwk), RSA_PARAMS, true, ["wrapKey"]);
}

export async function encryptReport(plaintext: string): Promise<{ wrappedKey: string; iv: string; ciphertext: string }> {
  const pub = await getPublicKey();
  const dataKey = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, dataKey, new TextEncoder().encode(plaintext));
  const wrapped = await crypto.subtle.wrapKey("raw", dataKey, pub, { name: "RSA-OAEP" });
  return {
    wrappedKey: bytesToB64(new Uint8Array(wrapped)),
    iv: bytesToB64(iv),
    ciphertext: bytesToB64(new Uint8Array(cipher)),
  };
}

export async function exportPrivateKeyPem(): Promise<string> {
  if (!memoryPrivateKey) throw new Error("Private key is not in memory. Import your downloaded key file first.");
  const pkcs8 = await crypto.subtle.exportKey("pkcs8", memoryPrivateKey);
  const b64 = bytesToB64(new Uint8Array(pkcs8)).replace(/.{64}/g, "$&\n");
  return `-----BEGIN PRIVATE KEY-----\n${b64}\n-----END PRIVATE KEY-----\n`;
}

export async function importPrivateKeyFromText(text: string): Promise<CryptoKey> {
  const b64 = text.replace(/-----BEGIN PRIVATE KEY-----/, "").replace(/-----END PRIVATE KEY-----/, "").replace(/\s+/g, "");
  const key = await crypto.subtle.importKey("pkcs8", b64ToBytes(b64), RSA_PARAMS, true, ["unwrapKey"]);
  memoryPrivateKey = key;
  return key;
}

export function hasPrivateKeyInMemory(): boolean {
  return memoryPrivateKey !== null;
}

export async function decryptEnvelope(env: { wrappedKey: string; iv: string; ciphertext: string }): Promise<string> {
  if (!memoryPrivateKey) throw new Error("No private key in memory — import your downloaded admin private key first.");
  const dataKey = await crypto.subtle.unwrapKey(
    "raw",
    b64ToBytes(env.wrappedKey),
    memoryPrivateKey,
    { name: "RSA-OAEP" },
    { name: "AES-GCM", length: 256 },
    true,
    ["decrypt"],
  );
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64ToBytes(env.iv) }, dataKey, b64ToBytes(env.ciphertext));
  return new TextDecoder().decode(plain);
}
