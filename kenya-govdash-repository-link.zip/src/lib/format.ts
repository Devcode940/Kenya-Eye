import type { AuditOpinion, Coalition } from "./types";

export function formatKesMillions(value: number | null | undefined): string {
  if (value === null || value === undefined) return "N/A";
  if (value >= 1_000_000) return `Kshs ${(value / 1_000_000).toFixed(2)}T`;
  if (value >= 1_000) return `Kshs ${(value / 1_000).toFixed(1)}B`;
  return `Kshs ${Math.round(value).toLocaleString()}M`;
}

export function formatPopulation(value: number | null | undefined): string {
  if (value === null || value === undefined) return "N/A";
  if (value >= 1_000_000) {
    const m = value / 1_000_000;
    return `${m >= 10 ? Math.round(m) : m.toFixed(2)}M`;
  }
  if (value >= 1_000) return `${Math.round(value / 1_000)}K`;
  return value.toLocaleString();
}

export function formatPct(value: number | null | undefined): string {
  if (value === null || value === undefined) return "N/A";
  return `${value.toFixed(1)}%`;
}

export function initials(name: string): string {
  return name
    .replace(/^(Hon\.|Dr\.|Prof\.|Eng\.)\s+/i, "")
    .split(/\s+/)
    .filter((p) => p.length > 1 && !/^(ole|van|de|jr)$/i.test(p))
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function auditColor(opinion: AuditOpinion): string {
  switch (opinion) {
    case "Unmodified":
      return "bg-emerald-600";
    case "Qualified":
      return "bg-amber-500";
    case "Adverse":
      return "bg-rose-600";
    case "Disclaimer":
      return "bg-purple-600";
    default:
      return "bg-slate-400";
  }
}

export function auditText(opinion: AuditOpinion): string {
  switch (opinion) {
    case "Unmodified":
      return "text-emerald-700 dark:text-emerald-300";
    case "Qualified":
      return "text-amber-700 dark:text-amber-300";
    case "Adverse":
      return "text-rose-700 dark:text-rose-300";
    case "Disclaimer":
      return "text-purple-700 dark:text-purple-300";
    default:
      return "text-slate-500";
  }
}

export function auditBg(opinion: AuditOpinion): string {
  switch (opinion) {
    case "Unmodified":
      return "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800";
    case "Qualified":
      return "bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800";
    case "Adverse":
      return "bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800";
    case "Disclaimer":
      return "bg-purple-50 text-purple-800 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800";
    default:
      return "bg-slate-50 text-slate-600 border-slate-200 dark:bg-slate-900 dark:text-slate-300";
  }
}

export function coalitionColor(c: Coalition): string {
  switch (c) {
    case "Kenya Kwanza":
      return "bg-yellow-100 text-yellow-900 border-yellow-300 dark:bg-yellow-900/30 dark:text-yellow-200 dark:border-yellow-800";
    case "Azimio":
      return "bg-sky-100 text-sky-900 border-sky-300 dark:bg-sky-900/30 dark:text-sky-200 dark:border-sky-800";
    case "Independent":
      return "bg-stone-100 text-stone-800 border-stone-300 dark:bg-stone-800 dark:text-stone-200";
    default:
      return "bg-zinc-100 text-zinc-700 border-zinc-300 dark:bg-zinc-800 dark:text-zinc-200";
  }
}

export function partyToCoalition(party: string): Coalition {
  const p = party.toLowerCase();
  if (["uda", "anc", "ford-kenya", "ford kenya", "dap-k", "udm", "paa"].includes(p)) return "Kenya Kwanza";
  if (["odm", "wiper", "jubilee", "nap-k"].includes(p)) return "Azimio";
  if (p.includes("independent")) return "Independent";
  return "Other";
}
