// Google Firebase Auth. Configure via .env (see .env.example):
//   VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN, VITE_FIREBASE_PROJECT_ID,
//   VITE_FIREBASE_APP_ID, VITE_FIREBASE_MESSAGING_SENDER_ID
// When not configured, the app runs in demo mode (no Google sign-in) and all
// features still work locally — nothing breaks.
import { initializeApp, type FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, type Auth, type User } from "firebase/auth";

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
};

export const firebaseEnabled = Boolean(config.apiKey && config.projectId && config.appId);

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let provider: GoogleAuthProvider | null = null;

if (firebaseEnabled) {
  app = initializeApp(config as Record<string, string>);
  auth = getAuth(app);
  provider = new GoogleAuthProvider();
  provider.addScope("profile");
  provider.addScope("email");
}

export async function signInWithGoogle(): Promise<User> {
  if (!auth || !provider) throw new Error("Firebase not configured — set VITE_FIREBASE_* env vars (see .env.example). Demo mode active.");
  const cred = await signInWithPopup(auth, provider);
  return cred.user;
}

export async function logout(): Promise<void> {
  if (auth) await signOut(auth);
}

export function subscribeAuth(cb: (user: User | null) => void): () => void {
  if (!auth) {
    cb(null);
    return () => {};
  }
  return onAuthStateChanged(auth, cb);
}

export { auth };
