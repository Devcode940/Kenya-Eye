import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Language = "en" | "sw";

const translations: Record<Language, Record<string, string>> = {
  en: {
    "app.title": "Kenya Government Accountability Dashboard",
    "app.subtitle": "Constitution of Kenya 2010 · Devolved Governance · 47 Counties",
    "app.title.short": "Kenya GovDash",
    "app.badge": "Non-partisan · Factual · Source-cited · Data-gap transparent",
    "nav.home": "Home",
    "nav.counties": "Counties",
    "nav.finance_audit": "Finance & Audit",
    "nav.representatives": "Representatives",
    "nav.compare": "Compare",
    "nav.search": "Search",
    "nav.stats": "Platform Stats",
    "nav.feedback": "Feedback",
    "nav.whistleblower": "Whistleblower",
    "nav.ai": "AI Assistant",
    "nav.admin": "Admin",
    "bottomnav.home": "Home",
    "bottomnav.ai": "AI",
    "bottomnav.profile": "Explore",
    "action.search": "Search counties, reps, finance…",
    "action.cmdk": "Command palette",
    "rightSidebar.language": "Language",
    "rightSidebar.english": "English",
    "rightSidebar.swahili": "Kiswahili",
    "rightSidebar.theme": "Theme",
    "rightSidebar.lightMode": "Light",
    "rightSidebar.darkMode": "Dark",
    "footer.nonPartisan": "Non-Partisan · Factual",
    "footer.sources": "Live Sources: OAG · CoB · TI-Kenya · EACC · KNBS",
    "finance.title": "Finance & Audit Dashboard",
    "reps.title": "Representatives Directory",
    "reps.search": "Search by name, county, or party…",
  },
  sw: {
    "app.title": "Dashibodi ya Uwajibikaji wa Serikali ya Kenya",
    "app.subtitle": "Katiba ya Kenya 2010 · Utawala wa Ugatuzi · Kaunti 47",
    "app.title.short": "Dashibodi ya Kenya",
    "app.badge": "Isiyo na chama · Ya ukweli · Chanzo kilichotajwa · Wazi kuhusu pengo",
    "nav.home": "Nyumbani",
    "nav.counties": "Kaunti",
    "nav.finance_audit": "Fedha na Ukaguzi",
    "nav.representatives": "Wawakilishi",
    "nav.compare": "Linganisha",
    "nav.search": "Tafuta",
    "nav.stats": "Takwimu",
    "nav.feedback": "Maoni",
    "nav.whistleblower": "Mlalamishaji",
    "nav.ai": "Msaidizi wa AI",
    "nav.admin": "Msimamizi",
    "bottomnav.home": "Nyumbani",
    "bottomnav.ai": "AI",
    "bottomnav.profile": "Chunguza",
    "action.search": "Tafuta kaunti, wawakilishi, fedha…",
    "action.cmdk": "Paleti ya amri",
    "rightSidebar.language": "Lugha",
    "rightSidebar.english": "English",
    "rightSidebar.swahili": "Kiswahili",
    "rightSidebar.theme": "Mandhari",
    "rightSidebar.lightMode": "Mwanga",
    "rightSidebar.darkMode": "Giza",
    "footer.nonPartisan": "Isiyo na Chama · Ya Ukweli",
    "footer.sources": "Vyanzo: OAG · CoB · TI-Kenya · EACC · KNBS",
    "finance.title": "Dashibodi ya Fedha na Ukaguzi",
    "reps.title": "Saraka ya Wawakilishi",
    "reps.search": "Tafuta kwa jina, kaunti, au chama…",
  },
};

const COUNTY_NAMES_SW: Record<string, string> = {
  "Tana River": "Mto Tana",
  "West Pokot": "Pokot Magharibi",
  "Nairobi City": "Nairobi",
};

interface LanguageContextValue {
  language: Language;
  isSwahili: boolean;
  toggleLanguage: () => void;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  countyName: (englishName: string) => string;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);
const STORAGE_KEY = "kenya-govdash-language";

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en");

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) as Language | null;
      if (saved === "en" || saved === "sw") setLanguageState(saved);
    } catch {
      /* ignore */
    }
  }, []);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      /* ignore */
    }
    document.documentElement.lang = lang;
  }, []);

  const toggleLanguage = useCallback(() => {
    setLanguage(language === "en" ? "sw" : "en");
  }, [language, setLanguage]);

  const t = useCallback(
    (key: string) => translations[language][key] ?? translations.en[key] ?? key,
    [language],
  );

  const countyName = useCallback(
    (englishName: string) => (language === "sw" ? COUNTY_NAMES_SW[englishName] ?? englishName : englishName),
    [language],
  );

  const value = useMemo(
    () => ({ language, isSwahili: language === "sw", toggleLanguage, setLanguage, t, countyName }),
    [language, toggleLanguage, setLanguage, t, countyName],
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
