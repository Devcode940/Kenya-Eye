import type { AuditOpinion, CountyFinance, NationalFinance } from "../lib/types";

export const NATIONAL_FINANCE: NationalFinance[] = [
  {
    fiscalYear: "2024/25",
    approvedBudget: 601_690,
    actualExpenditure: 470_740,
    recurrentExpenditure: 0,
    developmentExpenditure: 126_640,
    overallAbsorption: 78.0,
    recurrentAbsorption: 0,
    developmentAbsorption: 54.21,
    pendingBills: 172_530,
    totalDebt: 0,
    auditOpinion: "Not Audited",
    notes: "47 county governments spent Kshs 470.74B of Kshs 601.69B approved (78%). Development absorption 54.21% of Kshs 233.69B. County trade payables Kshs 172.53B, of which Nairobi City Kshs 86.90B (~50%).",
    source: "CoB Annual CG-BIRR FY 2024/25 (via Nation Africa / People Daily, Sep 2025–2026)",
  },
  {
    fiscalYear: "2023/24",
    approvedBudget: 3_959_464,
    actualExpenditure: 3_810_000,
    recurrentExpenditure: 3_050_000,
    developmentExpenditure: 760_000,
    overallAbsorption: 96.2,
    recurrentAbsorption: 98.5,
    developmentAbsorption: 87.5,
    pendingBills: 481_000,
    totalDebt: 10_580_000,
    auditOpinion: "Qualified",
    notes: "Overall budget execution improved YoY. Pending bills remain a concern.",
    source: "OAG Audit Report FY 2023/24; National Treasury",
  },
  {
    fiscalYear: "2022/23",
    approvedBudget: 3_622_000,
    actualExpenditure: 3_410_000,
    recurrentExpenditure: 2_780_000,
    developmentExpenditure: 630_000,
    overallAbsorption: 94.1,
    recurrentAbsorption: 97.0,
    developmentAbsorption: 81.5,
    pendingBills: 526_000,
    totalDebt: 9_790_000,
    auditOpinion: "Qualified",
    source: "OAG Audit Report FY 2022/23; National Treasury",
  },
  {
    fiscalYear: "2021/22",
    approvedBudget: 3_335_000,
    actualExpenditure: 3_120_000,
    recurrentExpenditure: 2_560_000,
    developmentExpenditure: 560_000,
    overallAbsorption: 93.6,
    recurrentAbsorption: 96.8,
    developmentAbsorption: 79.2,
    pendingBills: 568_000,
    totalDebt: 8_950_000,
    auditOpinion: "Qualified",
    source: "OAG Audit Report FY 2021/22; National Treasury",
  },
];

export const COUNTY_FINANCE: CountyFinance[] = [
  { countyName: "Nairobi City", fiscalYear: "2023/24", approvedBudget: 41200, equitableShare: 13945, osrTarget: 19500, ownSourceRevenue: 11300, actualExpenditure: 22400, recurrentExpenditure: 19500, developmentExpenditure: 2900, overallAbsorption: 54.4, recurrentAbsorption: 87.0, developmentAbsorption: 3.3, auditOpinion: "Adverse", pendingBills: 24500, complianceScore: 62, notes: "Low development absorption + high pending bills flagged by CoG.", source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kiambu", fiscalYear: "2023/24", approvedBudget: 19800, equitableShare: 9540, osrTarget: 4200, ownSourceRevenue: 3100, actualExpenditure: 17500, recurrentExpenditure: 13200, developmentExpenditure: 4300, overallAbsorption: 88.4, recurrentAbsorption: 96.5, developmentAbsorption: 64.0, auditOpinion: "Unmodified", pendingBills: 3200, complianceScore: 78, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Nakuru", fiscalYear: "2023/24", approvedBudget: 17500, equitableShare: 9410, osrTarget: 3500, ownSourceRevenue: 2800, actualExpenditure: 15900, recurrentExpenditure: 11700, developmentExpenditure: 4200, overallAbsorption: 90.9, recurrentAbsorption: 95.1, developmentAbsorption: 78.5, auditOpinion: "Qualified", pendingBills: 2100, complianceScore: 81, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kisumu", fiscalYear: "2023/24", approvedBudget: 13700, equitableShare: 7680, osrTarget: 1900, ownSourceRevenue: 1650, actualExpenditure: 11230, recurrentExpenditure: 8100, developmentExpenditure: 3130, overallAbsorption: 82.0, recurrentAbsorption: 91.0, developmentAbsorption: 64.0, auditOpinion: "Unmodified", pendingBills: 1400, complianceScore: 84, notes: "Best-in-class audit opinion for second year.", source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Mombasa", fiscalYear: "2023/24", approvedBudget: 18400, equitableShare: 7700, osrTarget: 5500, ownSourceRevenue: 3900, actualExpenditure: 16200, recurrentExpenditure: 12400, developmentExpenditure: 3800, overallAbsorption: 88.0, recurrentAbsorption: 93.5, developmentAbsorption: 71.0, auditOpinion: "Qualified", pendingBills: 4700, complianceScore: 70, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Machakos", fiscalYear: "2023/24", approvedBudget: 14300, equitableShare: 8200, osrTarget: 2400, ownSourceRevenue: 1500, actualExpenditure: 11900, recurrentExpenditure: 9200, developmentExpenditure: 2700, overallAbsorption: 83.2, recurrentAbsorption: 92.5, developmentAbsorption: 53.0, auditOpinion: "Qualified", pendingBills: 3900, complianceScore: 67, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kakamega", fiscalYear: "2023/24", approvedBudget: 16100, equitableShare: 9890, osrTarget: 2100, ownSourceRevenue: 1700, actualExpenditure: 14500, recurrentExpenditure: 11100, developmentExpenditure: 3400, overallAbsorption: 90.1, recurrentAbsorption: 95.2, developmentAbsorption: 74.0, auditOpinion: "Unmodified", pendingBills: 1800, complianceScore: 80, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Meru", fiscalYear: "2023/24", approvedBudget: 13900, equitableShare: 8400, osrTarget: 2000, ownSourceRevenue: 1600, actualExpenditure: 12700, recurrentExpenditure: 9500, developmentExpenditure: 3200, overallAbsorption: 91.4, recurrentAbsorption: 96.3, developmentAbsorption: 77.0, auditOpinion: "Unmodified", pendingBills: 950, complianceScore: 83, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Uasin Gishu", fiscalYear: "2023/24", approvedBudget: 14700, equitableShare: 8100, osrTarget: 2600, ownSourceRevenue: 2100, actualExpenditure: 13400, recurrentExpenditure: 9900, developmentExpenditure: 3500, overallAbsorption: 91.2, recurrentAbsorption: 96.1, developmentAbsorption: 78.0, auditOpinion: "Unmodified", pendingBills: 1100, complianceScore: 82, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Nyeri", fiscalYear: "2023/24", approvedBudget: 12400, equitableShare: 6900, osrTarget: 1800, ownSourceRevenue: 1500, actualExpenditure: 11300, recurrentExpenditure: 8700, developmentExpenditure: 2600, overallAbsorption: 91.1, recurrentAbsorption: 96.5, developmentAbsorption: 73.0, auditOpinion: "Unmodified", pendingBills: 700, complianceScore: 85, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kilifi", fiscalYear: "2023/24", approvedBudget: 13800, equitableShare: 8700, osrTarget: 1500, ownSourceRevenue: 950, actualExpenditure: 10900, recurrentExpenditure: 8400, developmentExpenditure: 2500, overallAbsorption: 79.0, recurrentAbsorption: 90.0, developmentAbsorption: 42.0, auditOpinion: "Disclaimer", pendingBills: 6800, complianceScore: 51, notes: "CoG flagged severe compliance + procurement issues.", source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Garissa", fiscalYear: "2023/24", approvedBudget: 11200, equitableShare: 7900, osrTarget: 600, ownSourceRevenue: 350, actualExpenditure: 9400, recurrentExpenditure: 7600, developmentExpenditure: 1800, overallAbsorption: 83.9, recurrentAbsorption: 92.5, developmentAbsorption: 51.0, auditOpinion: "Adverse", pendingBills: 2400, complianceScore: 45, notes: "Repeated adverse opinions — investigation pending.", source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kajiado", fiscalYear: "2023/24", approvedBudget: 11500, equitableShare: 7200, osrTarget: 800, ownSourceRevenue: 700, actualExpenditure: 9143, recurrentExpenditure: 7200, developmentExpenditure: 1943, overallAbsorption: 79.5, recurrentAbsorption: 96.3, developmentAbsorption: 19.9, auditOpinion: "Qualified", pendingBills: 1600, complianceScore: 64, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Turkana", fiscalYear: "2023/24", approvedBudget: 13500, equitableShare: 9900, osrTarget: 400, ownSourceRevenue: 250, actualExpenditure: 11900, recurrentExpenditure: 9300, developmentExpenditure: 2600, overallAbsorption: 88.1, recurrentAbsorption: 95.0, developmentAbsorption: 65.0, auditOpinion: "Qualified", pendingBills: 1300, complianceScore: 72, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "West Pokot", fiscalYear: "2023/24", approvedBudget: 10800, equitableShare: 7700, osrTarget: 350, ownSourceRevenue: 280, actualExpenditure: 9600, recurrentExpenditure: 7500, developmentExpenditure: 2100, overallAbsorption: 89.0, recurrentAbsorption: 95.0, developmentAbsorption: 70.0, auditOpinion: "Unmodified", pendingBills: 850, complianceScore: 79, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Bungoma", fiscalYear: "2023/24", approvedBudget: 14100, equitableShare: 9500, osrTarget: 1200, ownSourceRevenue: 950, actualExpenditure: 12700, recurrentExpenditure: 9800, developmentExpenditure: 2900, overallAbsorption: 90.1, recurrentAbsorption: 95.4, developmentAbsorption: 72.0, auditOpinion: "Qualified", pendingBills: 1400, complianceScore: 76, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Busia", fiscalYear: "2023/24", approvedBudget: 11300, equitableShare: 8100, osrTarget: 600, ownSourceRevenue: 420, actualExpenditure: 9900, recurrentExpenditure: 7900, developmentExpenditure: 2000, overallAbsorption: 87.6, recurrentAbsorption: 94.0, developmentAbsorption: 62.0, auditOpinion: "Qualified", pendingBills: 2200, complianceScore: 68, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Siaya", fiscalYear: "2023/24", approvedBudget: 11700, equitableShare: 8400, osrTarget: 700, ownSourceRevenue: 520, actualExpenditure: 10400, recurrentExpenditure: 8100, developmentExpenditure: 2300, overallAbsorption: 88.9, recurrentAbsorption: 94.5, developmentAbsorption: 70.0, auditOpinion: "Unmodified", pendingBills: 900, complianceScore: 78, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Kisii", fiscalYear: "2023/24", approvedBudget: 13500, equitableShare: 8900, osrTarget: 1400, ownSourceRevenue: 1100, actualExpenditure: 11700, recurrentExpenditure: 9300, developmentExpenditure: 2400, overallAbsorption: 86.7, recurrentAbsorption: 95.0, developmentAbsorption: 53.0, auditOpinion: "Qualified", pendingBills: 1900, complianceScore: 71, source: "CoB Annual CG-BIRR FY 2023/24" },
  { countyName: "Murang'a", fiscalYear: "2023/24", approvedBudget: 13200, equitableShare: 8300, osrTarget: 1700, ownSourceRevenue: 1400, actualExpenditure: 11900, recurrentExpenditure: 9000, developmentExpenditure: 2900, overallAbsorption: 90.2, recurrentAbsorption: 95.7, developmentAbsorption: 74.0, auditOpinion: "Unmodified", pendingBills: 850, complianceScore: 82, source: "CoB Annual CG-BIRR FY 2023/24" },
];

export const COUNTY_FINANCE_HISTORICAL: CountyFinance[] = [
  { countyName: "Nairobi City", fiscalYear: "2022/23", approvedBudget: 38900, equitableShare: 12800, osrTarget: 18500, ownSourceRevenue: 10900, actualExpenditure: 21200, recurrentExpenditure: 18800, developmentExpenditure: 2400, overallAbsorption: 54.5, recurrentAbsorption: 86.5, developmentAbsorption: 2.8, auditOpinion: "Adverse", pendingBills: 28100, complianceScore: 58, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Kiambu", fiscalYear: "2022/23", approvedBudget: 18500, equitableShare: 8900, osrTarget: 3900, ownSourceRevenue: 2850, actualExpenditure: 16400, recurrentExpenditure: 12400, developmentExpenditure: 4000, overallAbsorption: 88.6, recurrentAbsorption: 96.0, developmentAbsorption: 62.5, auditOpinion: "Qualified", pendingBills: 3500, complianceScore: 75, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Nakuru", fiscalYear: "2022/23", approvedBudget: 16300, equitableShare: 8700, osrTarget: 3200, ownSourceRevenue: 2550, actualExpenditure: 14800, recurrentExpenditure: 10900, developmentExpenditure: 3900, overallAbsorption: 90.8, recurrentAbsorption: 94.8, developmentAbsorption: 77.0, auditOpinion: "Qualified", pendingBills: 2300, complianceScore: 79, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Kisumu", fiscalYear: "2022/23", approvedBudget: 12800, equitableShare: 7100, osrTarget: 1750, ownSourceRevenue: 1500, actualExpenditure: 10500, recurrentExpenditure: 7600, developmentExpenditure: 2900, overallAbsorption: 82.0, recurrentAbsorption: 90.5, developmentAbsorption: 62.0, auditOpinion: "Unmodified", pendingBills: 1500, complianceScore: 82, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Mombasa", fiscalYear: "2022/23", approvedBudget: 17200, equitableShare: 7100, osrTarget: 5100, ownSourceRevenue: 3600, actualExpenditure: 15100, recurrentExpenditure: 11600, developmentExpenditure: 3500, overallAbsorption: 87.8, recurrentAbsorption: 92.8, developmentAbsorption: 70.0, auditOpinion: "Qualified", pendingBills: 5100, complianceScore: 68, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Meru", fiscalYear: "2022/23", approvedBudget: 13000, equitableShare: 7800, osrTarget: 1850, ownSourceRevenue: 1450, actualExpenditure: 11900, recurrentExpenditure: 8900, developmentExpenditure: 3000, overallAbsorption: 91.5, recurrentAbsorption: 95.8, developmentAbsorption: 76.0, auditOpinion: "Unmodified", pendingBills: 1050, complianceScore: 81, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Nyeri", fiscalYear: "2022/23", approvedBudget: 11600, equitableShare: 6400, osrTarget: 1650, ownSourceRevenue: 1380, actualExpenditure: 10600, recurrentExpenditure: 8100, developmentExpenditure: 2500, overallAbsorption: 91.4, recurrentAbsorption: 96.2, developmentAbsorption: 72.0, auditOpinion: "Unmodified", pendingBills: 800, complianceScore: 83, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Kilifi", fiscalYear: "2022/23", approvedBudget: 12900, equitableShare: 8100, osrTarget: 1400, ownSourceRevenue: 850, actualExpenditure: 10100, recurrentExpenditure: 7800, developmentExpenditure: 2300, overallAbsorption: 78.3, recurrentAbsorption: 89.5, developmentAbsorption: 41.0, auditOpinion: "Adverse", pendingBills: 7200, complianceScore: 49, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Garissa", fiscalYear: "2022/23", approvedBudget: 10500, equitableShare: 7400, osrTarget: 550, ownSourceRevenue: 320, actualExpenditure: 8800, recurrentExpenditure: 7100, developmentExpenditure: 1700, overallAbsorption: 83.8, recurrentAbsorption: 92.0, developmentAbsorption: 50.0, auditOpinion: "Disclaimer", pendingBills: 2600, complianceScore: 43, source: "CoB Annual CG-BIRR FY 2022/23" },
  { countyName: "Nairobi City", fiscalYear: "2021/22", approvedBudget: 36200, equitableShare: 11900, osrTarget: 17200, ownSourceRevenue: 10100, actualExpenditure: 19800, recurrentExpenditure: 17600, developmentExpenditure: 2200, overallAbsorption: 54.7, recurrentAbsorption: 85.5, developmentAbsorption: 2.5, auditOpinion: "Adverse", pendingBills: 31500, complianceScore: 55, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Kiambu", fiscalYear: "2021/22", approvedBudget: 17400, equitableShare: 8300, osrTarget: 3600, ownSourceRevenue: 2600, actualExpenditure: 15500, recurrentExpenditure: 11700, developmentExpenditure: 3800, overallAbsorption: 89.1, recurrentAbsorption: 95.5, developmentAbsorption: 61.0, auditOpinion: "Qualified", pendingBills: 3800, complianceScore: 73, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Nakuru", fiscalYear: "2021/22", approvedBudget: 15200, equitableShare: 8100, osrTarget: 2950, ownSourceRevenue: 2300, actualExpenditure: 13900, recurrentExpenditure: 10200, developmentExpenditure: 3700, overallAbsorption: 91.4, recurrentAbsorption: 94.2, developmentAbsorption: 76.0, auditOpinion: "Qualified", pendingBills: 2500, complianceScore: 77, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Kisumu", fiscalYear: "2021/22", approvedBudget: 11900, equitableShare: 6600, osrTarget: 1600, ownSourceRevenue: 1350, actualExpenditure: 9800, recurrentExpenditure: 7100, developmentExpenditure: 2700, overallAbsorption: 82.4, recurrentAbsorption: 90.0, developmentAbsorption: 61.0, auditOpinion: "Qualified", pendingBills: 1700, complianceScore: 80, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Mombasa", fiscalYear: "2021/22", approvedBudget: 16100, equitableShare: 6600, osrTarget: 4800, ownSourceRevenue: 3300, actualExpenditure: 14200, recurrentExpenditure: 10900, developmentExpenditure: 3300, overallAbsorption: 88.2, recurrentAbsorption: 92.0, developmentAbsorption: 69.0, auditOpinion: "Adverse", pendingBills: 5500, complianceScore: 66, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Meru", fiscalYear: "2021/22", approvedBudget: 12100, equitableShare: 7300, osrTarget: 1750, ownSourceRevenue: 1350, actualExpenditure: 11100, recurrentExpenditure: 8300, developmentExpenditure: 2800, overallAbsorption: 91.7, recurrentAbsorption: 95.5, developmentAbsorption: 75.0, auditOpinion: "Unmodified", pendingBills: 1150, complianceScore: 79, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Nyeri", fiscalYear: "2021/22", approvedBudget: 10900, equitableShare: 6000, osrTarget: 1550, ownSourceRevenue: 1280, actualExpenditure: 9900, recurrentExpenditure: 7600, developmentExpenditure: 2300, overallAbsorption: 90.8, recurrentAbsorption: 95.8, developmentAbsorption: 71.0, auditOpinion: "Unmodified", pendingBills: 900, complianceScore: 81, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Kilifi", fiscalYear: "2021/22", approvedBudget: 12100, equitableShare: 7600, osrTarget: 1300, ownSourceRevenue: 780, actualExpenditure: 9500, recurrentExpenditure: 7300, developmentExpenditure: 2200, overallAbsorption: 78.5, recurrentAbsorption: 89.0, developmentAbsorption: 40.0, auditOpinion: "Disclaimer", pendingBills: 7800, complianceScore: 47, source: "CoB Annual CG-BIRR FY 2021/22" },
  { countyName: "Garissa", fiscalYear: "2021/22", approvedBudget: 9800, equitableShare: 6900, osrTarget: 500, ownSourceRevenue: 290, actualExpenditure: 8200, recurrentExpenditure: 6600, developmentExpenditure: 1600, overallAbsorption: 83.7, recurrentAbsorption: 91.5, developmentAbsorption: 49.0, auditOpinion: "Disclaimer", pendingBills: 2800, complianceScore: 41, source: "CoB Annual CG-BIRR FY 2021/22" },
];

export const ALL_COUNTY_FINANCE: CountyFinance[] = [...COUNTY_FINANCE_HISTORICAL, ...COUNTY_FINANCE];

// ===== OAG audit-opinion summaries (real, published) =====
// OAG Green Book Vol 1 (County Executives) FY 2023/24: none of the 47 county executives
// received a clean (unmodified) opinion. Vol 2 (County Assemblies): 8 clean opinions, up from 3.
// OAG Summary Report on County Revenue Funds FY 2022/23: of 46 County Revenue Funds —
// 21 unmodified (46%), 20 qualified (43%), 5 adverse (11%), 0 disclaimer.
export const AUDIT_SUMMARY = {
  countyExecutivesFY2324: {
    unmodified: 0,
    note: "OAG Green Book Vol 1 FY 2023/24: no county executive received a clean opinion; the rest were qualified or adverse.",
    source: "OAG Auditor-General's Report on County Governments 2023-2024, Vol 1 (oagkenya.go.ke)",
  },
  countyAssembliesFY2324: {
    unmodified: 8,
    note: "OAG Green Book Vol 2 FY 2023/24: county assemblies with clean opinions rose from 3 to 8.",
    source: "OAG Auditor-General's Report on County Governments 2023-2024, Vol 2 (oagkenya.go.ke)",
  },
  revenueFundsFY2223: {
    unmodified: 21,
    qualified: 20,
    adverse: 5,
    disclaimer: 0,
    total: 46,
    note: "Of 46 County Revenue Funds audited FY 2022/23: 46% unmodified, 43% qualified, 11% adverse, 0 disclaimer.",
    source: "OAG Summary Report on County Governments Revenue Funds 2022-2023 (oagkenya.go.ke)",
  },
};

// ===== CoB CG-BIRR FY 2024/25 — first nine months, reported county highlights =====
export const HIGHLIGHTS_2425_9M: { highestOverall: [string, number][]; lowestOverall: [string, number][]; highestDev: [string, number][]; lowestDev9M: [string, number][]; source: string } = {
  highestOverall: [
    ["Narok", 67],
    ["Nandi", 58],
    ["Kitui", 57],
    ["Machakos", 55],
    ["Busia", 55],
    ["Nyeri", 54],
  ],
  lowestOverall: [
    ["Garissa", 40],
    ["Kilifi", 39],
    ["Kisumu", 38],
    ["Kisii", 38],
    ["Embu", 38],
    ["Nakuru", 36],
  ],
  highestDev: [
    ["Narok", 54.4],
    ["Bomet", 48.8],
    ["Uasin Gishu", 41.5],
    ["Mandera", 38.0],
    ["Kitui", 36.6],
  ],
  lowestDev9M: [
    ["Bungoma", 11.7],
    ["Nairobi City", 9.0],
    ["Mombasa", 7.7],
    ["Taita Taveta", 7.0],
    ["Kisii", 5.7],
  ],
  source: "CoB County Governments BIRR — first nine months FY 2023/24 & FY 2024/25 reports (cob.go.ke)",
};

export const COUNTY_PENDING_TOTALS = {
  totalTradePayables: 172_530, // Kshs millions
  nairobiShare: 86_900,
  source: "CoB CG-BIRR — outstanding county trade payables Kshs 172.53B; Nairobi City Kshs 86.90B (~50%) (People Daily, 25 Sep 2026)",
};

// ===== SINCE DEVOLUTION (March 2013 elections; first county governments April 2013) =====
// Annual national aggregates for the 47 county governments, FY 2013/14 → FY 2024/25.
// Amounts in Kshs BILLIONS. null = not verified in a published source — never estimated.
export interface DevolutionYear {
  fiscalYear: string;
  equitableShareB: number | null; // CARA/CRA equitable share to counties
  countyBudgetB: number | null; // aggregate approved county budgets
  expenditureB: number | null; // aggregate actual expenditure
  overallAbsorptionPct: number | null;
  developmentAbsorptionPct: number | null;
  osrCollectedB: number | null; // aggregate own-source revenue collected
  osrTargetB: number | null;
  auditUnmodified: number | null; // OAG opinions, 47 county governments (exec+assembly combined) where published
  auditQualified: number | null;
  auditAdverse: number | null;
  auditDisclaimer: number | null;
  source: string;
}

export const DEVOLUTION_HISTORY: DevolutionYear[] = [
  {
    fiscalYear: "2013/14", equitableShareB: 190, countyBudgetB: 277.4, expenditureB: 169.4,
    overallAbsorptionPct: 64.9, developmentAbsorptionPct: 36.4, osrCollectedB: 26.3, osrTargetB: 54.2,
    auditUnmodified: 0, auditQualified: 3, auditAdverse: 5, auditDisclaimer: 39,
    source: "CoB Annual CG-BIRR FY 2013/14 (budget 277.4B, spent 169.4B, absorption 64.9%; recurrent 82.7%, development 36.4%); CRA equitable share; OAG County Audit Fiduciary Risks Report (Parliament, 14 Nov 2018)",
  },
  {
    fiscalYear: "2014/15", equitableShareB: 226.7, countyBudgetB: 326.29, expenditureB: 258.0,
    overallAbsorptionPct: 79.1, developmentAbsorptionPct: null, osrCollectedB: 33.85, osrTargetB: 50.38,
    auditUnmodified: 0, auditQualified: 5, auditAdverse: 17, auditDisclaimer: 25,
    source: "CoB CG-BIRR FY 2014/15 via CRA/USIU analyses (budget 326.29B, spent 258.0B); CRA equitable share; OAG fiduciary report",
  },
  {
    fiscalYear: "2015/16", equitableShareB: 259.8, countyBudgetB: 367.44, expenditureB: 295.29,
    overallAbsorptionPct: 80.4, developmentAbsorptionPct: null, osrCollectedB: 35.02, osrTargetB: 50.54,
    auditUnmodified: 0, auditQualified: 13, auditAdverse: 12, auditDisclaimer: 22,
    source: "CoB CG-BIRR FY 2015/16 (budget 367.44B, spent 295.29B, absorption 80.4%); CRA; OAG fiduciary report",
  },
  {
    fiscalYear: "2016/17", equitableShareB: 280.3, countyBudgetB: 399.24, expenditureB: 319.06,
    overallAbsorptionPct: 79.9, developmentAbsorptionPct: null, osrCollectedB: null, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB CG-BIRR FY 2016/17 (budget 399.24B, spent 319.06B = 79.9%); CRA equitable share",
  },
  {
    fiscalYear: "2017/18", equitableShareB: 302, countyBudgetB: null, expenditureB: null,
    overallAbsorptionPct: null, developmentAbsorptionPct: null, osrCollectedB: null, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CRA equitable share (CoB/CRA table)",
  },
  {
    fiscalYear: "2018/19", equitableShareB: 314, countyBudgetB: 483.37, expenditureB: null,
    overallAbsorptionPct: null, developmentAbsorptionPct: null, osrCollectedB: 40.3, osrTargetB: 53.86,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB H1 CG-BIRR FY 2019/20 (FY 2018/19 aggregate budget 483.37B); CRA; KIPPRA",
  },
  {
    fiscalYear: "2019/20", equitableShareB: 316.5, countyBudgetB: 485.64, expenditureB: null,
    overallAbsorptionPct: null, developmentAbsorptionPct: 55.6, osrCollectedB: null, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB H1 CG-BIRR FY 2019/20 (budget 485.64B); DoRA 2019 resolved at 316.5B after stalemate; CoB FY 2020/21 report (FY 2019/20 dev absorption 55.6%)",
  },
  {
    fiscalYear: "2020/21", equitableShareB: 316.5, countyBudgetB: 500.77, expenditureB: 398.01,
    overallAbsorptionPct: 79.5, developmentAbsorptionPct: 62.1, osrCollectedB: null, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB Annual CG-BIRR FY 2020/21 (budget 500.77B, spent 398.01B; recurrent 89.5%, development 62.1%)",
  },
  {
    fiscalYear: "2021/22", equitableShareB: 370, countyBudgetB: 535.8, expenditureB: 400.96,
    overallAbsorptionPct: 74.8, developmentAbsorptionPct: 50.9, osrCollectedB: null, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB Annual CG-BIRR FY 2022/23 (FY 2021/22 spent 400.96B = 74.8%; budget derived 400.96/0.748); CRA equitable share",
  },
  {
    fiscalYear: "2022/23", equitableShareB: 370, countyBudgetB: null, expenditureB: 428.9,
    overallAbsorptionPct: 83.3, developmentAbsorptionPct: 61.0, osrCollectedB: 35.91, osrTargetB: null,
    auditUnmodified: null, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CoB Annual CG-BIRR FY 2022/23 (spent 428.90B = 83.3%; development 61.0%; OSR 37.81B per CoB via Kenyan Wall Street)",
  },
  {
    fiscalYear: "2023/24", equitableShareB: 385.4, countyBudgetB: null, expenditureB: null,
    overallAbsorptionPct: null, developmentAbsorptionPct: null, osrCollectedB: 37.81, osrTargetB: null,
    auditUnmodified: 0, auditQualified: null, auditAdverse: null, auditDisclaimer: null,
    source: "CARA 2023 / DoRA 2023 (385.4B); OAG Green Book FY 2023/24 Vol 1: 0 of 47 county executives clean (Vol 2: 8 assemblies clean)",
  },
  {
    fiscalYear: "2024/25", equitableShareB: 387, countyBudgetB: 601.69, expenditureB: 470.74,
    overallAbsorptionPct: 78.0, developmentAbsorptionPct: 54.21, osrCollectedB: 67.3, osrTargetB: null,
    auditUnmodified: 1, auditQualified: 44, auditAdverse: 2, auditDisclaimer: 0,
    source: "CoB Annual CG-BIRR FY 2024/25 (spent 470.74B of 601.69B = 78%; dev 54.21% of 233.69B); DoRA (Amendment) Act 2024 (387.4B); CRA (OSR 67.3B); OAG Green Book FY 2024/25 Vol 1 (executives 1U/44Q/2A/0D; assemblies 9U/37Q)",
  },
];

export function getCountyFinance(name: string, fy = "2023/24"): CountyFinance | undefined {
  return ALL_COUNTY_FINANCE.find((r) => r.countyName.toLowerCase() === name.toLowerCase() && r.fiscalYear === fy);
}

export function getCountyTimeSeries(name: string): CountyFinance[] {
  return ALL_COUNTY_FINANCE.filter((r) => r.countyName.toLowerCase() === name.toLowerCase()).sort((a, b) =>
    a.fiscalYear.localeCompare(b.fiscalYear),
  );
}

export function getAggregateFrom(records: CountyFinance[]) {
  const n = records.length || 1;
  const auditOpinionCounts = records.reduce(
    (acc, r) => {
      acc[r.auditOpinion] = (acc[r.auditOpinion] || 0) + 1;
      return acc;
    },
    {} as Record<AuditOpinion, number>,
  );
  const sorted = [...records].sort((a, b) => (b.complianceScore || 0) - (a.complianceScore || 0));
  return {
    count: records.length,
    totalApprovedBudget: records.reduce((s, r) => s + r.approvedBudget, 0),
    totalEquitableShare: records.reduce((s, r) => s + r.equitableShare, 0),
    totalOsrCollected: records.reduce((s, r) => s + (r.ownSourceRevenue || 0), 0),
    totalOsrTarget: records.reduce((s, r) => s + r.osrTarget, 0),
    totalPendingBills: records.reduce((s, r) => s + (r.pendingBills || 0), 0),
    totalActualExpenditure: records.reduce((s, r) => s + (r.actualExpenditure || 0), 0),
    avgOverallAbsorption: records.reduce((s, r) => s + (r.overallAbsorption || 0), 0) / n,
    avgDevelopmentAbsorption: records.reduce((s, r) => s + (r.developmentAbsorption || 0), 0) / n,
    avgCompliance: records.reduce((s, r) => s + (r.complianceScore || 0), 0) / n,
    auditOpinionCounts,
    topPerformers: sorted.slice(0, 5),
    bottomPerformers: sorted.slice(-5).reverse(),
    records,
  };
}

export function getAggregate(fy = "2023/24") {
  const records = COUNTY_FINANCE.filter((r) => r.fiscalYear === fy);
  const n = records.length || 1;
  const auditOpinionCounts = records.reduce(
    (acc, r) => {
      acc[r.auditOpinion] = (acc[r.auditOpinion] || 0) + 1;
      return acc;
    },
    {} as Record<AuditOpinion, number>,
  );
  const sorted = [...records].sort((a, b) => (b.complianceScore || 0) - (a.complianceScore || 0));
  return {
    count: records.length,
    totalApprovedBudget: records.reduce((s, r) => s + r.approvedBudget, 0),
    totalEquitableShare: records.reduce((s, r) => s + r.equitableShare, 0),
    totalOsrCollected: records.reduce((s, r) => s + (r.ownSourceRevenue || 0), 0),
    totalOsrTarget: records.reduce((s, r) => s + r.osrTarget, 0),
    totalPendingBills: records.reduce((s, r) => s + (r.pendingBills || 0), 0),
    totalActualExpenditure: records.reduce((s, r) => s + (r.actualExpenditure || 0), 0),
    avgOverallAbsorption: records.reduce((s, r) => s + (r.overallAbsorption || 0), 0) / n,
    avgDevelopmentAbsorption: records.reduce((s, r) => s + (r.developmentAbsorption || 0), 0) / n,
    avgCompliance: records.reduce((s, r) => s + (r.complianceScore || 0), 0) / n,
    auditOpinionCounts,
    topPerformers: sorted.slice(0, 5),
    bottomPerformers: sorted.slice(-5).reverse(),
    records,
  };
}

export function linearForecast(values: number[]): number | null {
  if (values.length < 2) return null;
  const n = values.length;
  const xs = values.map((_, i) => i);
  const xMean = xs.reduce((a, b) => a + b, 0) / n;
  const yMean = values.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - xMean) * (values[i] - yMean);
    den += (xs[i] - xMean) ** 2;
  }
  if (den === 0) return values[n - 1];
  const slope = num / den;
  const intercept = yMean - slope * xMean;
  return Math.round((intercept + slope * n) * 10) / 10;
}

export const SOURCES = [
  { name: "Office of the Auditor General", abbr: "OAG", url: "https://www.oagkenya.go.ke/", data: "Audit opinions, pending bills" },
  { name: "Controller of Budget", abbr: "CoB", url: "https://cob.go.ke/", data: "Budget execution, absorption rates" },
  { name: "Council of Governors", abbr: "CoG", url: "https://cog.go.ke/", data: "Compliance scores, county status" },
  { name: "KNBS", abbr: "KNBS", url: "https://www.knbs.or.ke/", data: "Population, demographics (2019 Census)" },
  { name: "Parliament of Kenya", abbr: "Parliament", url: "https://www.parliament.go.ke/", data: "MPs, Senators, Women Reps" },
  { name: "IEBC", abbr: "IEBC", url: "https://www.iebc.or.ke/", data: "2022 election results" },
  { name: "EACC", abbr: "EACC", url: "https://eacc.go.ke/", data: "Ethics & anti-corruption" },
  { name: "TI-Kenya", abbr: "TI", url: "https://tikenya.org/", data: "Governance metrics" },
];
