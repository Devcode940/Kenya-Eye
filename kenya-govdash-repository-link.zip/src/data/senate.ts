// Senate of Kenya — 13th Parliament (2022–2027), Thirteenth Parliament, Fifth Session.
// Sources: parliament.go.ke/the-senate (+ /senators), IEBC Kenya Gazette nomination lists (Sep 2022).

export interface SenateLeader {
  role: string;
  name: string;
  party: string;
}

export const SENATE_LEADERSHIP: SenateLeader[] = [
  { role: "Speaker of the Senate", name: "Rt. Hon. Amason Jeffah Kingi, EGH, MP", party: "ODM" },
  { role: "Deputy Speaker", name: "Sen. Kathuri Murungi, MGH, MP", party: "UDA" },
  { role: "Senate Majority Leader", name: "Sen. Aaron Cheruiyot Kipkirui, EGH, MP", party: "UDA" },
  { role: "Senate Minority Leader", name: "Sen. Justice (Rtd.) Stewart Madzayo, EGH, MP", party: "ODM" },
  { role: "Senate Majority Whip", name: "Sen. David Wakoli Wafula, MP", party: "UDA" },
  { role: "Senate Minority Whip", name: "Sen. Olekina Ledama, MP", party: "ODM" },
  { role: "Clerk of the Senate", name: "Mr. Jeremiah M. Nyegenye, CBS", party: "—" },
];

// 20 nominated senators (IEBC gazette, Sep 2022): 16 women + 2 youth + 2 PWD = 67 total with 47 elected.
export const SENATE_NOMINATED: { name: string; party: string; group: string }[] = [
  { name: "Veronica Waheti Nduati", party: "UDA", group: "Women" },
  { name: "Roselinda Soipan Tuya", party: "UDA", group: "Women" },
  { name: "Miraj Abdillahi Abdulrahman", party: "UDA", group: "Women" },
  { name: "Gloria Magoma Orwoba", party: "UDA", group: "Women" },
  { name: "Joyce Chepkoech Korir", party: "UDA", group: "Women" },
  { name: "Karen Nyamu", party: "UDA", group: "Women" },
  { name: "Peris Pesi Tobiko", party: "UDA", group: "Women" },
  { name: "Maureen Tabitha Mutinda", party: "UDA", group: "Women" },
  { name: "Catherine Muyeka Mumma", party: "ODM", group: "Women" },
  { name: "Beatrice Akinyi Ogolla", party: "ODM", group: "Women" },
  { name: "Hamida Ali Kibwana", party: "ODM", group: "Women" },
  { name: "Betty Batuli Montet", party: "ODM", group: "Women" },
  { name: "Beth Kalunda Syengo", party: "ODM", group: "Women" },
  { name: "Margaret Jepkoech Kamar", party: "Jubilee", group: "Women" },
  { name: "Mariam Sheikh Omar", party: "UDM", group: "Women" },
  { name: "Shakila Abdalla Mohamed", party: "Wiper", group: "Women" },
  { name: "Hezena M. Lemaletian", party: "ODM", group: "Youth" },
  { name: "Raphael Chimera Mwinzagu", party: "UDA", group: "Youth" },
  { name: "Crystal Kagehi Asige", party: "ODM", group: "PWD" },
  { name: "George Mungai Mbugua", party: "UDA", group: "PWD" },
];

// Where to get LIVE Senate information (verified 2026):
export const SENATE_SOURCES = [
  {
    name: "Official Senate roster (parliament.go.ke)",
    url: "https://www.parliament.go.ke/the-senate/senators",
    how: "HTML table of all 67 senators (name, county, party, elected/nominated) + per-member 'More Info' pages. Also a 'Download list of Senate delegations and political parties' file on the page.",
    curl: "curl -sL 'https://www.parliament.go.ke/the-senate/senators' | grep -oP '(?<=<td>)[^<]+'",
  },
  {
    name: "Senate Hansard (official debates) — DSpace REST API",
    url: "https://hansardsn.parliament.go.ke/server/api/",
    how: "DSpace 7 repository. List items: GET /server/api/core/items?size=50 — each debate PDF is a bitstream: GET /server/api/core/bitstreams/{uuid}/content. Also mirrored at parliament.go.ke/sites/default/files/YYYY-MM/.",
    curl: "curl -s 'https://hansardsn.parliament.go.ke/server/api/core/items?size=20' | jq '. _embedded.items[].name'",
  },
  {
    name: "Senate business: Bills, Order Papers, Motions",
    url: "https://www.parliament.go.ke/the-senate",
    how: "Order Papers, Hansard links and the Bills tracker for the Senate are published under The Senate menu on parliament.go.ke (e.g. Senate Bill No. 39 of 2024 debated 25 Mar 2026).",
    curl: "Open https://www.parliament.go.ke/the-senate → Bills / Order Papers",
  },
  {
    name: "IPU Parline — Kenya Senate (structured + CSV/XLS)",
    url: "https://data.ipu.org/parliament/KE/KE-UC01/",
    how: "Inter-Parliamentary Union data: chamber structure, 47 directly elected + nominated members, current count 67, with XLS/CSV historical downloads.",
    curl: "See 'Historical data' → XLS/CSV on the page",
  },
  {
    name: "OpenSanctions — ke_senate dataset (67 senators, monthly refresh)",
    url: "https://www.opensanctions.org/datasets/ke_senate/",
    how: "Scraped from parliament.go.ke HTML. Bulk downloads: targets.simple.csv, entities.ftm.json; free /search and /match API for non-commercial use.",
    curl: "curl -s 'https://www.opensanctions.org/datasets/ke_senate/' → Bulk download → targets.simple.csv",
  },
  {
    name: "EveryPolitician (MySociety) — Popolo JSON per parliament",
    url: "https://data.mysociety.org/datasets/everypolitician-kenya-assembly/",
    how: "Popolo JSON + CSV per parliament term for MPs and senators; libraries for Python/Ruby.",
    curl: "All Data as Popolo JSON from the dataset page",
  },
  {
    name: "Mzalendo — Hansard search, scorecards, #MbungeSpotlight",
    url: "https://www.mzalendo.com/",
    how: "Non-partisan parliamentary monitor: searchable Hansard, MP/senator scorecards, daily bills & motions, #Dokeza public participation.",
    curl: "Open https://www.mzalendo.com/ → Hansard / Scorecards",
  },
  {
    name: "Kenya Open Data Portal (opendata.go.ke, Socrata API)",
    url: "https://www.opendata.go.ke/d/4ein-76wj",
    how: "Hosts 'The Hansard as published by Parliament of Kenya'. Query via Socrata: /api/views/4ein-76wj/rows.json",
    curl: "curl -s 'https://www.opendata.go.ke/api/views/4ein-76wj/rows.json?$limit=50'",
  },
  {
    name: "Kenya Law — Bills & Acts",
    url: "https://kenyalaw.org/",
    how: "Official-ish repository of bills, acts and the Kenya Gazette; useful for tracking Senate-passed legislation.",
    curl: "Open https://kenyalaw.org/kenyalaw/legislation/",
  },
];
