import { COUNTY_FINANCE } from "./finance";
import type { CountyFinance } from "../lib/types";

const read = <T>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};
const write = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent("kgd-store"));
  } catch {
    /* ignore */
  }
};

// ---------- Finance snapshot overrides (admin CRUD over the published base) ----------
const FIN_KEY = "kgd-finance-edits";
export type FinanceEdit = CountyFinance & { deleted?: boolean };

export function getFinanceEdits(): Record<string, FinanceEdit> {
  return read<Record<string, FinanceEdit>>(FIN_KEY, {});
}

export function upsertFinance(rec: CountyFinance): void {
  const edits = getFinanceEdits();
  edits[`${rec.countyName}|${rec.fiscalYear}`] = { ...rec };
  write(FIN_KEY, edits);
}

export function deleteFinance(countyName: string, fy = "2023/24"): void {
  const edits = getFinanceEdits();
  const cur = edits[`${countyName}|${fy}`];
  edits[`${countyName}|${fy}`] = cur ? { ...cur, deleted: true } : ({ countyName, fiscalYear: fy, deleted: true } as FinanceEdit);
  write(FIN_KEY, edits);
}

export function effectiveCountyFinance(fy = "2023/24"): CountyFinance[] {
  const edits = getFinanceEdits();
  const base = COUNTY_FINANCE.filter((r) => r.fiscalYear === fy && !edits[`${r.countyName}|${fy}`]?.deleted);
  const byKey = new Map<string, CountyFinance>(base.map((r) => [`${r.countyName}|${fy}`, r]));
  for (const [k, e] of Object.entries(edits)) {
    if (e.fiscalYear === fy && !e.deleted) byKey.set(k, e);
  }
  return [...byKey.values()].sort((a, b) => a.countyName.localeCompare(b.countyName));
}

// ---------- CECM verification toggles ----------
const CECM_KEY = "kgd-cecm-verified";
export function getCecmVerified(): Record<string, boolean> {
  return read(CECM_KEY, {});
}
export function toggleCecm(id: string, verified: boolean): void {
  const v = getCecmVerified();
  v[id] = verified;
  write(CECM_KEY, v);
}

// ---------- Feedback ----------
export interface FeedbackItem {
  id: string;
  name: string;
  county: string;
  topic: string;
  message: string;
  status: "Received" | "Under review" | "Responded" | "Closed";
  at: number;
  history: { status: string; at: number }[];
}
const FB_KEY = "kgd-feedback";
export function getFeedback(): FeedbackItem[] {
  return read<FeedbackItem[]>(FB_KEY, []);
}
export function addFeedback(item: Omit<FeedbackItem, "id" | "status" | "history" | "at">): FeedbackItem {
  const full: FeedbackItem = { ...item, at: Date.now(), id: crypto.randomUUID(), status: "Received", history: [{ status: "Received", at: Date.now() }] };
  write(FB_KEY, [full, ...getFeedback()]);
  return full;
}
export function setFeedbackStatus(id: string, status: FeedbackItem["status"]): void {
  const all = getFeedback().map((f) =>
    f.id === id ? { ...f, status, history: [...f.history, { status, at: Date.now() }] } : f,
  );
  write(FB_KEY, all);
}

// ---------- Finance alerts ----------
const ALERT_KEY = "kgd-alerts";
export function getAlerts(): { email: string; county: string; metric: string; threshold: number; at: number }[] {
  return read(ALERT_KEY, []);
}
export function addAlert(a: { email: string; county: string; metric: string; threshold: number }): void {
  write(ALERT_KEY, [...getAlerts(), { ...a, at: Date.now() }]);
}

// ---------- Whistleblower envelopes (ciphertext only) ----------
export interface WbEnvelope {
  id: string;
  wrappedKey: string;
  iv: string;
  ciphertext: string;
  category: string;
  county: string;
  status: "Queued" | "Under review" | "Escalated" | "Closed";
  at: number;
  history: { status: string; at: number }[];
}
const WB_KEY = "kgd-wb";
const WB_PUB = "kgd-wb-pub";
export function getWb(): WbEnvelope[] {
  return read<WbEnvelope[]>(WB_KEY, []);
}
export function saveWb(env: WbEnvelope): void {
  write(WB_KEY, [...getWb(), env]);
}
export function setWbStatus(id: string, status: WbEnvelope["status"]): void {
  write(
    WB_KEY,
    getWb().map((w) => (w.id === id ? { ...w, status, history: [...w.history, { status, at: Date.now() }] } : w)),
  );
}
export function getWbPubJwk(): string | null {
  try {
    return localStorage.getItem(WB_PUB);
  } catch {
    return null;
  }
}
export function setWbPubJwk(jwk: string): void {
  try {
    localStorage.setItem(WB_PUB, jwk);
  } catch {
    /* ignore */
  }
}

export function useStore() {
  return { getFinanceEdits, upsertFinance, deleteFinance, effectiveCountyFinance, getCecmVerified, toggleCecm, getFeedback, addFeedback, setFeedbackStatus, getAlerts, addAlert, getWb, saveWb, setWbStatus, getWbPubJwk, setWbPubJwk };
}
