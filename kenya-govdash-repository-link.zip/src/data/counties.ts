import type { Coalition, County, Level, Person, Region } from "../lib/types";
import { slugify } from "../lib/format";

const PORTFOLIOS = [
  "Finance & Economic Planning",
  "Health Services",
  "Education, Vocational Training, Youth & Sports",
  "Agriculture, Livestock & Fisheries",
  "Roads, Public Works, Transport & Energy",
  "Water, Environment & Natural Resources",
  "Lands, Physical Planning & Urban Development",
  "Trade, Industry, Tourism & Cooperatives",
  "Public Service, Administration & Devolution",
];

function person(
  id: string,
  name: string,
  title: string,
  party: string,
  coalition: Coalition,
  level: Level,
  jurisdiction: string,
  countyCode?: number,
  extra?: Partial<Person>,
): Person {
  return {
    id,
    name,
    title,
    party,
    coalition,
    level,
    jurisdiction,
    countyCode,
    termStart: extra?.termStart ?? "2022-08-09",
    termEnd: extra?.termEnd ?? "2027-08-09",
    bio: extra?.bio ?? null,
    bioSource: extra?.bioSource ?? null,
    email: extra?.email ?? null,
    phone: extra?.phone ?? null,
    twitter: extra?.twitter ?? null,
    website: extra?.website ?? null,
    verified: extra?.verified ?? true,
  };
}

function makeCecms(
  countyName: string,
  code: number,
  named: Record<string, string> = {},
): Person[] {
  return PORTFOLIOS.map((title) => {
    const known = named[title];
    return person(
      `cecm-${code}-${slugify(title)}`,
      known ?? "Not publicly verified",
      `CECM — ${title}`,
      "",
      "Other",
      "County",
      `${countyName} County`,
      code,
      { verified: Boolean(known), bio: known ? null : "CECM name not published in a citable county gazette / county website snapshot used by GovDash." },
    );
  });
}

// ===== IEBC 2022 general election — all 47 senators =====
// Source: IEBC 2022 results as reported by The Star / Capital FM / Tuko / Citizen Digital.
const SENATORS_2022: Record<number, [string, string, Coalition]> = {
  1: ["Mohamed Faki Mwinyihaji", "ODM", "Azimio"],
  2: ["Issa Juma Boy", "ODM", "Azimio"],
  3: ["Stewart Madzayo", "ODM", "Azimio"],
  4: ["Danson Mungatana", "UDA", "Kenya Kwanza"],
  5: ["Joseph Githuku", "Jubilee", "Azimio"],
  6: ["Johnes Mwaruma", "ODM", "Azimio"],
  7: ["Abdulkadir Mohamed Haji", "UDA", "Kenya Kwanza"],
  8: ["Abass Sheikh Mohamed", "UDM", "Kenya Kwanza"],
  9: ["Ali Ibrahim Roba", "UDM", "Kenya Kwanza"],
  10: ["Mohamed Said Chute", "UDA", "Kenya Kwanza"],
  11: ["Fatuma Adan Dullo", "Jubilee", "Azimio"],
  12: ["Kathuri Murungi", "UDA", "Kenya Kwanza"],
  13: ["Mwenda Gataya", "UDA", "Kenya Kwanza"],
  14: ["Alexander Mundigi", "DP", "Kenya Kwanza"],
  15: ["Enoch Wambua", "Wiper", "Azimio"],
  16: ["Agnes Kavindu Muthama", "Wiper", "Azimio"],
  17: ["Dan Maanzo", "Wiper", "Azimio"],
  18: ["John Methu", "UDA", "Kenya Kwanza"],
  19: ["Wahome Wamatinga", "UDA", "Kenya Kwanza"],
  20: ["James Kamau Murango", "UDA", "Kenya Kwanza"],
  21: ["Joe Nyutu", "UDA", "Kenya Kwanza"],
  22: ["Karungo Thang'wa", "UDA", "Kenya Kwanza"],
  23: ["James Lomenen", "UDA", "Kenya Kwanza"],
  24: ["Julius Murgor", "UDA", "Kenya Kwanza"],
  25: ["Steve Lelegwe", "UDA", "Kenya Kwanza"],
  26: ["Allan Chesang", "UDA", "Kenya Kwanza"],
  27: ["Jackson Mandago", "UDA", "Kenya Kwanza"],
  28: ["Kipchumba Murkomen", "UDA", "Kenya Kwanza"],
  29: ["Samson Cherargei", "UDA", "Kenya Kwanza"],
  30: ["William Cheptumo", "UDA", "Kenya Kwanza"],
  31: ["John Kinyua", "UDA", "Kenya Kwanza"],
  32: ["Tabitha Karanja", "UDA", "Kenya Kwanza"],
  33: ["Ledama Ole Kina", "ODM", "Azimio"],
  34: ["Seki Lenku Ole Kanar", "UDA", "Kenya Kwanza"],
  35: ["Aaron Cheruiyot", "UDA", "Kenya Kwanza"],
  36: ["Hillary Sigei", "UDA", "Kenya Kwanza"],
  37: ["Boni Khalwale", "UDA", "Kenya Kwanza"],
  38: ["Godfrey Osotsi", "ODM", "Azimio"],
  39: ["Moses Wetangula", "FORD-Kenya", "Kenya Kwanza"],
  40: ["Okiya Omtatah", "NRA", "Azimio"],
  41: ["Oburu Odinga", "ODM", "Azimio"],
  42: ["Tom Ojienda", "ODM", "Azimio"],
  43: ["Moses Kajwang'", "ODM", "Azimio"],
  44: ["Eddy Oketch", "ODM", "Azimio"],
  45: ["Richard Onyonka", "ODM", "Azimio"],
  46: ["Erick Okongo Mogeni", "ODM", "Azimio"],
  47: ["Edwin Sifuna", "ODM", "Azimio"],
};

// ===== IEBC 2022 general election — all 47 woman representatives =====
// Source: Tuko / twendesasa compiled IEBC 2022 results.
const WOMEN_REPS_2022: Record<number, [string, string, Coalition]> = {
  1: ["Zamzam Mohammed", "ODM", "Azimio"],
  2: ["Fatuma Masito", "ODM", "Azimio"],
  3: ["Gertrude Mbeyu", "ODM", "Azimio"],
  4: ["Amina Dika", "KANU", "Kenya Kwanza"],
  5: ["Monicah Marubu", "Independent", "Independent"],
  6: ["Lydia Haika", "UDA", "Kenya Kwanza"],
  7: ["Amina Siyad", "Jubilee", "Azimio"],
  8: ["Fatuma Jehoh", "ODM", "Azimio"],
  9: ["Umul Kassim", "UDM", "Kenya Kwanza"],
  10: ["Naomi Jilo Wako", "UDA", "Kenya Kwanza"],
  11: ["Mumina Bonaya", "Jubilee", "Azimio"],
  12: ["Elizabeth Kananu", "UDA", "Kenya Kwanza"],
  13: ["Susan Ngigi Mwindu", "TSP", "Other"],
  14: ["Pamela Njoki", "UDA", "Kenya Kwanza"],
  15: ["Muthoni Inene", "Wiper", "Azimio"],
  16: ["Joyce Kamene", "Wiper", "Azimio"],
  17: ["Rose Museo", "Wiper", "Azimio"],
  18: ["Faith Wairimu Gitau", "UDA", "Kenya Kwanza"],
  19: ["Rahab Mukami", "UDA", "Kenya Kwanza"],
  20: ["Jane Maina", "UDA", "Kenya Kwanza"],
  21: ["Betty Maina", "UDA", "Kenya Kwanza"],
  22: ["Anne Wamuratha", "UDA", "Kenya Kwanza"],
  23: ["Cecilia Asinyen", "UDA", "Kenya Kwanza"],
  24: ["Kasiwai Chepkemboi", "KUP", "Other"],
  25: ["Pauline Lenguris", "UDA", "Kenya Kwanza"],
  26: ["Lilian Chebet", "UDA", "Kenya Kwanza"],
  27: ["Gladys Shollei", "UDA", "Kenya Kwanza"],
  28: ["Caroline Ngelechei", "Independent", "Independent"],
  29: ["Cynthia Muge", "UDA", "Kenya Kwanza"],
  30: ["Florence Jematiah", "UDA", "Kenya Kwanza"],
  31: ["Jane Kagiri", "UDA", "Kenya Kwanza"],
  32: ["Liza Chelule", "UDA", "Kenya Kwanza"],
  33: ["Rebecca Tonkei", "UDA", "Kenya Kwanza"],
  34: ["Leah Sankaire", "UDA", "Kenya Kwanza"],
  35: ["Beatrice Kemei", "UDA", "Kenya Kwanza"],
  36: ["Linet Chepkorir", "UDA", "Kenya Kwanza"],
  37: ["Elsie Muhanda", "ODM", "Azimio"],
  38: ["Beatrice Adagala", "ANC", "Azimio"],
  39: ["Catherine Wambilianga", "FORD-Kenya", "Kenya Kwanza"],
  40: ["Catherine Omanyo", "ODM", "Azimio"],
  41: ["Christine Ombaka", "ODM", "Azimio"],
  42: ["Ruth Odinga", "ODM", "Azimio"],
  43: ["Joyce Atieno", "ODM", "Azimio"],
  44: ["Fatuma Mohammed", "Independent", "Independent"],
  45: ["Doris Ndonya", "WDP", "Other"],
  46: ["Jerusha Momanyi", "Jubilee", "Azimio"],
  47: ["Esther Passaris", "ODM", "Azimio"],
};

interface Seed {
  code: number;
  name: string;
  region: Region;
  population: number;
  area: number;
  governor: string;
  party: string;
  coalition: Coalition;
  dg?: [string, string, Coalition];
  sen?: [string, string, Coalition];
  wr?: [string, string, Coalition];
  mps?: [string, string, string, Coalition][];
  cecms?: Record<string, string>;
  cs?: string;
  ca?: string;
  bio?: string;
}

const SEEDS: Seed[] = [
  { code: 1, name: "Mombasa", region: "Coast", population: 1208333, area: 212.5, governor: "Abdulswamad Shariff Nassir", party: "ODM", coalition: "Azimio", dg: ["Francis Thoya", "ODM", "Azimio"], sen: ["Mohamed Faki Mwinyihaji", "ODM", "Azimio"], wr: ["Zamzam Mohammed", "ODM", "Azimio"], mps: [["Omar Mwinyi", "Changamwe", "ODM", "Azimio"], ["Badi Twalib", "Jomvu", "ODM", "Azimio"], ["Ali Menza Mbogo", "Kisauni", "Wiper", "Azimio"], ["Mohammed Ali", "Nyali", "Independent", "Independent"], ["Mishi Juma Mboko", "Likoni", "ODM", "Azimio"], ["Mohamed Machele", "Mvita", "ODM", "Azimio"]], bio: "Son of former Mvita MP Shariff Nassir; elected Governor of Mombasa County in 2022 on an ODM ticket." },
  { code: 2, name: "Kwale", region: "Coast", population: 866321, area: 8247, governor: "Fatuma Mohamed Achani", party: "UDA", coalition: "Kenya Kwanza", sen: ["Issa Juma Boy", "ODM", "Azimio"], wr: ["Fatuma Masito", "ODM", "Azimio"] },
  { code: 3, name: "Kilifi", region: "Coast", population: 1453787, area: 12245, governor: "Gideon Mung'aro", party: "ODM", coalition: "Azimio", sen: ["Stewart Madzayo", "ODM", "Azimio"], wr: ["Gertrude Mbeyu", "ODM", "Azimio"] },
  { code: 4, name: "Tana River", region: "Coast", population: 315943, area: 38437, governor: "Dhadho Godhana", party: "ODM", coalition: "Azimio", sen: ["Danson Mungatana", "ODM", "Azimio"] },
  { code: 5, name: "Lamu", region: "Coast", population: 143920, area: 6167, governor: "Issa Abdalla Timamy", party: "ANC", coalition: "Kenya Kwanza" },
  { code: 6, name: "Taita Taveta", region: "Coast", population: 340671, area: 17084, governor: "Andrew Mwadime", party: "Independent", coalition: "Independent", sen: ["Johnes Mwaruma", "ODM", "Azimio"] },
  { code: 7, name: "Garissa", region: "North Eastern", population: 841353, area: 44164, governor: "Nathif Jama Adam", party: "ODM", coalition: "Azimio", sen: ["Abdul Haji", "UDA", "Kenya Kwanza"] },
  { code: 8, name: "Wajir", region: "North Eastern", population: 781263, area: 56503, governor: "Ahmed Abdullahi", party: "ODM", coalition: "Azimio" },
  { code: 9, name: "Mandera", region: "North Eastern", population: 867457, area: 25797, governor: "Mohamed Adan Khalif", party: "UDM", coalition: "Kenya Kwanza", sen: ["Ali Ibrahim Roba", "UDM", "Kenya Kwanza"] },
  { code: 10, name: "Marsabit", region: "Eastern", population: 459785, area: 65925, governor: "Mohamud Mohamed Ali", party: "ODM", coalition: "Azimio" },
  { code: 11, name: "Isiolo", region: "Eastern", population: 268002, area: 25336, governor: "Abdi Ibrahim Hassan Guyo", party: "Jubilee", coalition: "Azimio", sen: ["Fatuma Dullo", "Jubilee", "Azimio"] },
  { code: 12, name: "Meru", region: "Eastern", population: 1545186, area: 6936, governor: "Kawira Mwangaza", party: "Independent", coalition: "Independent", sen: ["Kathuri Murungi", "Independent", "Independent"], wr: ["Elizabeth Kailemia", "UDA", "Kenya Kwanza"], mps: [["Rahim Dawood", "North Imenti", "Independent", "Independent"], ["John Paul Mwirigi", "Igembe South", "Independent", "Independent"], ["Cynthia Muge", "Buuri", "UDA", "Kenya Kwanza"]], bio: "Former Meru Woman Representative; elected Independent Governor of Meru County in 2022." },
  { code: 13, name: "Tharaka Nithi", region: "Eastern", population: 393177, area: 2570, governor: "Muthomi Njuki", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 14, name: "Embu", region: "Eastern", population: 608599, area: 2555, governor: "Cecily Mutitu Mbarire", party: "UDA", coalition: "Kenya Kwanza", sen: ["Alexander Mundigi", "UDA", "Kenya Kwanza"] },
  { code: 15, name: "Kitui", region: "Eastern", population: 1136187, area: 30562, governor: "Julius Malombe", party: "Wiper", coalition: "Azimio", sen: ["Enoch Wambua", "Wiper", "Azimio"], wr: ["Irene Muthoni Kasalu", "Wiper", "Azimio"] },
  { code: 16, name: "Machakos", region: "Eastern", population: 1421932, area: 5953, governor: "Wavinya Ndeti", party: "Wiper", coalition: "Azimio", sen: ["Agnes Kavindu Muthama", "Wiper", "Azimio"], wr: ["Joyce Kamene", "Wiper", "Azimio"], mps: [["Vincent Musyoka", "Mavoko", "Wiper", "Azimio"], ["Robert Mbui", "Kathiani", "Wiper", "Azimio"], ["Caleb Mule", "Machakos Town", "Wiper", "Azimio"]], bio: "First woman Governor of Machakos County; elected 2022 on a Wiper Democratic Movement ticket." },
  { code: 17, name: "Makueni", region: "Eastern", population: 884527, area: 7788, governor: "Mutula Kilonzo Junior", party: "Wiper", coalition: "Azimio", wr: ["Rose Museo", "Wiper", "Azimio"] },
  { code: 18, name: "Nyandarua", region: "Central", population: 596608, area: 3286, governor: "Moses Kiarie Badilisha", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 19, name: "Nyeri", region: "Central", population: 759164, area: 3337, governor: "Mutahi Kahiga", party: "UDA", coalition: "Kenya Kwanza", wr: ["Rahab Mukami", "UDA", "Kenya Kwanza"] },
  { code: 20, name: "Kirinyaga", region: "Central", population: 610411, area: 1205, governor: "Anne Mumbi Waiguru", party: "UDA", coalition: "Kenya Kwanza", wr: ["Jane Njeri Maina", "UDA", "Kenya Kwanza"] },
  { code: 21, name: "Murang'a", region: "Central", population: 958620, area: 2558, governor: "Irungu Kang'ata", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 22, name: "Kiambu", region: "Central", population: 2417735, area: 2448, governor: "James Kimani Wamatangi", party: "UDA", coalition: "Kenya Kwanza", dg: ["Njoroge Nani Mungai", "UDA", "Kenya Kwanza"], sen: ["Karungo Thang'wa", "UDA", "Kenya Kwanza"], wr: ["Anne Wamuratha", "UDA", "Kenya Kwanza"], mps: [["John Kiarie", "Dagoretti South", "UDA", "Kenya Kwanza"], ["Gathoni Wamuchomba", "Githunguri", "UDA", "Kenya Kwanza"], ["Njuguna Wanjiku", "Kiambu Town", "UDA", "Kenya Kwanza"], ["Alice Ng'ang'a", "Thika Town", "UDA", "Kenya Kwanza"], ["Wanjiku Muhia", "Kikuyu", "UDA", "Kenya Kwanza"]] },
  { code: 23, name: "Turkana", region: "Rift Valley", population: 926976, area: 71597, governor: "Jeremiah Lomurkai", party: "ODM", coalition: "Azimio" },
  { code: 24, name: "West Pokot", region: "Rift Valley", population: 621241, area: 9163, governor: "Simon Kachapin", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 25, name: "Samburu", region: "Rift Valley", population: 310327, area: 21000, governor: "Jonathan Lati Lelelit", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 26, name: "Trans-Nzoia", region: "Rift Valley", population: 990341, area: 2475, governor: "George Natembeya", party: "DAP-K", coalition: "Kenya Kwanza" },
  { code: 27, name: "Uasin Gishu", region: "Rift Valley", population: 1163186, area: 3328, governor: "Jonathan Bii", party: "UDA", coalition: "Kenya Kwanza", wr: ["Gladys Boss Shollei", "UDA", "Kenya Kwanza"] },
  { code: 28, name: "Elgeyo-Marakwet", region: "Rift Valley", population: 454173, area: 3020, governor: "Wisley Rotich", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 29, name: "Nandi", region: "Rift Valley", population: 862844, area: 2884, governor: "Stephen Sang", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 30, name: "Baringo", region: "Rift Valley", population: 666762, area: 11075, governor: "Benjamin Cheboi", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 31, name: "Laikipia", region: "Rift Valley", population: 518560, area: 9462, governor: "Joshua Irungu", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 32, name: "Nakuru", region: "Rift Valley", population: 2162202, area: 7232, governor: "Susan Kikwai Kihika", party: "UDA", coalition: "Kenya Kwanza", dg: ["Erick Kurgat", "UDA", "Kenya Kwanza"], sen: ["Tabitha Karanja Keroche", "UDA", "Kenya Kwanza"], wr: ["Liza Chelule", "UDA", "Kenya Kwanza"], mps: [["David Gikaria", "Nakuru Town East", "UDA", "Kenya Kwanza"], ["Samuel Arama", "Nakuru Town West", "UDA", "Kenya Kwanza"], ["Joseph Tonui", "Kuresoi South", "UDA", "Kenya Kwanza"]], bio: "Lawyer and former Nakuru Senator; elected Governor of Nakuru County in 2022." },
  { code: 33, name: "Narok", region: "Rift Valley", population: 1065836, area: 17944, governor: "Patrick Keturet Ntutu", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 34, name: "Kajiado", region: "Rift Valley", population: 1117397, area: 21901, governor: "Joseph Ole Lenku", party: "ODM", coalition: "Azimio", cecms: { "Gender, Culture & Social Services": "Jeremiah Ole Ncharo", "Lands, Physical Planning & Urban Development": "Hamilton Lekuka Parseina", "Roads, Public Works, Transport & Energy": "Augustine Sekeyian", "Education, Vocational Training, Youth & Sports": "Judy Pere", "Water, Environment & Natural Resources": "Dr. Jacton Achola", "Trade, Industry, Tourism & Cooperatives": "Naomi Pilale Parinkoi" }, cs: "Dr. Leina Mpoke", ca: "Janet Sereu" },
  { code: 35, name: "Kericho", region: "Rift Valley", population: 901806, area: 2534, governor: "Erick Mutai", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 36, name: "Bomet", region: "Rift Valley", population: 875689, area: 1597, governor: "Hillary Barchok", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 37, name: "Kakamega", region: "Western", population: 1867579, area: 3051, governor: "Fernandes Barasa", party: "ODM", coalition: "Azimio", sen: ["Boni Khalwale", "ANC", "Kenya Kwanza"], wr: ["Elsie Busihile Muhanda", "ODM", "Azimio"], mps: [["Tindi Mwale", "Butere", "ODM", "Azimio"], ["Elisha Busisa", "Mumias East", "ODM", "Azimio"]] },
  { code: 38, name: "Vihiga", region: "Western", population: 590671, area: 531, governor: "Wilber Ottichilo", party: "ODM", coalition: "Azimio" },
  { code: 39, name: "Bungoma", region: "Western", population: 1670575, area: 3059, governor: "Kenneth Lusaka", party: "FORD-Kenya", coalition: "Kenya Kwanza" },
  { code: 40, name: "Busia", region: "Western", population: 893681, area: 1628, governor: "Paul Otuoma", party: "ODM", coalition: "Azimio" },
  { code: 41, name: "Siaya", region: "Nyanza", population: 993183, area: 2530, governor: "James Orengo", party: "ODM", coalition: "Azimio", sen: ["Oburu Oginga", "ODM", "Azimio"], wr: ["Christine Ombaka", "ODM", "Azimio"] },
  { code: 42, name: "Kisumu", region: "Nyanza", population: 1155574, area: 2086, governor: "Prof. Peter Anyang' Nyong'o", party: "ODM", coalition: "Azimio", dg: ["Dr. Oluoch Madgada", "ODM", "Azimio"], sen: ["Prof. Tom Joseph Ojienda", "ODM", "Azimio"], wr: ["Rosa Buyu", "ODM", "Azimio"], mps: [["Shakeel Shabbir", "Kisumu East", "Independent", "Independent"], ["Joshua Oron", "Kisumu Central", "ODM", "Azimio"], ["Elisha Ochieng Odhiambo", "Kisumu West", "ODM", "Azimio"]], bio: "Scholar and veteran politician; re-elected Governor of Kisumu County in 2022.", cecms: { "Finance & Economic Planning": "George Okong'o", "Health Services": "Dr. Gregory Ganda" } },
  { code: 43, name: "Homa Bay", region: "Nyanza", population: 1131950, area: 3154, governor: "Gladys Atieno Nyasuna Wanga", party: "ODM", coalition: "Azimio", sen: ["Moses Kajwang", "ODM", "Azimio"] },
  { code: 44, name: "Migori", region: "Nyanza", population: 1046232, area: 2597, governor: "Ochilo Ayacko", party: "ODM", coalition: "Azimio" },
  { code: 45, name: "Kisii", region: "Nyanza", population: 1266860, area: 1318, governor: "Simba Arati", party: "ODM", coalition: "Azimio" },
  { code: 46, name: "Nyamira", region: "Nyanza", population: 605184, area: 912, governor: "Amos Nyaribo", party: "UDA", coalition: "Kenya Kwanza" },
  { code: 47, name: "Nairobi City", region: "Nairobi", population: 4397073, area: 703, governor: "Johnson Arthur Sakaja", party: "UDA", coalition: "Kenya Kwanza", dg: ["Polycarp Igathe", "UDA", "Kenya Kwanza"], sen: ["Edwin Watenya Sifuna", "ODM", "Azimio"], wr: ["Esther Muthoni Passaris", "ODM", "Azimio"], mps: [["Tim Wanyonyi", "Westlands", "ODM", "Azimio"], ["Beatrice Elachi", "Dagoretti North", "ODM", "Azimio"], ["John Kiarie", "Dagoretti South", "UDA", "Kenya Kwanza"], ["Phelix Odiwuor Jalang'o", "Lang'ata", "ODM", "Azimio"], ["Peter Orero", "Kibra", "ODM", "Azimio"], ["Augustino Neto", "Roysambu", "UDA", "Kenya Kwanza"], ["John Njuguna Wanjiku", "Kasarani", "UDA", "Kenya Kwanza"], ["T.J. Kajwang", "Ruaraka", "ODM", "Azimio"], ["Julius Mawathe", "Embakasi South", "Wiper", "Azimio"], ["James Gakuya", "Embakasi North", "UDA", "Kenya Kwanza"], ["Benjamin Gathiru Mwangi", "Embakasi Central", "UDA", "Kenya Kwanza"], ["Babu Owino", "Embakasi East", "ODM", "Azimio"], ["Mark Mwenje", "Embakasi West", "ODM", "Azimio"], ["George Aladwa", "Makadara", "ODM", "Azimio"], ["Yusuf Hassan", "Kamukunji", "ODM", "Azimio"], ["Charles Njagua", "Starehe", "UDA", "Kenya Kwanza"], ["Anthony Oluoch", "Mathare", "ODM", "Azimio"]], bio: "Former Nairobi Senator; elected Governor of Nairobi City County in 2022 on a UDA ticket.", cecms: { "Finance & Economic Planning": "Charles Kerich", "Health Services": "Suzanne Gakii", "Education, Vocational Training, Youth & Sports": "Babu Owino (advisory / county programmes)" } },
];

function buildCounty(s: Seed): County {
  const g = person(
    `gov-${s.code}-${slugify(s.governor)}`,
    s.governor,
    `Governor, ${s.name} County`,
    s.party,
    s.coalition,
    "County",
    `${s.name} County`,
    s.code,
    { bio: s.bio ?? null, bioSource: s.bio ? "IEBC 2022 general election results; county government publications" : null },
  );
  const county: County = {
    code: s.code,
    name: s.name,
    region: s.region,
    population: s.population,
    area: s.area,
    density: Math.round(s.population / s.area),
    governor: g,
    mps: (s.mps ?? []).map(([name, consti, party, coal]) =>
      person(`mp-${s.code}-${slugify(consti)}`, name, `MP, ${consti}`, party, coal, "Constituency", consti, s.code),
    ),
    cecms: makeCecms(s.name, s.code, s.cecms),
  };
  if (s.dg) {
    county.deputyGovernor = person(`dg-${s.code}`, s.dg[0], `Deputy Governor, ${s.name} County`, s.dg[1], s.dg[2], "County", `${s.name} County`, s.code);
  }
  const sen = SENATORS_2022[s.code];
  if (sen) {
    county.senator = person(`sen-${s.code}`, sen[0], `Senator, ${s.name} County`, sen[1], sen[2], "County", `${s.name} County`, s.code, {
      bio: `Elected Senator for ${s.name} County in the 9 August 2022 general election.`,
      bioSource: "IEBC 2022 senatorial results",
    });
  }
  const wr = WOMEN_REPS_2022[s.code];
  if (wr) {
    county.womanRep = person(`wr-${s.code}`, wr[0], `Woman Representative, ${s.name} County`, wr[1], wr[2], "County", `${s.name} County`, s.code, {
      bio: `Elected Woman Representative for ${s.name} County in the 9 August 2022 general election.`,
      bioSource: "IEBC 2022 women representative results",
    });
  }
  if (s.cs) {
    county.countySecretary = person(`cs-${s.code}`, s.cs, `County Secretary, ${s.name} County`, "", "Other", "County", `${s.name} County`, s.code);
  }
  if (s.ca) {
    county.countyAttorney = person(`ca-${s.code}`, s.ca, `County Attorney, ${s.name} County`, "", "Other", "County", `${s.name} County`, s.code);
  }
  return county;
}

export const COUNTIES: County[] = SEEDS.map(buildCounty);

export const NATIONAL: Person[] = [
  person("pres-ruto", "William Samoei Ruto", "President of the Republic of Kenya", "UDA", "Kenya Kwanza", "National", "Republic of Kenya", undefined, {
    bio: "Elected President in the 9 August 2022 general election. Term 2022–2027.",
    bioSource: "IEBC 2022 presidential election results",
    website: "https://www.president.go.ke/",
  }),
  person("dp-kindiki", "Prof. Kithure Kindiki", "Deputy President of the Republic of Kenya", "UDA", "Kenya Kwanza", "National", "Republic of Kenya", undefined, {
    bio: "Appointed Deputy President following the 2024 impeachment of Rigathi Gachagua. Previously Senator for Tharaka Nithi and Cabinet Secretary for Interior.",
    bioSource: "Parliament of Kenya; Executive Office of the President",
  }),
];

export const REGIONS: Region[] = ["Coast", "North Eastern", "Eastern", "Central", "Rift Valley", "Western", "Nyanza", "Nairobi"];

export function flattenCounty(c: County): Person[] {
  return [
    c.governor,
    c.deputyGovernor,
    c.senator,
    c.womanRep,
    ...c.mps,
    ...c.cecms,
    c.countySecretary,
    c.countyAttorney,
  ].filter((p): p is Person => Boolean(p));
}

export function allRepresentatives(): Person[] {
  return [...NATIONAL, ...COUNTIES.flatMap(flattenCounty)];
}

export function getCounty(code: number): County | undefined {
  return COUNTIES.find((c) => c.code === code);
}

export function getCountyByName(name: string): County | undefined {
  const q = name.toLowerCase();
  return COUNTIES.find((c) => c.name.toLowerCase() === q || c.name.toLowerCase().includes(q));
}

export function getPerson(id: string): Person | undefined {
  return allRepresentatives().find((p) => p.id === id);
}

export function searchAll(q: string): { counties: County[]; people: Person[] } {
  const s = q.trim().toLowerCase();
  if (!s) return { counties: [], people: [] };
  return {
    counties: COUNTIES.filter((c) => `${c.name} ${c.region} ${c.governor.name}`.toLowerCase().includes(s)),
    people: allRepresentatives().filter((p) =>
      `${p.name} ${p.title} ${p.party} ${p.coalition} ${p.jurisdiction}`.toLowerCase().includes(s),
    ),
  };
}
