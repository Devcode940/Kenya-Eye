// Generates kenya-county-data/data/** from the app's verified datasets plus
// factual county seats, approximate centroids and known referral hospitals.
// Run: npx tsx scripts/generate-county-data.mts
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { COUNTIES, flattenCounty } from "../src/data/counties";
import { ALL_COUNTY_FINANCE, COUNTY_FINANCE, NATIONAL_FINANCE, AUDIT_SUMMARY, COUNTY_PENDING_TOTALS, DEVOLUTION_HISTORY } from "../src/data/finance";
import { SENATE_LEADERSHIP, SENATE_NOMINATED } from "../src/data/senate";

const ROOT = join(dirname(new URL(import.meta.url).pathname), "..", "kenya-county-data", "data");
const NOW = new Date().toISOString();

const CAPITALS: Record<number, string> = {
  1: "Mombasa", 2: "Kwale", 3: "Kilifi", 4: "Hola", 5: "Lamu", 6: "Voi", 7: "Garissa", 8: "Wajir", 9: "Mandera",
  10: "Marsabit", 11: "Isiolo", 12: "Meru", 13: "Chuka", 14: "Embu", 15: "Kitui", 16: "Machakos", 17: "Wote",
  18: "Ol Kalou", 19: "Nyeri", 20: "Kerugoya", 21: "Murang'a", 22: "Kiambu", 23: "Lodwar", 24: "Kapenguria",
  25: "Maralal", 26: "Kitale", 27: "Eldoret", 28: "Iten", 29: "Kapsabet", 30: "Kabarnet", 31: "Nanyuki",
  32: "Nakuru", 33: "Narok", 34: "Kajiado", 35: "Kericho", 36: "Bomet", 37: "Kakamega", 38: "Mbale",
  39: "Bungoma", 40: "Busia", 41: "Siaya", 42: "Kisumu", 43: "Homa Bay", 44: "Migori", 45: "Kisii",
  46: "Nyamira", 47: "Nairobi",
};

// Approximate WGS84 county centroids (for mapping until the IEBC boundary shapefile is ingested).
const CENTROIDS: Record<number, [number, number]> = {
  1: [-4.05, 39.67], 2: [-4.18, 39.45], 3: [-3.63, 39.85], 4: [-1.7, 40.0], 5: [-2.27, 40.9], 6: [-3.4, 38.35],
  7: [-0.45, 39.65], 8: [1.75, 40.06], 9: [3.94, 41.86], 10: [2.33, 37.98], 11: [0.35, 37.62], 12: [-0.05, 37.65],
  13: [-0.1, 37.65], 14: [-0.53, 37.45], 15: [-1.37, 38.01], 16: [-1.52, 37.26], 17: [-1.8, 37.62], 18: [-0.62, 36.38],
  19: [-0.42, 36.95], 20: [-0.5, 37.35], 21: [-0.92, 37.15], 22: [-1.17, 36.83], 23: [3.12, 35.6], 24: [1.4, 35.1],
  25: [1.1, 36.7], 26: [1.0, 35.0], 27: [0.51, 35.3], 28: [0.95, 35.5], 29: [0.2, 35.1], 30: [0.47, 36.1],
  31: [-0.07, 37.07], 32: [-0.3, 36.08], 33: [-1.08, 35.87], 34: [-1.85, 36.78], 35: [-0.37, 35.28], 36: [-0.78, 35.34],
  37: [0.28, 34.75], 38: [0.08, 34.72], 39: [0.57, 34.56], 40: [0.46, 34.11], 41: [-0.06, 34.29], 42: [-0.09, 34.77],
  43: [-0.53, 34.46], 44: [-1.06, 34.47], 45: [-0.68, 34.77], 46: [-0.57, 34.95], 47: [-1.29, 36.82],
};

// Level 5/6 referral hospitals (Ministry of Health designation) — counties without a listed
// national referral hospital are served by their County Referral Hospital (marked null here
// rather than guessed).
const REFERRAL: Record<number, string> = {
  1: "Coast General University Hospital (Level 6)",
  22: "Kenyatta University Teaching, Referral and Research Hospital (Level 6)",
  42: "Jaramogi Oginga Odinga Teaching and Referral Hospital (Level 6)",
  47: "Kenyatta National Hospital (Level 6)",
  27: "Moi Teaching and Referral Hospital (Level 6)",
  32: "Nakuru County Referral Hospital (Level 5)",
  37: "Kakamega County Referral Hospital (Level 5)",
  3: "Kilifi County Referral Hospital (Level 5)",
  7: "Garissa County Referral Hospital (Level 5)",
  12: "Meru County Referral Hospital (Level 5)",
  19: "Nyeri County Referral Hospital (Level 5)",
  16: "Machakos County Referral Hospital (Level 5)",
  14: "Embu County Referral Hospital (Level 5)",
};

function write(rel: string, obj: unknown) {
  const p = join(ROOT, rel);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, JSON.stringify(obj, null, 2));
  console.log("wrote", rel);
}

const brief = (p: { name: string; title: string; party: string; coalition: string; id: string }) => ({
  id: p.id, name: p.name, title: p.title, party: p.party, coalition: p.coalition,
});

// ---------- counties ----------
const master = COUNTIES.map((c) => ({
  code: c.code,
  name: c.name,
  region: c.region,
  countySeat: CAPITALS[c.code] ?? null,
  centroid: CENTROIDS[c.code] ?? null,
  population2019: c.population,
  landAreaSqKm: c.area,
  densityPerSqKm: c.density,
  governor: brief(c.governor),
  deputyGovernor: c.deputyGovernor ? brief(c.deputyGovernor) : null,
  senator: c.senator ? brief(c.senator) : null,
  womanRepresentative: c.womanRep ? brief(c.womanRep) : null,
  cecmSeats: c.cecms.length,
  cecmVerified: c.cecms.filter((x) => x.verified).length,
  countySecretary: c.countySecretary ? brief(c.countySecretary) : null,
  countyAttorney: c.countyAttorney ? brief(c.countyAttorney) : null,
  mpCount: c.mps.length,
}));
write("counties/county_master.json", {
  _meta: { generatedAt: NOW, source: "IEBC 2022 results; KNBS 2019 Census; county government publications", license: "CC-BY-4.0 data / MIT code", counties: 47 },
  counties: master,
});

write("counties/county_boundaries.geojson", {
  type: "FeatureCollection",
  _meta: "Approximate county centroids as Points (WGS84). Replace with IEBC county boundary polygons via ingestion/knbs (shapefile). Do not treat these as official boundaries.",
  features: COUNTIES.map((c) => ({
    type: "Feature",
    properties: { code: c.code, name: c.name, region: c.region, countySeat: CAPITALS[c.code], note: "centroid" },
    geometry: { type: "Point", coordinates: [CENTROIDS[c.code][1], CENTROIDS[c.code][0]] }, // GeoJSON = [lon, lat]
  })),
});

// ---------- domain files ----------
const byName = Object.fromEntries(COUNTIES.map((c) => [c.name, c]));

write("demographics/demographics.json", {
  _meta: { generatedAt: NOW, source: "KNBS 2019 Kenya Population and Housing Census (Vol II/III)", url: "https://www.knbs.or.ke/?p=2972", note: "Household, urban/rural and age-structure splits pending ingestion/knbs fetch of census volumes — fields null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    population2019: c.population,
    landAreaSqKm: c.area,
    densityPerSqKm: c.density,
    households: null,
    urbanPopulation: null,
    ruralPopulation: null,
    dataAvailable: true,
    partialFields: ["households", "urbanPopulation", "ruralPopulation"],
  }])),
});

write("elections/elections_2022.json", {
  _meta: { generatedAt: NOW, source: "IEBC 9 August 2022 general election results (gazetted)", url: "https://www.iebc.or.ke/", note: "Vote counts per candidate pending ingestion from IEBC results portal — null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    governor: brief(c.governor),
    senator: c.senator ? brief(c.senator) : null,
    womanRepresentative: c.womanRep ? brief(c.womanRep) : null,
    governorVotes: null,
    registeredVoters: null,
    turnoutPct: null,
  }])),
});

write("finance/finance.json", {
  _meta: { generatedAt: NOW, source: "CoB County/National BIRRs; OAG Green Book; County Allocation of Revenue Act", url: "https://cob.go.ke/reports", countyRows: COUNTY_FINANCE.length, nationalRows: NATIONAL_FINANCE.length, auditSummary: AUDIT_SUMMARY, countyPendingTotals: COUNTY_PENDING_TOTALS, note: "County rows exist only where a published CoB extract is held; other counties are absent (N/A), not zero." },
  national: NATIONAL_FINANCE,
  counties: ALL_COUNTY_FINANCE,
  devolution: DEVOLUTION_HISTORY,
});

write("governance/governance.json", {
  _meta: { generatedAt: NOW, source: "IEBC 2022; parliament.go.ke; county government gazettes", url: "https://www.parliament.go.ke/the-senate/senators", senateLeadership: SENATE_LEADERSHIP, nominatedSenators: SENATE_NOMINATED, note: "CECM names require a citable county gazette/portal page — unverified seats are listed with verified=false." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    governor: brief(c.governor),
    deputyGovernor: c.deputyGovernor ? brief(c.deputyGovernor) : null,
    senator: c.senator ? brief(c.senator) : null,
    womanRepresentative: c.womanRep ? brief(c.womanRep) : null,
    countySecretary: c.countySecretary ? brief(c.countySecretary) : null,
    countyAttorney: c.countyAttorney ? brief(c.countyAttorney) : null,
    cecms: c.cecms.map((x) => ({ id: x.id, name: x.name, portfolio: x.title.replace("CECM — ", ""), verified: x.verified })),
    constituencyMPs: c.mps.map(brief),
  }])),
});

write("health/health.json", {
  _meta: { generatedAt: NOW, source: "Ministry of Health facility master list / KHIS", url: "https://khis.health.go.ke/", note: "Facility counts, beds and health workers pending ingestion from KHIS facility registry — null, not estimated. Level 5/6 referral hospital shown only where officially designated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    referralHospital: REFERRAL[c.code] ?? null,
    totalFacilities: null,
    hospitalBeds: null,
    healthWorkers: null,
    under5Mortality: null,
    dataAvailable: Boolean(REFERRAL[c.code]),
  }])),
});

write("education/education.json", {
  _meta: { generatedAt: NOW, source: "KNBS 2019 Census (school attendance); KNEC; Ministry of Education", url: "https://www.knbs.or.ke/", note: "School counts, enrolment and KCPE/KCSE performance pending ingestion — null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    primarySchools: null,
    secondarySchools: null,
    enrolmentPrimary: null,
    enrolmentSecondary: null,
    literacyRatePct: null,
    kcseMeanGrade: null,
    dataAvailable: false,
  }])),
});

write("agriculture/agriculture.json", {
  _meta: { generatedAt: NOW, source: "KNBS Economic Survey; county CIDPs; Ministry of Agriculture", url: "https://www.knbs.or.ke/", note: "Crop/livestock output pending ingestion from KNBS Economic Survey county tables — null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    mainCrops: null,
    livestockHead: null,
    agricultureGvaSharePct: null,
    dataAvailable: false,
  }])),
});

write("infrastructure/infrastructure.json", {
  _meta: { generatedAt: NOW, source: "KeRRA road registry; Kenya Power; county CIDPs", url: "https://kerra.or.ke/", note: "Road km, electrification and water coverage pending ingestion — null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    countySeat: CAPITALS[c.code] ?? null,
    pavedRoadKm: null,
    electrificationPct: null,
    waterCoveragePct: null,
    dataAvailable: Boolean(CAPITALS[c.code]),
  }])),
});

write("projects/projects.json", {
  _meta: { generatedAt: NOW, source: "CoB BIRR development absorption (published proxy for project delivery); county CIDP project registers pending", url: "https://cob.go.ke/reports", note: "Individual project registers are not in the bundled extract — developmentAbsorption is shown as the published proxy." },
  counties: Object.fromEntries(COUNTIES.map((c) => {
    const f = COUNTY_FINANCE.find((x) => x.countyName === c.name);
    return [c.name, {
      countyCode: c.code,
      developmentAbsorptionPct: f?.developmentAbsorption ?? null,
      overallAbsorptionPct: f?.overallAbsorption ?? null,
      pendingBillsKshsM: f?.pendingBills ?? null,
      activeProjects: null,
      stalledProjects: null,
      dataAvailable: Boolean(f),
    }];
  })),
});

write("procurement/procurement.json", {
  _meta: { generatedAt: NOW, source: "PPRA public procurement portal", url: "https://www.ppra.go.ke/", note: "Award-level tender data is NOT bundled — fetch from PPRA portal via ingestion. Nulls, never fabricated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    tendersAwarded: null,
    tenderValueKshsM: null,
    singleSourcedPct: null,
    dataAvailable: false,
  }])),
});

write("environment/environment.json", {
  _meta: { generatedAt: NOW, source: "KNBS 2019 Census; NEMA; county environment reports", url: "https://www.nema.go.ke/", note: "Land area and density are published; forest cover, waste and pollution metrics pending — null, not estimated." },
  counties: Object.fromEntries(COUNTIES.map((c) => [c.name, {
    countyCode: c.code,
    landAreaSqKm: c.area,
    densityPerSqKm: c.density,
    forestCoverPct: null,
    protectedAreaSqKm: null,
    dataAvailable: true,
    partialFields: ["forestCoverPct", "protectedAreaSqKm"],
  }])),
});

// representatives flat export (for the directory/API)
write("counties/representatives.json", {
  _meta: { generatedAt: NOW, source: "IEBC 2022; parliament.go.ke; county gazettes", total: COUNTIES.reduce((s, c) => s + flattenCounty(c).length, 0) + 2 },
  representatives: [...COUNTIES.flatMap(flattenCounty)].map((p) => ({ ...p })),
});

console.log("done. counties:", COUNTIES.length);
