# kenya-county-data

Structured, source-cited data for all **47 counties of Kenya**, backing the Kenya GovDash app.

> Non-partisan · Factual · Source-cited · Data-gap transparent. Fields that are not in a published
> source are `null` with a `source`/`_meta` note — never estimated.

```
kenya-county-data/
├── data/
│   ├── counties/
│   │   ├── county_master.json          # 47 counties: codes, seats, centroids, population, leadership
│   │   ├── county_boundaries.geojson   # county centroids (Points) — swap in IEBC polygons via ingestion
│   │   └── representatives.json      # flat list: governors, senators, women reps, MPs, CECMs
│   ├── demographics/demographics.json # KNBS 2019 Census (population, area, density; households pending)
│   ├── health/health.json              # referral hospitals; facility counts pending KHIS ingest
│   ├── education/education.json        # pending KNBS/KNEC ingest
│   ├── agriculture/agriculture.json    # pending KNBS Economic Survey ingest
│   ├── finance/finance.json            # CoB BIRR + OAG: national & county snapshots, audit summary
│   ├── infrastructure/infrastructure.json
│   ├── projects/projects.json          # development absorption proxy + pending bills
│   ├── governance/governance.json      # leadership, CECMs (verified flag), senate leadership
│   ├── procurement/procurement.json    # pending PPRA ingest (never fabricated)
│   ├── environment/environment.json
│   └── elections/elections_2022.json  # IEBC 2022: governor/senator/woman rep per county
├── ingestion/
│   ├── knbs/fetch_knbs.mjs             # KNBS census volumes -> demographics
│   ├── treasury/fetch_cob.mjs          # CoB BIRR PDFs -> finance (pass local PDF text as arg)
│   ├── cog/fetch_cog.mjs               # CoG performance index -> compliance scores
│   ├── county_portals/scrape_portals.mjs # county sites -> CECM verification
│   └── validation/validate.mjs         # structural validation, exit 1 on errors
├── backend/server.mjs                  # zero-dep JSON API (node backend/server.mjs)
└── database/
    ├── schema.sql                      # full schema (SQLite dev / Postgres prod)
    └── migrations/0001_init.sql, 0002_domains.sql, 0003_civic.sql
```

## Regenerate the JSON from the app's verified datasets

```bash
npx tsx scripts/generate-county-data.mts
```

## Validate

```bash
node kenya-county-data/ingestion/validation/validate.mjs
```

## Run the local data API

```bash
node kenya-county-data/backend/server.mjs 4000
curl http://localhost:4000/api/health
curl http://localhost:4000/api/counties/47            # Nairobi City
curl http://localhost:4000/api/counties/42/finance    # Kisumu finance
curl "http://localhost:4000/api/finance?format=csv" -o finance.csv
curl "http://localhost:4000/api/search?q=nakuru"
```

## Ingest fresh data (network required)

```bash
node kenya-county-data/ingestion/knbs/fetch_knbs.mjs
node kenya-county-data/ingestion/treasury/fetch_cob.mjs ./download/cg-birr-2023-24.txt
node kenya-county-data/ingestion/cog/fetch_cog.mjs
node kenya-county-data/ingestion/county_portals/scrape_portals.mjs
node kenya-county-data/ingestion/validation/validate.mjs
```

## Load into SQLite

```bash
sqlite3 dev.db < kenya-county-data/database/schema.sql
for f in kenya-county-data/database/migrations/*.sql; do sqlite3 dev.db < "$f"; done
```

## Primary sources

| Source | URL | Provides |
| --- | --- | --- |
| KNBS | https://www.knbs.or.ke/?p=2972 | 2019 Census: population, area, households |
| CoB | https://cob.go.ke/reports | BIRRs: budgets, absorption, pending bills |
| OAG | https://www.oagkenya.go.ke/ | Green Book: audit opinions, findings |
| CoG | https://cog.go.ke/ | compliance scores, county status |
| Parliament | https://www.parliament.go.ke/the-senate/senators | senators roster (HTML; DSpace API for Hansard) |
| IEBC | https://www.iebc.or.ke/ | 2022 results, nomination gazettes |
| PPRA | https://www.ppra.go.ke/ | tender awards |
| KHIS | https://khis.health.go.ke/ | health facility registry |
| County portals | e.g. https://nairobi.go.ke | CECM lists, CIDPs |
