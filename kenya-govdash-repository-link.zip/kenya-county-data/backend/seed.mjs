// Seed a SQLite database (kenya-county-data/backend/dev.db) from the JSON data
// using the schema in database/schema.sql. Uses sql.js (WASM SQLite) — no native deps.
// Usage: node kenya-county-data/backend/seed.mjs
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import initSqlJs from "sql.js";

const HERE = join(dirname(new URL(import.meta.url).pathname));
const DATA = join(HERE, "..", "data");
const DB_DIR = HERE;
const DB_FILE = join(DB_DIR, "dev.db");

const load = (rel) => JSON.parse(readFileSync(join(DATA, rel), "utf8"));
const schema = readFileSync(join(HERE, "..", "database", "schema.sql"), "utf8");

const SQL = await initSqlJs();
const db = existsSync(DB_FILE) ? new SQL.Database(readFileSync(DB_FILE)) : new SQL.Database();
db.run(schema);

const master = load("counties/county_master.json");
const reps = load("counties/representatives.json");
const fin = load("finance/finance.json");
const domains = {
  health: load("health/health.json"),
  education: load("education/education.json"),
  agriculture: load("agriculture/agriculture.json"),
  infrastructure: load("infrastructure/infrastructure.json"),
  projects: load("projects/projects.json"),
  procurement: load("procurement/procurement.json"),
  environment: load("environment/environment.json"),
};

const codeByName = Object.fromEntries(master.counties.map((c) => [c.name, c.code]));

const insCounty = db.prepare(`INSERT OR REPLACE INTO counties (code,name,region,county_seat,centroid_lat,centroid_lon,population_2019,land_area_sq_km,density_per_sq_km) VALUES (?,?,?,?,?,?,?,?,?)`);
for (const c of master.counties) insCounty.run([c.code, c.name, c.region, c.countySeat, c.centroid?.[0] ?? null, c.centroid?.[1] ?? null, c.population2019, c.landAreaSqKm, c.densityPerSqKm]);

const insRep = db.prepare(`INSERT OR REPLACE INTO representatives (id,full_name,title,party,coalition,level,jurisdiction,county_code,term_start,term_end,verified,bio,bio_source,email,phone,twitter,website) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const r of reps.representatives) insRep.run([r.id, r.name, r.title, r.party ?? "", r.coalition, r.level, r.jurisdiction, r.countyCode ?? null, r.termStart, r.termEnd, r.verified ? 1 : 0, r.bio ?? null, r.bioSource ?? null, r.email ?? null, r.phone ?? null, r.twitter ?? null, r.website ?? null]);

const insFin = db.prepare(`INSERT OR REPLACE INTO finance_snapshots (county_code,fiscal_year,level,approved_budget_m,equitable_share_m,osr_target_m,osr_collected_m,actual_expenditure_m,recurrent_expenditure_m,development_expenditure_m,overall_absorption_pct,recurrent_absorption_pct,development_absorption_pct,audit_opinion,pending_bills_m,compliance_score,notes,source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const r of fin.counties) insFin.run([codeByName[r.countyName] ?? null, r.fiscalYear, "county", r.approvedBudget, r.equitableShare, r.osrTarget, r.ownSourceRevenue ?? null, r.actualExpenditure ?? null, r.recurrentExpenditure ?? null, r.developmentExpenditure ?? null, r.overallAbsorption ?? null, r.recurrentAbsorption ?? null, r.developmentAbsorption ?? null, r.auditOpinion, r.pendingBills ?? null, r.complianceScore ?? null, r.notes ?? null, r.source]);

const insNat = db.prepare(`INSERT OR REPLACE INTO national_finance (fiscal_year,approved_budget_m,actual_expenditure_m,recurrent_expenditure_m,development_expenditure_m,overall_absorption_pct,recurrent_absorption_pct,development_absorption_pct,pending_bills_m,total_debt_m,audit_opinion,notes,source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const n of fin.national) insNat.run([n.fiscalYear, n.approvedBudget, n.actualExpenditure, n.recurrentExpenditure, n.developmentExpenditure, n.overallAbsorption, n.recurrentAbsorption, n.developmentAbsorption, n.pendingBills, n.totalDebt, n.auditOpinion, n.notes ?? null, n.source]);

// devolution history into national_finance-like table via a generic key/value approach:
db.run(`CREATE TABLE IF NOT EXISTS devolution_history (fiscal_year TEXT PRIMARY KEY, equitable_share_b REAL, county_budget_b REAL, expenditure_b REAL, overall_absorption_pct REAL, development_absorption_pct REAL, osr_collected_b REAL, osr_target_b REAL, audit_unmodified INTEGER, audit_qualified INTEGER, audit_adverse INTEGER, audit_disclaimer INTEGER, source TEXT)`);
const insDev = db.prepare(`INSERT OR REPLACE INTO devolution_history VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const d of fin.devolution ?? []) insDev.run([d.fiscalYear, d.equitableShareB, d.countyBudgetB, d.expenditureB, d.overallAbsorptionPct, d.developmentAbsorptionPct, d.osrCollectedB, d.osrTargetB, d.auditUnmodified, d.auditQualified, d.auditAdverse, d.auditDisclaimer, d.source]);

const insDom = (table, row) => db.prepare(`INSERT OR REPLACE INTO ${table} (county_code, source, updated_at) VALUES (?,?,?)`);
const domRows = {
  domain_health: (d, c) => [c, d.referralHospital, d.totalFacilities, d.hospitalBeds, d.healthWorkers, d.under5Mortality, "KHIS/MoH", new Date().toISOString()],
  domain_education: (d, c) => [c, d.primarySchools, d.secondarySchools, d.enrolmentPrimary, d.enrolmentSecondary, d.literacyRatePct, d.kcseMeanGrade, "KNBS/KNEC", new Date().toISOString()],
  domain_agriculture: (d, c) => [c, d.mainCrops, d.livestockHead, d.agricultureGvaSharePct, "KNBS Economic Survey", new Date().toISOString()],
  domain_infrastructure: (d, c) => [c, d.pavedRoadKm, d.electrificationPct, d.waterCoveragePct, "KeRRA/KPLC/CIDP", new Date().toISOString()],
  domain_projects: (d, c) => [c, d.activeProjects, d.stalledProjects, d.developmentAbsorptionPct, "CoB CG-BIRR", new Date().toISOString()],
  domain_procurement: (d, c) => [c, d.tendersAwarded, d.tenderValueKshsM, d.singleSourcedPct, "PPRA", new Date().toISOString()],
  domain_environment: (d, c) => [c, d.forestCoverPct, d.protectedAreaSqKm, "KNBS/NEMA", new Date().toISOString()],
};
for (const [name, file] of Object.entries(domains)) {
  const table = "domain_" + name;
  const fn = domRows[table];
  const stmt = db.prepare(`INSERT OR REPLACE INTO ${table} VALUES (${Array(fn({}, 0).length).fill("?").join(",")})`);
  for (const [countyName, d] of Object.entries(file.counties)) {
    stmt.run(fn(d, codeByName[countyName]));
  }
}

mkdirSync(DB_DIR, { recursive: true });
writeFileSync(DB_FILE, Buffer.from(db.export()));
const counts = db.exec("SELECT (SELECT COUNT(*) FROM counties) c, (SELECT COUNT(*) FROM representatives) r, (SELECT COUNT(*) FROM finance_snapshots) f, (SELECT COUNT(*) FROM devolution_history) d")[0].values[0];
console.log("seeded dev.db:", JSON.stringify(counts));
db.close();
