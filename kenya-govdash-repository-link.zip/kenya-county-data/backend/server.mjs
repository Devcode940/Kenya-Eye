// Kenya GovDash — SQLite-backed data API.
// Usage:
//   node kenya-county-data/backend/seed.mjs          # build/refresh dev.db from JSON
//   node kenya-county-data/backend/server.mjs 4000   # serve API (auto-seeds if missing)
// Zero native deps: sql.js (WASM SQLite). CORS enabled for the frontend dev server.
import { createServer } from "node:http";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { execFileSync } from "node:child_process";
import initSqlJs from "sql.js";

const HERE = join(dirname(new URL(import.meta.url).pathname));
const DB_FILE = join(HERE, "dev.db");
const PORT = Number(process.argv[2]) || 4000;

if (!existsSync(DB_FILE)) {
  console.log("dev.db missing — seeding from JSON…");
  execFileSync(process.execPath, [join(HERE, "seed.mjs")], { stdio: "inherit" });
}

const SQL = await initSqlJs();
const db = new SQL.Database(readFileSync(DB_FILE));

const q = (sql, ...params) => {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
};
const run = (sql, ...params) => {
  db.run(sql, params);
  writeFileSync(DB_FILE, Buffer.from(db.export()));
};

function send(res, code, obj, headers = {}) {
  res.writeHead(code, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    ...headers,
  });
  res.end(typeof obj === "string" ? obj : JSON.stringify(obj));
}

async function body(req) {
  let s = "";
  for await (const chunk of req) s += chunk;
  try { return JSON.parse(s || "{}"); } catch { return {}; }
}

const REPORTS_BY_FY = [
  { fy: "2013/14", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports", note: "First year of devolution. OAG county audit fiduciary risks report tabled in Parliament 14 Nov 2018." },
  { fy: "2014/15", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2015/16", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2016/17", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2017/18", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2018/19", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2019/20", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2020/21", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports" },
  { fy: "2021/22", oag: "https://www.oagkenya.go.ke/2021-2022-county-government-audit-reports/", cob: "https://cob.go.ke/reports" },
  { fy: "2022/23", oag: "https://www.oagkenya.go.ke/2022-2023-county-government-audit-reports/", cob: "https://cob.go.ke/reports" },
  { fy: "2023/24", oag: "https://www.oagkenya.go.ke/2023-2024-county-government-audit-reports/", cob: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports" },
  { fy: "2024/25", oag: "https://www.oagkenya.go.ke/", cob: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports" },
];

createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const p = u.pathname;

  if (p === "/api/health") return send(res, 200, { ok: true, db: "sqlite(dev.db)", time: new Date().toISOString(), counties: q("SELECT COUNT(*) n FROM counties")[0].n });

  if (p === "/api/counties" && req.method === "GET") return send(res, 200, q("SELECT * FROM counties ORDER BY code"));

  let m = p.match(/^\/api\/counties\/(\d+)$/);
  if (m && req.method === "GET") {
    const c = q("SELECT * FROM counties WHERE code=?", Number(m[1]))[0];
    if (!c) return send(res, 404, { error: "county not found" });
    c.representatives = q("SELECT * FROM representatives WHERE county_code=?", c.code);
    return send(res, 200, c);
  }

  m = p.match(/^\/api\/counties\/(\d+)\/([a-z_]+)$/);
  if (m && req.method === "GET") {
    const table = "domain_" + m[2];
    const ok = q("SELECT name FROM sqlite_master WHERE type='table' AND name=?", table)[0];
    if (!ok) return send(res, 404, { error: "unknown domain" });
    return send(res, 200, { county_code: Number(m[1]), domain: m[2], row: q(`SELECT * FROM ${table} WHERE county_code=?`, Number(m[1]))[0] ?? null });
  }

  if (p === "/api/finance" && req.method === "GET") {
    const county = u.searchParams.get("county");
    const fy = u.searchParams.get("fy");
    let rows = q(`SELECT f.*, c.name county_name FROM finance_snapshots f LEFT JOIN counties c ON c.code=f.county_code ${county ? "WHERE c.name LIKE ?" : ""} ${fy ? (county ? "AND" : "WHERE") + " f.fiscal_year=?" : ""} ORDER BY county_name`, ...[...(county ? [`%${county}%`] : []), ...(fy ? [fy] : [])]);
    if (u.searchParams.get("format") === "csv") {
      const csv = ["county,fy,approvedBudget,absorption,audit,compliance,pendingBills", ...rows.map((r) => [r.county_name, r.fiscal_year, r.approved_budget_m, r.overall_absorption_pct, r.audit_opinion, r.compliance_score, r.pending_bills_m].join(","))].join("\n");
      return send(res, 200, csv, { "content-type": "text/csv" });
    }
    return send(res, 200, { national: q("SELECT * FROM national_finance ORDER BY fiscal_year"), devolution: q("SELECT * FROM devolution_history ORDER BY fiscal_year"), counties: rows });
  }

  if (p === "/api/devolution") return send(res, 200, q("SELECT * FROM devolution_history ORDER BY fiscal_year"));

  if (p === "/api/reports") return send(res, 200, { reports: REPORTS_BY_FY, devolution: q("SELECT * FROM devolution_history ORDER BY fiscal_year") });

  if (p === "/api/representatives" && req.method === "GET") {
    const qy = u.searchParams.get("q") || "";
    const type = u.searchParams.get("type") || "";
    const where = [];
    const params = [];
    if (qy) { where.push("(full_name LIKE ? OR title LIKE ? OR party LIKE ? OR jurisdiction LIKE ?)"); params.push(`%${qy}%`, `%${qy}%`, `%${qy}%`, `%${qy}%`); }
    if (type === "senators") { where.push("title LIKE 'Senator%'"); }
    if (type === "governors") { where.push("title LIKE 'Governor%'"); }
    if (type === "women-reps") { where.push("title LIKE 'Woman%'"); }
    return send(res, 200, q(`SELECT * FROM representatives ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY full_name LIMIT 500`, ...params));
  }

  if (p === "/api/search" && req.method === "GET") {
    const s = `%${(u.searchParams.get("q") || "").toLowerCase()}%`;
    return send(res, 200, {
      counties: q("SELECT * FROM counties WHERE lower(name||region||county_seat) LIKE ?", s),
      people: q("SELECT * FROM representatives WHERE lower(full_name||title||party||jurisdiction) LIKE ? LIMIT 50", s),
      finance: q("SELECT f.*, c.name county_name FROM finance_snapshots f LEFT JOIN counties c ON c.code=f.county_code WHERE lower(c.name) LIKE ?", s),
    });
  }

  if (p === "/api/feedback" && req.method === "GET") return send(res, 200, q("SELECT * FROM feedback ORDER BY created_at DESC LIMIT 100"));
  if (p === "/api/feedback" && req.method === "POST") {
    const b = await body(req);
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    run("INSERT INTO feedback (id,name,county_code,topic,message,status,created_at,history) VALUES (?,?,?,?,?,?,?,?)", id, b.name ?? "Anonymous", b.countyCode ?? null, b.topic ?? "General", b.message ?? "", "Received", now, JSON.stringify([{ status: "Received", at: now }]));
    return send(res, 201, { id, status: "Received" });
  }

  if (p === "/api/whistleblower" && req.method === "POST") {
    const b = await body(req);
    const id = "WB-" + crypto.randomUUID().slice(0, 8).toUpperCase();
    const now = new Date().toISOString();
    run("INSERT INTO whistleblower_envelopes (id,wrapped_key,iv,ciphertext,category,county_code,status,created_at,history) VALUES (?,?,?,?,?,?,?,?,?)", id, b.wrappedKey, b.iv, b.ciphertext, b.category ?? "Other", b.countyCode ?? null, "Queued", now, JSON.stringify([{ status: "Queued", at: now }]));
    return send(res, 201, { ticket: id });
  }
  if (p === "/api/whistleblower/status" && req.method === "GET") {
    const t = (u.searchParams.get("ticket") || "").toUpperCase();
    const row = q("SELECT id,category,county_code,status,created_at,history FROM whistleblower_envelopes WHERE id=?", t)[0];
    return row ? send(res, 200, row) : send(res, 404, { error: "no such ticket" });
  }

  send(res, 404, { error: "not found", routes: ["/api/health", "/api/counties", "/api/counties/:code", "/api/counties/:code/:domain", "/api/finance?county=&fy=&format=csv", "/api/devolution", "/api/reports", "/api/representatives?q=&type=", "/api/search?q=", "/api/feedback", "/api/whistleblower", "/api/whistleblower/status?ticket="] });
}).listen(PORT, () => console.log(`kenya-govdash SQLite API on http://localhost:${PORT}/api/health`));
