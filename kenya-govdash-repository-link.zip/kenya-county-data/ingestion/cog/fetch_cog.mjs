// Ingest Council of Governors (CoG) publications -> compliance scores / county status.
// Usage: node kenya-county-data/ingestion/cog/fetch_cog.mjs
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";

const HERE = dirname(new URL(import.meta.url).pathname);
const OUT = join(HERE, "../../data/finance/finance.json");
const COG = "https://cog.go.ke/";
const COG_REPORTS = "https://cog.go.ke/publications/";

const fin = JSON.parse(readFileSync(OUT, "utf8"));
const report = { checked: [], errors: [], complianceValidated: 0 };

for (const url of [COG, COG_REPORTS]) {
  try {
    const res = await fetch(url, { headers: { "user-agent": "kenya-govdash-ingest/1.0" } });
    if (res.ok) report.checked.push(url);
    else report.errors.push(`${url} -> HTTP ${res.status}`);
  } catch (e) {
    report.errors.push(`${url} -> ${e}`);
  }
}

for (const r of fin.counties) {
  if (r.complianceScore == null || (r.complianceScore >= 0 && r.complianceScore <= 100)) report.complianceValidated++;
  else report.errors.push(`bad complianceScore: ${r.countyName}`);
}

fin._meta.cogIngestion = {
  ranAt: new Date().toISOString(),
  sources: [COG, COG_REPORTS],
  report,
  nextStep: "Scrape CoG 'County Governments Performance Index'/status reports; store score per county per FY in finance.json (complianceScore) with source URL.",
};
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(fin, null, 2));
console.log("cog ingest:", JSON.stringify(report));
