// Validate all data/*.json files against structural rules + county code coverage.
// Usage: node kenya-county-data/ingestion/validation/validate.mjs   (exit 1 on errors)
import { readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";

const DATA = join(dirname(new URL(import.meta.url).pathname), "../../data");
const errors = [];
const warnings = [];

function load(rel) {
  return JSON.parse(readFileSync(join(DATA, rel), "utf8"));
}

const master = load("counties/county_master.json");
const codes = new Set(master.counties.map((c) => c.code));
const names = new Set(master.counties.map((c) => c.name));

if (master.counties.length !== 47) errors.push(`county_master has ${master.counties.length} counties, expected 47`);
for (const c of master.counties) {
  if (!(c.code >= 1 && c.code <= 47)) errors.push(`bad code ${c.code}`);
  if (!c.governor?.name) errors.push(`${c.name}: missing governor`);
  if (!c.senator?.name) warnings.push(`${c.name}: missing senator`);
  if (!c.womanRepresentative?.name) warnings.push(`${c.name}: missing woman rep`);
  if (typeof c.population2019 !== "number" || c.population2019 <= 0) errors.push(`${c.name}: bad population`);
}

const geo = load("counties/county_boundaries.geojson");
if (geo.type !== "FeatureCollection" || geo.features.length !== 47) errors.push("geojson must have 47 features");
for (const f of geo.features) {
  const [lon, lat] = f.geometry.coordinates;
  if (lon < 32 || lon > 42 || lat < -5 || lat > 5) errors.push(`centroid out of Kenya bounds: ${f.properties.name}`);
}

const domains = ["demographics/demographics.json", "elections/elections_2022.json", "finance/finance.json", "governance/governance.json", "health/health.json", "education/education.json", "agriculture/agriculture.json", "infrastructure/infrastructure.json", "projects/projects.json", "procurement/procurement.json", "environment/environment.json"];
for (const d of domains) {
  const j = load(d);
  const countyMap = j.counties ?? (d.startsWith("finance") ? null : null);
  if (d.startsWith("finance")) {
    for (const r of j.counties) {
      if (!names.has(r.countyName)) errors.push(`finance: unknown county ${r.countyName}`);
      if (r.overallAbsorption != null && (r.overallAbsorption < 0 || r.overallAbsorption > 100)) errors.push(`finance: absorption out of range ${r.countyName}`);
      if (!r.source) errors.push(`finance: missing source ${r.countyName}`);
    }
    continue;
  }
  const keys = Object.keys(countyMap);
  if (keys.length !== 47) errors.push(`${d}: ${keys.length} county entries, expected 47`);
  for (const k of keys) {
    if (!names.has(k)) errors.push(`${d}: unknown county ${k}`);
    if (countyMap[k].countyCode !== master.counties.find((c) => c.name === k)?.code) errors.push(`${d}: code mismatch ${k}`);
  }
}

// every JSON file under data/ must parse
(function walk(dir) {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) walk(p);
    else if (p.endsWith(".json") || p.endsWith(".geojson")) {
      try { JSON.parse(readFileSync(p, "utf8")); } catch (err) { errors.push(`unparseable ${p}: ${err}`); }
    }
  }
})(DATA);

console.log("validation:", errors.length ? `FAILED (${errors.length})` : "OK", warnings.length ? `warnings: ${warnings.length}` : "");
for (const e of errors) console.log("ERROR:", e);
for (const w of warnings.slice(0, 10)) console.log("warn:", w);
process.exit(errors.length ? 1 : 0);
