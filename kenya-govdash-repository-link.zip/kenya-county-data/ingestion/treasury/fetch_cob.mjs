// Ingest Controller of Budget (CoB) BIRR reports -> data/finance/finance.json
// Usage: node kenya-county-data/ingestion/treasury/fetch_cob.mjs [path-to-local-cbirr.pdf]
// Without a local PDF it checks the CoB reports portal and validates existing rows.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";

const HERE = dirname(new URL(import.meta.url).pathname);
const OUT = join(HERE, "../../data/finance/finance.json");
const COB_REPORTS = "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports";
const COB_NATIONAL = "https://cob.go.ke/reports";

const fin = JSON.parse(readFileSync(OUT, "utf8"));
const report = { portalChecked: false, rowsValidated: 0, rowsRejected: [], parsed: 0 };

async function check(url) {
  const res = await fetch(url, { headers: { "user-agent": "kenya-govdash-ingest/1.0" } });
  return res.ok;
}

try {
  report.portalChecked = await check(COB_REPORTS) && (await check(COB_NATIONAL));
} catch (e) {
  report.rowsRejected.push(`portal unreachable: ${e}`);
}

const RE = /(?:absorption|execution)[^\d]{0,40}(\d{1,3}(?:\.\d)?)\s*(?:per\s*cent|%)/gi;

// Validate existing county rows; optionally parse a locally downloaded CG-BIRR PDF text.
const localPdf = process.argv[2];
if (localPdf && existsSync(localPdf)) {
  // pdf parsing requires pdfjs-dist (see original repo scripts/ingest_pdfs.ts).
  // Here we expect extracted text (.txt) alongside or passed directly.
  const text = readFileSync(localPdf, "utf8");
  let m;
  while ((m = RE.exec(text))) report.parsed++;
  console.log(`parsed ${report.parsed} absorption mentions from ${localPdf}`);
}

for (const r of fin.counties) {
  const ok =
    typeof r.approvedBudget === "number" &&
    (r.overallAbsorption == null || (r.overallAbsorption >= 0 && r.overallAbsorption <= 100)) &&
    ["Unmodified", "Qualified", "Adverse", "Disclaimer", "Not Audited"].includes(r.auditOpinion) &&
    typeof r.source === "string" && r.source.length > 0;
  if (ok) report.rowsValidated++;
  else report.rowsRejected.push(r.countyName + " " + r.fiscalYear);
}

fin._meta.ingestion = {
  ranAt: new Date().toISOString(),
  sources: [COB_REPORTS, COB_NATIONAL],
  report,
  nextStep: "Download the Annual CG-BIRR PDF, extract text (pdfjs-dist), and map Table 2.x county rows (budget, expenditure, absorption) into finance.json. Keep source per row.",
};
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(fin, null, 2));
console.log("cob ingest:", JSON.stringify(report));
