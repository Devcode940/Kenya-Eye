// Ingest KNBS 2019 Census volumes -> data/demographics/demographics.json
// Usage: node kenya-county-data/ingestion/knbs/fetch_knbs.mjs
// Network failures leave existing data untouched (idempotent, never destructive).
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";

const HERE = dirname(new URL(import.meta.url).pathname);
const OUT = join(HERE, "../../data/demographics/demographics.json");
const MASTER = join(HERE, "../../data/counties/county_master.json");

const KNBS_CENSUS = "https://www.knbs.or.ke/?p=2972"; // 2019 Census volumes
const KNBS_API_NOTE = "KNBS publishes census volumes as PDF/XLSX; no stable JSON API. Parse volumes or use the KNBS statbank.";

const master = JSON.parse(readFileSync(MASTER, "utf8"));
const existing = JSON.parse(readFileSync(OUT, "utf8"));

async function fetchText(url) {
  const res = await fetch(url, { headers: { "user-agent": "kenya-govdash-ingest/1.0 (civic accountability)" } });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.text();
}

const report = { fetched: [], skipped: [], validated: 0, errors: [] };

try {
  // Validate the census landing page is reachable (source citation check).
  await fetchText(KNBS_CENSUS);
  report.fetched.push(KNBS_CENSUS);
} catch (e) {
  report.errors.push(String(e));
}

// Cross-check master population against the demographics file we generated from KNBS 2019.
for (const c of master.counties) {
  const d = existing.counties[c.name];
  if (d && d.population2019 === c.population2019 && d.landAreaSqKm === c.landAreaSqKm) report.validated++;
  else report.errors.push(`mismatch: ${c.name}`);
}

existing._meta.ingestion = {
  ranAt: new Date().toISOString(),
  source: KNBS_CENSUS,
  apiNote: KNBS_API_NOTE,
  report,
  nextStep: "Download census Vol II (population by county) & Vol III (households) XLSX/PDF from the KNBS portal and parse county tables into demographics.json fields households/urbanPopulation/ruralPopulation.",
};
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(existing, null, 2));
console.log("knbs ingest:", JSON.stringify(report));
