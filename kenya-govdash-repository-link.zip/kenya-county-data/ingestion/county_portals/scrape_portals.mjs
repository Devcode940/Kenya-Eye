// Scrape county government portals for CECM / county secretary listings.
// Usage: node kenya-county-data/ingestion/county_portals/scrape_portals.mjs
// Best-effort: each county site has a different structure; matches are verified
// against a name pattern and stored with the page URL as the citation.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";

const HERE = dirname(new URL(import.meta.url).pathname);
const OUT = join(HERE, "../../data/governance/governance.json");
const MASTER = join(HERE, "../../data/counties/county_master.json");

// Official county portal domains (verify before use; some counties use .go.ke subdomains).
const PORTALS = {
  "Nairobi City": "https://nairobi.go.ke",
  Mombasa: "https://mombasa.go.ke",
  Kisumu: "https://kisumu.go.ke",
  Nakuru: "https://nakuru.go.ke",
  Kiambu: "https://kiambu.go.ke",
  Kajiado: "https://kajiado.go.ke",
  Kakamega: "https://kakamega.go.ke",
  Machakos: "https://machakos.go.ke",
  Meru: "https://meru.go.ke",
};

const gov = JSON.parse(readFileSync(OUT, "utf8"));
const master = JSON.parse(readFileSync(MASTER, "utf8"));
const report = { fetched: [], errors: [], cecmFound: 0 };

const NAME_RE = /([A-Z][a-z]+(?:\s+(?:ole\s+)?[A-Z][a-z'’-]+){1,4})/g;

for (const [county, base] of Object.entries(PORTALS)) {
  for (const path of ["/county-executive", "/government/county-executive", "/cecms", "/leadership"]) {
    try {
      const res = await fetch(base + path, { headers: { "user-agent": "kenya-govdash-ingest/1.0" } });
      if (!res.ok) continue;
      const html = await res.text();
      const names = [...new Set([...html.matchAll(NAME_RE)].map((m) => m[1]))].slice(0, 40);
      if (names.length) {
        report.fetched.push({ county, url: base + path, names: names.length });
        const row = gov.counties[county];
        if (row) {
          for (const c of row.cems ?? row.cecms) {
            if (c.verified) continue;
            if (names.some((n) => n.toLowerCase().includes(c.name.split(" ").slice(-1)[0].toLowerCase()))) {
              c.verified = true;
              c.verifiedSource = base + path;
              report.cecmFound++;
            }
          }
        }
      }
      break; // first working path wins
    } catch (e) {
      report.errors.push(`${county}${path}: ${e}`);
    }
  }
}

gov._meta.portalIngestion = { ranAt: new Date().toISOString(), portals: PORTALS, report };
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(gov, null, 2));
console.log("portal ingest:", JSON.stringify(report));
console.log("master counties:", master.counties.length);
