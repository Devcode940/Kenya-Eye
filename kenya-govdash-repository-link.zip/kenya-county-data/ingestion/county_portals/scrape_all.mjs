// Scrape ALL 47 county government websites and feed the results into the datasets.
// Usage: node kenya-county-data/ingestion/county_portals/scrape_all.mjs
// Writes: data/governance/county_portal_scrape.json (raw findings, cited per URL)
// and merges verified CECM names into data/governance/governance.json.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";

const HERE = dirname(new URL(import.meta.url).pathname);
const DATA = join(HERE, "../../data");
const sites = JSON.parse(readFileSync(join(HERE, "county_sites.json"), "utf8")).sites;
const OUT_SCRAPE = join(DATA, "governance/county_portal_scrape.json");
const OUT_GOV = join(DATA, "governance/governance.json");

const PATHS = ["/", "/county-executive", "/government/county-executive", "/cecms", "/leadership", "/executive", "/about/county-executive"];
const NAME_RE = /([A-Z][a-z]+(?:\s+(?:ole\s+|van\s+|de\s+)?[A-Z][a-z'’-]+){1,4})/g;
const PORTFOLIO_RE = /(CECM|County Executive Committee|Chief Officer)[^<]{0,120}/gi;

const scrape = { ranAt: new Date().toISOString(), counties: {}, errors: [] };

for (const [county, base] of Object.entries(sites)) {
  const entry = { portal: base, pagesFetched: [], names: [], portfolios: [], ok: false };
  for (const path of PATHS) {
    try {
      const res = await fetch(base + path, { headers: { "user-agent": "kenya-govdash-ingest/1.0 (civic accountability; contact: dev@example.org)" }, signal: AbortSignal.timeout(12000) });
      if (!res.ok) continue;
      const html = (await res.text()).replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ");
      const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ");
      if (text.length < 200) continue;
      entry.pagesFetched.push(base + path);
      entry.ok = true;
      for (const m of text.matchAll(NAME_RE)) entry.names.push(m[1]);
      for (const m of text.matchAll(PORTFOLIO_RE)) entry.portfolios.push(m[0].slice(0, 140));
      entry.names = [...new Set(entry.names)].slice(0, 60);
      entry.portfolios = [...new Set(entry.portfolios)].slice(0, 20);
      break; // first informative page is enough for the merge pass
    } catch (e) {
      entry.pagesFetched.push(`${base}${path} (error: ${String(e).slice(0, 80)})`);
    }
  }
  scrape.counties[county] = entry;
  if (!entry.ok) scrape.errors.push(county);
}

// Merge: mark CECMs verified when their surname appears on the county portal.
const gov = JSON.parse(readFileSync(OUT_GOV, "utf8"));
let verified = 0;
for (const [county, entry] of Object.entries(scrape.counties)) {
  const row = gov.counties[county];
  if (!row || !entry.ok) continue;
  for (const c of row.cecms) {
    if (c.verified) continue;
    const surname = c.name.split(" ").slice(-1)[0].toLowerCase();
    if (surname.length > 3 && entry.names.some((n) => n.toLowerCase().includes(surname))) {
      c.verified = true;
      c.verifiedSource = entry.portal;
      verified++;
    }
  }
}
gov._meta.portalIngestion = { ranAt: scrape.ranAt, verifiedAdded: verified, errors: scrape.errors };

mkdirSync(dirname(OUT_SCRAPE), { recursive: true });
writeFileSync(OUT_SCRAPE, JSON.stringify(scrape, null, 2));
writeFileSync(OUT_GOV, JSON.stringify(gov, null, 2));
console.log(`scraped ${Object.values(scrape.counties).filter((c) => c.ok).length}/47 county portals; verified +${verified} CECMs; errors: ${scrape.errors.length}`);
