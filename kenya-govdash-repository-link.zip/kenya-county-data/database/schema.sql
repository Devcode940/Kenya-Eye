-- Kenya GovDash — county data schema (SQLite dev / PostgreSQL prod compatible).
-- Mirrors the JSON files under kenya-county-data/data/**.
-- All figures must carry a source citation; missing public data is NULL, never estimated.

PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS counties (
  code            INTEGER PRIMARY KEY CHECK (code BETWEEN 1 AND 47),
  name            TEXT NOT NULL UNIQUE,
  region          TEXT NOT NULL,
  county_seat     TEXT,
  centroid_lat    REAL,
  centroid_lon    REAL,
  population_2019 INTEGER NOT NULL,
  land_area_sq_km REAL NOT NULL,
  density_per_sq_km REAL NOT NULL,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS representatives (
  id          TEXT PRIMARY KEY,
  full_name   TEXT NOT NULL,
  title       TEXT NOT NULL,
  party       TEXT,
  coalition   TEXT NOT NULL,
  level       TEXT NOT NULL,           -- National | County | Constituency | Ward
  jurisdiction TEXT NOT NULL,
  county_code INTEGER REFERENCES counties(code),
  term_start  TEXT NOT NULL,
  term_end    TEXT NOT NULL,
  verified    INTEGER NOT NULL DEFAULT 0,
  bio         TEXT,
  bio_source  TEXT,
  email       TEXT,
  phone       TEXT,
  twitter     TEXT,
  website     TEXT
);
CREATE INDEX IF NOT EXISTS idx_reps_county ON representatives(county_code);
CREATE INDEX IF NOT EXISTS idx_reps_name ON representatives(full_name);

CREATE TABLE IF NOT EXISTS finance_snapshots (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  county_code         INTEGER REFERENCES counties(code),
  fiscal_year         TEXT NOT NULL,             -- e.g. '2023/24'
  level               TEXT NOT NULL DEFAULT 'county',
  approved_budget_m   REAL,
  equitable_share_m   REAL,
  osr_target_m        REAL,
  osr_collected_m     REAL,
  actual_expenditure_m REAL,
  recurrent_expenditure_m REAL,
  development_expenditure_m REAL,
  overall_absorption_pct REAL,
  recurrent_absorption_pct REAL,
  development_absorption_pct REAL,
  audit_opinion       TEXT,                    -- Unmodified|Qualified|Adverse|Disclaimer|Not Audited
  pending_bills_m     REAL,
  compliance_score    INTEGER,                 -- CoG 0-100
  notes               TEXT,
  source              TEXT NOT NULL,
  source_url          TEXT,
  UNIQUE(county_code, fiscal_year)
);
CREATE INDEX IF NOT EXISTS idx_finance_county ON finance_snapshots(county_code, fiscal_year);

CREATE TABLE IF NOT EXISTS national_finance (
  fiscal_year TEXT PRIMARY KEY,
  approved_budget_m REAL, actual_expenditure_m REAL,
  recurrent_expenditure_m REAL, development_expenditure_m REAL,
  overall_absorption_pct REAL, recurrent_absorption_pct REAL, development_absorption_pct REAL,
  pending_bills_m REAL, total_debt_m REAL,
  audit_opinion TEXT, notes TEXT, source TEXT NOT NULL
);

-- Domain tables (health, education, agriculture, infrastructure, projects,
-- procurement, environment). One row per county per domain; NULL = not published.
CREATE TABLE IF NOT EXISTS domain_health (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  referral_hospital TEXT, total_facilities INTEGER, hospital_beds INTEGER,
  health_workers INTEGER, under5_mortality REAL, source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_education (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  primary_schools INTEGER, secondary_schools INTEGER, enrolment_primary INTEGER,
  enrolment_secondary INTEGER, literacy_rate_pct REAL, kcse_mean_grade TEXT,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_agriculture (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  main_crops TEXT, livestock_head INTEGER, agriculture_gva_share_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_infrastructure (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  paved_road_km REAL, electrification_pct REAL, water_coverage_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_projects (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  active_projects INTEGER, stalled_projects INTEGER,
  development_absorption_pct REAL, source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_procurement (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  tenders_awarded INTEGER, tender_value_kshs_m REAL, single_sourced_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_environment (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  forest_cover_pct REAL, protected_area_sq_km REAL, source TEXT, updated_at TEXT
);

-- Civic tables
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, name TEXT, county_code INTEGER REFERENCES counties(code),
  topic TEXT NOT NULL, message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Received', created_at TEXT NOT NULL,
  history TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS finance_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL, county_code INTEGER REFERENCES counties(code),
  metric TEXT NOT NULL, threshold REAL NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS whistleblower_envelopes (
  id TEXT PRIMARY KEY,            -- WB-XXXXXXXX
  wrapped_key TEXT NOT NULL,      -- RSA-OAEP wrapped AES key (base64)
  iv TEXT NOT NULL,
  ciphertext TEXT NOT NULL,       -- AES-256-GCM ciphertext only; private key never stored
  category TEXT NOT NULL, county_code INTEGER REFERENCES counties(code),
  status TEXT NOT NULL DEFAULT 'Queued',
  created_at TEXT NOT NULL, history TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS cecm_verification (
  rep_id TEXT PRIMARY KEY REFERENCES representatives(id),
  verified INTEGER NOT NULL DEFAULT 0, verified_by TEXT, verified_at TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS admin_sessions (
  token TEXT PRIMARY KEY, created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
