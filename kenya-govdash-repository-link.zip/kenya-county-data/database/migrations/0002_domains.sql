-- 0002_domains: per-county domain tables (health, education, agriculture,
-- infrastructure, projects, procurement, environment). NULL = not publicly available.
CREATE TABLE IF NOT EXISTS domain_health (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  referral_hospital TEXT, total_facilities INTEGER, hospital_beds INTEGER,
  health_workers INTEGER, under5_mortality REAL, source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_education (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  primary_schools INTEGER, secondary_schools INTEGER, enrolment_primary INTEGER,
  enrolment_secondary INTEGER, literacy_rate_pct REAL, kcse_mean_grade TEXT,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_agriculture (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  main_crops TEXT, livestock_head INTEGER, agriculture_gva_share_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_infrastructure (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  paved_road_km REAL, electrification_pct REAL, water_coverage_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_projects (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  active_projects INTEGER, stalled_projects INTEGER, development_absorption_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_procurement (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  tenders_awarded INTEGER, tender_value_kshs_m REAL, single_sourced_pct REAL,
  source TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS domain_environment (
  county_code INTEGER PRIMARY KEY REFERENCES counties(code),
  forest_cover_pct REAL, protected_area_sq_km REAL, source TEXT, updated_at TEXT
);
