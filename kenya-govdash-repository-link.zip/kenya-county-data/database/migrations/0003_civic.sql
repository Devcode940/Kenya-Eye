-- 0003_civic: feedback, alerts, whistleblower envelopes (ciphertext only), CECM verification, admin sessions
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, name TEXT, county_code INTEGER REFERENCES counties(code),
  topic TEXT NOT NULL, message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Received', created_at TEXT NOT NULL,
  history TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS finance_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL,
  county_code INTEGER REFERENCES counties(code),
  metric TEXT NOT NULL, threshold REAL NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS whistleblower_envelopes (
  id TEXT PRIMARY KEY,
  wrapped_key TEXT NOT NULL, iv TEXT NOT NULL, ciphertext TEXT NOT NULL,
  category TEXT NOT NULL, county_code INTEGER REFERENCES counties(code),
  status TEXT NOT NULL DEFAULT 'Queued', created_at TEXT NOT NULL,
  history TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS cecm_verification (
  rep_id TEXT PRIMARY KEY REFERENCES representatives(id),
  verified INTEGER NOT NULL DEFAULT 0, verified_by TEXT, verified_at TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS admin_sessions (
  token TEXT PRIMARY KEY, created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
