-- 0001_init: core tables (counties, representatives, finance, national_finance)
-- Applied by: sqlite3 dev.db < kenya-county-data/database/migrations/0001_init.sql
-- (schema.sql contains the full current schema; this migration creates the core set.)
CREATE TABLE IF NOT EXISTS counties (
  code INTEGER PRIMARY KEY CHECK (code BETWEEN 1 AND 47),
  name TEXT NOT NULL UNIQUE,
  region TEXT NOT NULL,
  county_seat TEXT,
  centroid_lat REAL,
  centroid_lon REAL,
  population_2019 INTEGER NOT NULL,
  land_area_sq_km REAL NOT NULL,
  density_per_sq_km REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS representatives (
  id TEXT PRIMARY KEY, full_name TEXT NOT NULL, title TEXT NOT NULL, party TEXT,
  coalition TEXT NOT NULL, level TEXT NOT NULL, jurisdiction TEXT NOT NULL,
  county_code INTEGER REFERENCES counties(code), term_start TEXT NOT NULL, term_end TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0, bio TEXT, bio_source TEXT,
  email TEXT, phone TEXT, twitter TEXT, website TEXT
);
CREATE TABLE IF NOT EXISTS finance_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  county_code INTEGER REFERENCES counties(code), fiscal_year TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'county',
  approved_budget_m REAL, equitable_share_m REAL, osr_target_m REAL, osr_collected_m REAL,
  actual_expenditure_m REAL, recurrent_expenditure_m REAL, development_expenditure_m REAL,
  overall_absorption_pct REAL, recurrent_absorption_pct REAL, development_absorption_pct REAL,
  audit_opinion TEXT, pending_bills_m REAL, compliance_score INTEGER,
  notes TEXT, source TEXT NOT NULL, source_url TEXT,
  UNIQUE(county_code, fiscal_year)
);
CREATE TABLE IF NOT EXISTS national_finance (
  fiscal_year TEXT PRIMARY KEY,
  approved_budget_m REAL, actual_expenditure_m REAL,
  recurrent_expenditure_m REAL, development_expenditure_m REAL,
  overall_absorption_pct REAL, recurrent_absorption_pct REAL, development_absorption_pct REAL,
  pending_bills_m REAL, total_debt_m REAL, audit_opinion TEXT, notes TEXT, source TEXT NOT NULL
);
